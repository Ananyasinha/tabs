<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('preTagdata'))
{
    function preTagdata($var)
    {
		echo "<pre>";
		print_r($var);
		echo "</pre>";
    }   
}

if ( ! function_exists('convertdate'))
{
    function convertdate($currdate,$formatdate)
    {
		$cnvrtdate = date($formatdate,strtotime($currdate));
		return $cnvrtdate;
    }   
}


if ( ! function_exists('generatePermaLink'))
{
    function generatePermaLink($job_title)
	{
		$array=array('[',']','(',')','/','%','#','&',',',' ','--','---','----','|','||','.',':');
		$job_title1= str_replace($array,"-",$job_title);
		return strtolower(str_replace($array,"-",$job_title1));
	}   
}

if ( ! function_exists('getpageinfo'))
{
    function getpageinfo($pageid)
    {	
		$obj =& get_instance();
		$obj->db->select('*');
		$obj->db->from('tbl_page');
		$obj->db->where_in('id',$pageid);
		$obj->db->where('status','Active');
		$query = $obj->db->get();
		//echo $obj->db->last_query();
		return $query->row();
    }
}


if ( ! function_exists('getcategory'))
{
    function getcategory($catid="", $limit="")
    {	
		$obj =& get_instance();
		$obj->db->select('*');
		$obj->db->from('tbl_category');
		if($catid!="")
		{
			$obj->db->where('id',$catid);
		}
		if($catid=="")
		{
			$obj->db->where('fld_parentid','0');
		}
		$obj->db->where('status','Active');
		$obj->db->order_by('id','desc');
		if($limit!="" && $limit>0)
		{
			$obj->db->limit($limit);
		}
		$query = $obj->db->get();
		//echo $obj->db->last_query();
		if($catid!="")
		{
			return $query->row();
		}
		else
		{
			return $query->result();
		}
    }
}

if ( ! function_exists('gettotalcatproduct'))
{
    function gettotalcatproduct($subcatid)
	{	
		$obj =& get_instance();
		$obj->db->select('count(*) as totalproduct');
		$obj->db->where('fld_subcategoryid',$subcatid);
		$obj->db->from('tbl_product');
		$obj->db->where('status','Active');
		$query = $obj->db->get();
		//echo $obj->db->last_query();
		$result = $query->row();
		return $result->totalproduct;
    }   
}
