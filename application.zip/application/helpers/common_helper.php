<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('preTagdata'))
{
    function preTagdata($var)
    {
		echo "<pre>";
		print_r($var);
		echo "</pre>";
    }   
}

if ( ! function_exists('convertdate'))
{
    function convertdate($currdate,$formatdate)
    {
		$cnvrtdate = date($formatdate,strtotime($currdate));
		return $cnvrtdate;
    }   
}


if ( ! function_exists('generatePermaLink'))
{
    function generatePermaLink($job_title)
	{
		$array=array('[',']','(',')','/','%','#','&',',',' ','--','---','----','|','||','.',':');
		$job_title1= str_replace($array,"-",$job_title);
		return strtolower(str_replace($array,"-",$job_title1));
	}   
}

if ( ! function_exists('getpageinfo'))
{
    function getpageinfo($pageid)
    {	
		$obj =& get_instance();
		$obj->db->select('*');
		$obj->db->from('tbl_page');
		$obj->db->where_in('id',$pageid);
		$obj->db->where('status','Active');
		$query = $obj->db->get();
		//echo $obj->db->last_query();
		return $query->row();
    }
}

if ( ! function_exists('getproductinfo'))
{
    function getproductinfo($productid='')
    {	
		$obj =& get_instance();
		$obj->db->select('*');
		$obj->db->from('tbl_product');
		if($productid!="")
		{
			$obj->db->where('id',$productid);
		}
		$obj->db->where('status','Active');
		$query = $obj->db->get();
		//echo $obj->db->last_query();
		if($productid!="")
		{
			return $query->row();
		}
		else
		{
			return $query->result();	
		}
    }
}

if ( ! function_exists('getbannerpagelist'))
{
    function getbannerpagelist()
    {	
		$arrgetbannerpagelist['Home'] 			= 'Home';
		$arrgetbannerpagelist['Product']  		= 'Product';
		$arrgetbannerpagelist['Capabilities']  	= 'Capabilities';
		$arrgetbannerpagelist['Facility']  		= 'Facility';
		$arrgetbannerpagelist['Why DCX']  		= 'Why DCX';
		$arrgetbannerpagelist['Quality']  		= 'Quality';
		$arrgetbannerpagelist['Partners']  		= 'Partners';
		$arrgetbannerpagelist['Customers']  	= 'Customers';
		$arrgetbannerpagelist['Awards']  	 	= 'Awards And Recognitions';
		$arrgetbannerpagelist['News']  			= 'News';
		
		$obj =& get_instance();
		$obj->db->select('*');
		$obj->db->from('tbl_product');
		$obj->db->where('status','Active');
		$query = $obj->db->get();
		//echo $obj->db->last_query();
		foreach($query->result() as $row)
		{
			$arrgetbannerpagelist[$row->fld_title] = $row->fld_title;
		}
		
		
		return $arrgetbannerpagelist;
    }
}

if ( ! function_exists('getcapabilitieslist'))
{
    function getcapabilitieslist()
    {	
		$arrcapabilitieslist['1']  = 'Production Machine & Equipment';
		$arrcapabilitieslist['2']  = 'Inspection & Test Equipment';
		
		return $arrcapabilitieslist;
	}
}