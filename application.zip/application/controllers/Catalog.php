<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog extends CI_Controller {

	function __construct() {
        parent::__construct();
		error_reporting(0);
		$this->load->library('Mandrill_Api');
		$this->load->model('catalog_model');
    }
	
	public function index()
	{
		$data['module'] = 'home';
		
		$pageInfo = getpageinfo(1);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['pageimage']= $pageInfo->fld_image;
		$data['details'] = $this->catalog_model->generalinfo();
		$data['gallery'] = $this->catalog_model->galleryinfo();
		$data['gossips'] = $this->catalog_model->gossipsinfo();

		//print_r($data['gallery']);die();

		$pageInfo = getpageinfo(6);
		$data['pageimage_quality']= $pageInfo->fld_image;
		
		
		$data['result_banner'] = $this->catalog_model->viewbannerlist('Home','','Active');
		
		$data['main_content'] = 'home';
		$this->load->view('common/template.php',$data);
	}
	

	
	public function movie()
	{
		$data['module'] = 'movie';
		
		$pageInfo = getpageinfo(2);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['details'] = $this->catalog_model->generalinfo();
		$data['result'] = $this->catalog_model->getmoviedetails();

		//print_r($data['result']);
		
		$data['main_content'] = 'movie';
		$this->load->view('common/template.php',$data);
	}
	

public function gallery()
	{
		$data['gallery'] = 'gallery';
		
		$pageInfo = getpageinfo(3);
		
		$data['details'] = $this->catalog_model->generalinfo();
		$data['result'] = $this->catalog_model->gallerydetails();
		
		print_r($data['result']);
		$data['main_content'] = 'gallery';
		$this->load->view('common/template.php',$data);
	}
	

	public function awards()
	{
		$data['module'] = 'awards';
		
		$pageInfo = getpageinfo(8);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['pageimage']= $pageInfo->fld_image;
		
		$data['result_banner'] = $this->catalog_model->viewbannerlist('Awards And Recognitions','','Active');
		
		$this->load->model('award_model');
		$data['result_awards'] = $this->award_model->viewrecord('','','Active');
		
		$data['main_content'] = 'awards';
		$this->load->view('common/template.php',$data);
	}
	
	public function contactus()
	{
		$data['module'] = 'contactus';
		
		$pageInfo = getpageinfo(11);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
				
		$data['main_content'] = 'contactus';
		$this->load->view('common/template.php',$data);
	}	
	
}
