<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	function __construct() {
        parent::__construct();
		error_reporting(0);
		$this->load->library('Mandrill_Api');
		$this->load->model('catalog_model');
    }
	
	public function index()
	{
		$data['module'] = 'home';
		
		$pageInfo = getpageinfo(1);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		
		$pageInfoabout = getpageinfo(2);
		$data['pagedescriptionabout']= $pageInfoabout->fld_description;
		
		$this->load->model('certificate_model');
		$data['result_certificate'] = $this->certificate_model->viewrecord('',3,'Active');
		
		$this->load->model('category_model');
		$data['result_category'] = $this->category_model->viewrecord('','','Active','Active');
		$data['result'] = $this->catalog_model->homegallery();
		
		$data['main_content'] = 'home';
		$this->load->view('common/template.php',$data);
	}
	
	public function aboutus()
	{
		$data['module'] = 'aboutus';
		
		$pageInfo = getpageinfo(2);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
				
		$data['main_content'] = 'aboutus';
		$this->load->view('common/template.php',$data);
	}
	
	public function products()
	{
		$data['module'] = 'products';
		
		
		$pageInfo = getpageinfo(3);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		
		$this->load->model('product_model');
		$data['result_product'] = $this->product_model->viewrecord('','','Active');
		
		$data['main_content'] = 'products';
		$this->load->view('common/template.php',$data);
	}
	
	public function enquiry()
	{
		$data['module'] = 'enquiry';
		
		$pageInfo = getpageinfo(4);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
				
		$data['main_content'] = 'enquiry';
		$this->load->view('common/template.php',$data);
	}
	
	public function certificates()
	{
		$data['module'] = 'certificates';
		
		$pageInfo = getpageinfo(5);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		
		$this->load->model('certificate_model');
		$data['result'] = $this->certificate_model->viewrecord('','','Active');
		
		$data['main_content'] = 'certificates';
		$this->load->view('common/template.php',$data);
	}
	
	public function gallery()
	{
		$data['module'] = 'gallery';
		
		$pageInfo = getpageinfo(6);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result'] = $this->catalog_model->viewrimage();
				
		$data['main_content'] = 'gallery';
		$this->load->view('common/template.php',$data);
	}
	
	public function contactus()
	{
		$data['module'] = 'contactus';
		
		$pageInfo = getpageinfo(7);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
				
		$data['main_content'] = 'contactus';
		$this->load->view('common/template.php',$data);
	}
	
	public function termsofuse()
	{
		$data['module'] = 'termsofuse';
		
		$pageInfo = getpageinfo(8);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
				
		$data['main_content'] = 'termsofuse';
		$this->load->view('common/template.php',$data);
	}
	
	public function privacypolicy()
	{
		$data['module'] = 'privacypolicy';
		
		$pageInfo = getpageinfo(9);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
				
		$data['main_content'] = 'privacypolicy';
		$this->load->view('common/template.php',$data);
	}
	
	public function sitemap()
	{
		$data['module'] = 'sitemap';
		
		$pageInfo = getpageinfo(10);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
				
		$data['main_content'] = 'sitemap';
		$this->load->view('common/template.php',$data);
	}
	
	public function category()
	{
		$maincatid =  explode("-",$this->uri->segment(2));
		$maincatid =  end($maincatid);
		
		$data['module'] = 'product_list';
		
		$this->load->model('category_model');
		$data['result'] = $this->category_model->viewrecord($maincatid);
		
		$this->load->model('product_model');
		$data['result_product'] = $this->product_model->viewrecord('','','Active','',$maincatid);
		
		$data['main_content'] = 'product_list';
		$this->load->view('common/template.php',$data);
	}
	
}
