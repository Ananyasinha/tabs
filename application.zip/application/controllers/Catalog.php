<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog extends CI_Controller {

	
	function __construct() {
        parent::__construct();
		error_reporting(0);
		$this->load->library('Mandrill_Api');
		$this->load->model('catalog_model');
    }
	

	public function index()
	{
		$data['module'] = 'home';
		
		$pageInfo = getpageinfo(1);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result']   = $this->catalog_model->generalinfo();
		$data['banner']   = $this->catalog_model->bannerinfo();

		//print_r($data['banner']);die();
		
	/*	$pageInfoabout = getpageinfo(2);
		$data['pagedescriptionabout']= $pageInfoabout->fld_description;
		
		$this->load->model('certificate_model');
		$data['result_certificate'] = $this->certificate_model->viewrecord('',3,'Active');
		
		$this->load->model('category_model');
		$data['result_category'] = $this->category_model->viewrecord('','','Active','Active');
		$data['result'] = $this->catalog_model->homegallery();
		*/
		$data['main_content'] = 'index';
		$this->load->view('site_common/template.php',$data);
	}
	
	public function aboutus()
	{
		$data['module'] = 'aboutus';
		
		$pageInfo = getpageinfo(2);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result']   = $this->catalog_model->generalinfo();
				
		$data['main_content'] = 'aboutus';
		$this->load->view('site_common/template.php',$data);
	}
	
	
	public function enquiry()
	{
		$data['module'] = 'enquiry';
		
		$pageInfo = getpageinfo(4);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['main_content'] = 'enquiry';
		$this->load->view('site_common/template.php',$data);
	}
	

	public function infrastructure()
	{
		$data['module'] = 'infrastructure';
		
		$pageInfo = getpageinfo(3);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result']   = $this->catalog_model->generalinfo();
				
		$data['main_content'] = 'infrastructure';
		$this->load->view('site_common/template.php',$data);
	}

	public function services()
	{
		$data['module'] = 'services';
		
		$pageInfo = getpageinfo(3);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result']   = $this->catalog_model->generalinfo();
		$data['details']   = $this->catalog_model->getserviceinfo();
				
		$data['main_content'] = 'services';
		$this->load->view('site_common/template.php',$data);
	}



	public function career()
	{
		$data['module'] = 'career';
		
		$pageInfo = getpageinfo(5);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result']   = $this->catalog_model->generalinfo();
				
		$data['main_content'] = 'career';
		$this->load->view('site_common/template.php',$data);
	}
	
	public function management()
	{
		$data['module'] = 'management';
		
		$pageInfo = getpageinfo(6);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		=  $pageInfo->fld_mkeyword;
		$data['result']   = $this->catalog_model->generalinfo();
		$data['pagedetail']   = $this->catalog_model->getpagedetail();

		$data['main_content'] = 'management';
		$this->load->view('site_common/template.php',$data);
	}
	
	
	public function gallery()
	{
		$data['module'] = 'gallery';
		
		$pageInfo = getpageinfo(7);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result']   = $this->catalog_model->generalinfo();
		$data['result1'] = $this->catalog_model->viewrimage();
				
		$data['main_content'] = 'gallery';
		$this->load->view('site_common/template.php',$data);
	}
	
	public function customhouseagent()
	{

		//$pageInfo = getpageinfo(7);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result']   = $this->catalog_model->generalinfo();
		$data['details']   = $this->catalog_model->galleryimage();
				
		$data['main_content'] = 'custom-house-agent';
		$this->load->view('site_common/template.php',$data);
	}
	


	public function contactus()
	{
		$data['module'] = 'contactus';
		
		$pageInfo = getpageinfo(8);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pageshortdescription']= $pageInfo->fld_shortdescription;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result'] = $this->catalog_model->generalinfo();
	
		$data['main_content'] = 'contact';
		$this->load->view('site_common/template.php',$data);
	}
	
	public function groupcompanies()
	{
		$data['module'] = 'group companies';
	   $pageInfo = getpageinfo(9);
		
		$data['mtitle'] 	  	= $pageInfo->fld_mtitle;
		$data['mdescription'] 	= $pageInfo->fld_mdescription;
		$data['mkeyword'] 		= $pageInfo->fld_mkeyword;
		$data['pagedescription']= $pageInfo->fld_description;
		$data['result'] = $this->catalog_model->generalinfo();
		

		$data['main_content'] = 'group-companies';
		$this->load->view('site_common/template.php',$data);
	}
	
	

	public function himlogistic()
	{
		$data['module'] = 'him-logistic';
		$data['result'] = $this->catalog_model->generalinfo();
		$data['details'] = $this->catalog_model->groupinfo1();	
		$data['main_content'] = 'him-logistic';
		$this->load->view('site_common/template.php',$data);
	}

	public function apacetransport()
	{
		$data['module'] = 'apace-transport';
		$data['result'] = $this->catalog_model->generalinfo();
		$data['details'] = $this->catalog_model->groupinfo2();		

		$data['main_content'] = 'apace-transport';
		$this->load->view('site_common/template.php',$data);
	}

	public function oakshipping()
	{
		$data['module'] = 'oak-shipping';
		$data['result'] = $this->catalog_model->generalinfo();	
		$data['details'] = $this->catalog_model->groupinfo3();	

		$data['main_content'] = 'oak-shipping';
		$this->load->view('site_common/template.php',$data);
	}

	public function winsumholidays()
	{
		$data['module'] = 'winsum-holidays';
		$data['result'] = $this->catalog_model->generalinfo();	
		$data['details'] = $this->catalog_model->groupinfo4();	

		$data['main_content'] = 'winsum-holidays';
		$this->load->view('site_common/template.php',$data);
	}

	public function hlplglobal()
	{
		$data['module'] = 'hlpl-global';
		$data['result'] = $this->catalog_model->generalinfo();
		$data['details'] = $this->catalog_model->groupinfo5();		

		$data['main_content'] = 'hlpl-global';
		$this->load->view('site_common/template.php',$data);
	}


	
	public function category()
	{
		$maincatid =  explode("-",$this->uri->segment(2));
		$maincatid =  end($maincatid);
		
		$data['module'] = 'product_list';
		
		$this->load->model('category_model');
		$data['result'] = $this->category_model->viewrecord($maincatid);
		
		$this->load->model('product_model');
		$data['result_product'] = $this->product_model->viewrecord('','','Active','',$maincatid);
		
		$data['main_content'] = 'product_list';
		$this->load->view('site_common/template.php',$data);
	}
	
}
