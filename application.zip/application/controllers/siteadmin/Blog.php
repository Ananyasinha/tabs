<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller {

  function __construct() {
        parent::__construct();
		error_reporting(0);
		$LoggedIn = $this->session->userdata("adm_logged_in");
        if ($LoggedIn == FALSE) {
            $this->session->set_flashdata("danger", "Invalid Request");
            redirect(base_url()."siteadmin", "refresh");
        }
		$this->load->model('blog_model');
    }
	
	public function index()
	{
		$data['module'] = 'Blog';
		$data['result'] = $this->blog_model->viewrecord();
		$data['main_content'] = 'siteadmin/blog/index';
		$this->load->view('common/home.php',$data);
	}
	
	public function add()
	{
		$data['module'] = 'Add Blog';
		
		$data['main_content'] = 'siteadmin/blog/add';
		$this->load->view('common/home.php',$data);
	
	}


	public function addblog()
	{
		$data = array(
			'title' => $this->input->post('name'),	
			'description' => $this->input->post('description'),
			'blog_date' =>  $this->input->post('date'),
			'created_on' => date("Y-m-d h:i:sa"),
		);

		$result = $this->blog_model->addblog($data);
		if($result > 0)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'New Blog Added Successfully');
			redirect(base_url().'siteadmin/blog');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/blog');
		}
	}


	 public function edit()
	{
		$pageid = $this->uri->segment(4);

		$data['module'] = 'Edit blog';
		$data['pageid'] = $pageid;
		$data['result'] = $this->blog_model->viewdetails($pageid);

		$data['main_content'] = 'siteadmin/blog/edit';
		$this->load->view('common/home.php',$data);
	}
	
	public function update()
	{
	    $id = $this->input->post('pageid');
		$data = array(
			'title' => $this->input->post('name'),	
			'blog_date'=> $this->input->post('date'),	
			'description' => $this->input->post('description'),
		);

		$result = $this->blog_model->updateblog($data,$id);
		if($result > 0)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'Blog Updated Successfully');
			redirect(base_url().'siteadmin/blog');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/blog');
		}
		
	}

	public function delete($id)
	{
		$status = $this->blog_model->deleteblog($id);
		if($status)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'Blog Deteted Successfully');
			redirect(base_url().'siteadmin/blog');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/blog');
		}
		
	}


	

	
}
