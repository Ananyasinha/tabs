<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gallery extends CI_Controller {


    function __construct() {
        parent::__construct();
		error_reporting(0);
		$LoggedIn = $this->session->userdata("adm_logged_in");
        if ($LoggedIn == FALSE) {
            $this->session->set_flashdata("danger", "Invalid Request");
            redirect(base_url()."siteadmin", "refresh");
        }
		$this->load->model('gallery_model');
    }
	
	public function index()
	{
	
		$data['module'] = 'gallery';
		$data['result'] = $this->gallery_model->viewrecord();

		$data['main_content'] = 'siteadmin/gallery/index';
		$this->load->view('common/home.php',$data);
	}
	
public function addgallery()
{
	$title = $this->input->post('title');
    $file_new_name = "";
    $filename      = $_FILES['uploadfile']['name'];
    if ($filename != "" || $filename != null) {
        $temp          = $_FILES['uploadfile']['tmp_name'];
        $file_size     = $_FILES['uploadfile']['size'];
        $ext           = pathinfo($filename, PATHINFO_EXTENSION);
        $base_path     = realpath(dirname(__FILE__) . '/../../../');
        $path          = $base_path . "/assets/galleryimg/";
        $file_new_name = 'ADIMAGE' . date("his"). '.' . $ext;
        $allowed       = array('jpg','jpeg','bmp','gif','png');

        if (!in_array(strtolower($ext), $allowed)) {
            $this->session->set_userdata('alert_type', 'danger');
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be  jpg, jpeg, bmp, gif or png');
            redirect('siteadmin/gallery', 'refresh');
        } elseif (($_FILES['uploadfile']['size'] > 5120000)) {
          $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be less than or equal to 5mb.');
            redirect('siteadmin/gallery', 'refresh');
        }
        move_uploaded_file($temp, $path .$file_new_name);
    }
  
      $data = array(
        'fld_image' => $file_new_name,
        'title'  => $title,
        'fld_addedon' => date("Y-m-d h:i:sa"),
    );

	$status = $this->gallery_model->insertgallery($data);
    if ($status) {
		$this->session->set_userdata('alert_type', 'success');
		$this->session->set_userdata('msg', 'Image Uploaded Successfully');
		redirect(base_url().'siteadmin/gallery');

	} else {
		$this->session->set_userdata('alert_type', 'danger');
		$this->session->set_userdata('msg', 'Oops something went wrong!');
		redirect(base_url().'siteadmin/gallery');
	}
		
}

public function changestatus()
{
    $this->ajax_model->changestatus();
}


public function deletegallery()
    {
   
        $galleryid = $this->uri->segment(4);
        
        $result = $this->gallery_model->deletegallery($galleryid);
        if($result>0)
        {
            $this->session->set_userdata('alert_type', 'success');
            $this->session->set_userdata('msg', 'Image Deleted Successfully');
            redirect(base_url().'siteadmin/gallery');
        }
        else
        {
            $this->session->set_userdata('alert_type', 'danger');
            $this->session->set_userdata('msg', '`Video Not Deleted !');
            redirect(base_url().'siteadmin/gallery');
        }
    }


}