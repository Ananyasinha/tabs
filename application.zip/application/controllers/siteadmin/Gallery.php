<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gallery extends CI_Controller {

	function __construct() {
        parent::__construct();
		error_reporting(0);
		$this->load->model('gallery_model');
    }
	
	public function index()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'Gallery';
			$data['result'] = $this->gallery_model->viewrecord();
			
			$data['main_content'] = 'gallery/index';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function insertfacility()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			if (isset ( $_FILES['file'] ) && $_FILES['file'] ['error'] == 0)
			{	
				$title 	 	= $this->input->post('title');
				$pagename 	= $this->input->post('pagename');
				
				$data = array(
					'fld_addedon'	=>	date('Y-m-d')
				);
				
				$insertid = $this->gallery_model->insertfacility($data);
		
				$this->load->library('image_lib');
			
				$ext = end(explode('.',$_FILES ['file']['name']));
				
				$new_name = "ABSFTGLRY".rand('1000','9999').time() . '.' . $ext; 
				UPLOADDIRPATH.'/assets/gallery/'.$new_name;
										
				$config['upload_path'] = UPLOADDIRPATH.'/assets/gallery/';
				$config['allowed_types'] = 'gif|jpg|png';
				//$config['max_size']	= '100';
				$config['file_name'] = $new_name;
				
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				if ( ! $this->upload->do_upload('file'))
				{
					$error = array('error' => $this->upload->display_errors());
					echo preTagdata($error);
					exit;
				}
				else
				{
					list($w, $h) = getimagesize(UPLOADDIRPATH.'/assets/gallery/'.$new_name);
					
					// START RESIZED IMG
					$n_w = 463; // destination image's width
					$n_h = 427; // destination image's height
					
					$source_ratio = $w / $h;
					$new_ratio = $n_w / $n_h;
					
					
					$config = array();
					
					// create resized image
					$config['image_library'] = 'GD2';
					$config['source_image']	= UPLOADDIRPATH.'/assets/gallery/'.$new_name;
					$config['new_image'] = UPLOADDIRPATH.'/assets/gallery/'.$new_name;
					$config['create_thumb'] = false;
					$config['maintain_ratio'] = true;
					
					if($new_ratio > $source_ratio || (($new_ratio == 1) && ($source_ratio < 1))){
						$config['width'] = $n_w;
						$config['height'] = round($w/$new_ratio);
						$config['y_axis'] = round(($h - $config['height'])/2);
						$config['x_axis'] = 0;
						
					} else {
						
						$config['width'] = round($h * $new_ratio);
						$config['height'] = $n_h;
						$size_config['x_axis'] = round(($w - $config['width'])/2);
						$size_config['y_axis'] = 0;

					}
					
					$this->image_lib->clear();
					$this->image_lib->initialize($config);
					$this->image_lib->resize();
					
					// END RESIZED IMG
					
					
					$data = array(
						'fld_image' =>	$new_name,						
					);
					$this->db->where('id',$insertid);	
					$this->db->update('tbl_gallery',$data);
					
				}
				redirect(base_url().'siteadmin/gallery');
				echo 'Gallery Image Added Successfully';
			}
		}
		else
		{
			echo 'Invalid Access';
		}
	}
	
	public function delete()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$facilityid = $this->uri->segment(4);
			
			$result = $this->gallery_model->deletefacility($facilityid);
			if($result>0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Gallery Image Deleted Successfully');
				redirect(base_url().'siteadmin/gallery');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Gallery Image Not Deleted !');
				redirect(base_url().'siteadmin/gallery');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
}
