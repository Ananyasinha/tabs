<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

	function __construct() {
        parent::__construct();
		error_reporting(0);
		$this->load->model('page_model');
    }
	
	public function index()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'page';
			$data['result'] = $this->page_model->viewrecord();
			
			$data['main_content'] = 'page/index';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function add()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'page';
			$data['result'] = $this->page_model->viewrecord();
			
			$data['main_content'] = 'page/add';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function insertpage()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$title 			= $this->input->post('title');
			$description 	= $this->input->post('description');
			
			$mtitle 		= $this->input->post('mtitle');
			$mdescription 	= $this->input->post('mdescription');
			$mkeyword 		= $this->input->post('mkeyword');
			
			$data = array(
				'fld_title'			=>	$title,
				'fld_description'	=>	$description,
				'fld_mtitle'		=>	$mtitle,
				'fld_mdescription'	=>	$mdescription,
				'fld_mkeyword'		=>	$mkeyword,
				'fld_postedon'		=>	date('Y-m-d H:i:s')
			);
			
			$insertid = $this->page_model->insertpage($data,$title);
			
			if($insertid>0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Page Info. Added Successfully');
				redirect(base_url().'siteadmin/page');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Page Info. Already Exist!');
				redirect(base_url().'siteadmin/page');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function edit()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$pageid = $this->uri->segment(4);
			
			$data['module'] = 'page';
			$data['pageid'] = $pageid;
			$data['result'] = $this->page_model->viewrecord($pageid);
			
			$data['main_content'] = 'page/edit';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function updatepage()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$pageid 		= $this->input->post('pageid');
			$title 			= $this->input->post('title');
			$mtitle 		= $this->input->post('mtitle');
			$mdescription 	= $this->input->post('mdescription');
			$mkeyword 		= $this->input->post('mkeyword');
			
			$data = array(
				'fld_page_title'	=> $title,
				'fld_mtitle'		=> $mtitle,
				'fld_mdescription'	=> $mdescription,
				'fld_mkeyword'		=> $mkeyword
			);
			
			$result = $this->page_model->updatepage($data,$pageid);
			if($result>0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Page Info. Updated Successfully');
				redirect(base_url().'siteadmin/page');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Page Info. Not Updated!');
				redirect(base_url().'siteadmin/page');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function deletepage()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$pageid = $this->uri->segment(4);
			
			$result = $this->page_model->deletepage($pageid);
			if($result>0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Page Info. Deleted Successfully');
				redirect(base_url().'siteadmin/page');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Page Info. Not Deleted !');
				redirect(base_url().'siteadmin/page');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
}
