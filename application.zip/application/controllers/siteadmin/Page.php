<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
        parent::__construct();
		error_reporting(0);
		$this->load->model('page_model');
    }
	
	public function index()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'page';
			$data['result'] = $this->page_model->viewrecord();
			
			$data['main_content'] = 'page/index';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function add()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'page';
			$data['result'] = $this->page_model->viewrecord();
			
			$data['main_content'] = 'page/add';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function insertpage()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$title 			= $this->input->post('title');
			$description 	= $this->input->post('description');
			
			$mtitle 		= $this->input->post('mtitle');
			$mdescription 	= $this->input->post('mdescription');
			$mkeyword 		= $this->input->post('mkeyword');
			
			$data = array(
				'fld_title'			=>	$title,
				'fld_description'	=>	$description,
				'fld_mtitle'		=>	$mtitle,
				'fld_mdescription'	=>	$mdescription,
				'fld_mkeyword'		=>	$mkeyword,
				'fld_postedon'		=>	date('Y-m-d H:i:s')
			);
			
			$insertid = $this->page_model->insertpage($data,$title);
			
			if($insertid>0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Page Info. Added Successfully');
				redirect(base_url().'siteadmin/page');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Page Info. Already Exist!');
				redirect(base_url().'siteadmin/page');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function edit()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$pageid = $this->uri->segment(4);
			
			$data['module'] = 'page';
			$data['pageid'] = $pageid;
			$data['result'] = $this->page_model->viewrecord($pageid);
			
			$data['main_content'] = 'page/edit';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function updatepage()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$pageid 		= $this->input->post('pageid');
			$title 			= $this->input->post('title');
			$description 	= $this->input->post('description');
			$shortdescription 	= $this->input->post('shortdescription');
			
			$mtitle 		= $this->input->post('mtitle');
			$mdescription 	= $this->input->post('mdescription');
			$mkeyword 		= $this->input->post('mkeyword');
			
			$data = array(
				'fld_title'			=>	$title,
				'fld_shortdescription'	=>	$shortdescription,
				'fld_description'	=>	$description,
				'fld_mtitle'		=>	$mtitle,
				'fld_mdescription'	=>	$mdescription,
				'fld_mkeyword'		=>	$mkeyword
			);
			
			$result = $this->page_model->updatepage($data,$pageid);
			if($result>0)
			{
				if (isset ( $_FILES['page_image'] ) && $_FILES['page_image'] ['error'] == 0)
				{
					$this->load->library('image_lib');
					
					$oldpage_image = $this->input->post('oldpage_image');
					if($oldpage_image!="")
					{
						unlink(UPLOADDIRPATH.'/assets/pageimg/'.$oldpage_image);
						unlink(UPLOADDIRPATH.'/assets/pageimg/resized/'.$oldpage_image);
						unlink(UPLOADDIRPATH.'/assets/pageimg/medium/'.$oldpage_image);
					}
					
					$ext = end(explode('.',$_FILES ['page_image']['name']));
					
					$new_name = "ABSFT".rand('1000','9999').time() . '.' . $ext; 
					UPLOADDIRPATH.'/assets/pageimg/'.$new_name;
											
					$config['upload_path'] = UPLOADDIRPATH.'/assets/pageimg/';
					$config['allowed_types'] = 'gif|jpg|png';
					//$config['max_size']	= '100';
					$config['file_name'] = $new_name;
					
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if ( ! $this->upload->do_upload('page_image'))
					{
						$error = array('error' => $this->upload->display_errors());
						echo preTagdata($error);
						exit;
					}
					else
					{
						list($w, $h) = getimagesize(UPLOADDIRPATH.'/assets/pageimg/'.$new_name);
						
						// START RESIZED IMG
						$n_w = 349; // destination image's width
						$n_h = 244; // destination image's height
						
						$source_ratio = $w / $h;
						$new_ratio = $n_w / $n_h;
						
						
						$config = array();
						
						// create resized image
						$config['image_library'] = 'GD2';
						$config['source_image']	= UPLOADDIRPATH.'/assets/pageimg/'.$new_name;
						$config['new_image'] = UPLOADDIRPATH.'/assets/pageimg/'.$new_name;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = true;
						
						if($new_ratio > $source_ratio || (($new_ratio == 1) && ($source_ratio < 1)))
						{
							$config['width'] = $n_w;
							$config['height'] = round($w/$new_ratio);
							$config['y_axis'] = round(($h - $config['height'])/2);
							$config['x_axis'] = 0;

						} else {

							$config['width'] = round($h * $new_ratio);
							$config['height'] = $n_h;
							$size_config['x_axis'] = round(($w - $config['width'])/2);
							$size_config['y_axis'] = 0;

						}
						
						$this->image_lib->clear();
						$this->image_lib->initialize($config);
						$this->image_lib->resize();
						
						// END RESIZED IMG
						
						
						$data = array(
							'fld_image' =>	$new_name,						
						);
						$this->db->where('id',$pageid);	
						$this->db->update('tbl_page',$data);
					}
				}
				
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Page Info. Updated Successfully');
				redirect(base_url().'siteadmin/page');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Page Info. Not Updated!');
				redirect(base_url().'siteadmin/page');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function deletepage()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$pageid = $this->uri->segment(4);
			
			$result = $this->page_model->deletepage($pageid);
			if($result>0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Page Info. Deleted Successfully');
				redirect(base_url().'siteadmin/page');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Page Info. Not Deleted !');
				redirect(base_url().'siteadmin/page');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
}
