<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Courses extends CI_Controller {

	function __construct() {
        parent::__construct();
		error_reporting(1);
		$LoggedIn = $this->session->userdata("adm_logged_in");
        if ($LoggedIn == FALSE) {
            $this->session->set_flashdata("danger", "Invalid Request");
            redirect(base_url()."siteadmin", "refresh");
          
        }
		$this->load->model('courses_model');
    }
	
	public function index()
	{

		$data['module'] = 'Courses';
		$data['result'] = $this->courses_model->viewrecord();

		$data['main_content'] = 'siteadmin/courses/index';
	    $this->load->view('common/home.php',$data);
	
	}



	public function add()
	{
		$data['module'] = 'Add Course';
		
		$data['main_content'] = 'siteadmin/courses/add';
		$this->load->view('common/home.php',$data);
	}


	public function addCourse()
	{
		$subname = $this->input->post('addmore');	

		$data = array(
			'course_name' => $this->input->post('coursename'),	
			'description' => $this->input->post('description'),
			'fees' =>  $this->input->post('fees'),
			'created_on' => date("Y-m-d h:i:sa"),
		);

		$result = $this->courses_model->addcourse($data ,$subname);
		if($result > 0)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'New Course Added Successfully');
			redirect(base_url().'siteadmin/courses');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/courses');
		}
	}
	

    public function edit()
	{
		$pageid = $this->uri->segment(4);

		$data['module'] = 'Edit Course';
		$data['pageid'] = $pageid;
		$data['result'] = $this->courses_model->viewdetails($pageid);
		$data['subresult'] = $this->courses_model->subrecord($pageid);

		//print_r($data['subresult']);die();

		$data['main_content'] = 'siteadmin/courses/edit';
		$this->load->view('common/home.php',$data);
	}
	
	public function updatecourse()
	{
		$pageid  = $this->input->post('pageid');
		$subname = $this->input->post('addmore');	

		$data = array(
			'course_name' => $this->input->post('coursename'),	
			'description' => $this->input->post('description'),
			'fees' =>  $this->input->post('fees'),
			'created_on' => date("Y-m-d h:i:sa"),
		);

		if(count($subname)!=0){
            for($i=0; $i< count($subname); $i++){
            
            $details[] = array(
                 'course_id' => $pageid,
                 'sub_course_name'=>$subname[$i],
            );
        }}


		$result = $this->courses_model->updatecourse($data ,$details,$pageid);
		if($result)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'New Course Added Successfully');
			redirect(base_url().'siteadmin/courses');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/courses');
		}
		
	}

	public function delete($id)
	{
		$status = $this->courses_model->deletecourse($id);
		if($status)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'Course Deteted Successfully');
			redirect(base_url().'siteadmin/courses');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/courses');
		}
		
	}


	/*Sub Courses*/

	public function subcourse()
	{
        $pageid = $this->uri->segment(4);
		$data['module'] = 'Sub Courses';
		$data['pageid'] = $pageid;
		$data['result'] = $this->courses_model->subdetails($pageid);

		$data['main_content'] = 'siteadmin/courses/courselist';
	    $this->load->view('common/home.php',$data);
	}


/*edit sub courses*/
	public function editsub()
	{
	
		$pageid = $this->uri->segment(4);

		$data['module'] = 'Edit Sub Course';
		$data['pageid'] = $pageid;
		$data['result'] = $this->courses_model->subcoursedetails($pageid);
		$data['subresult'] = $this->courses_model->coursedetails($pageid);

		$data['main_content'] = 'siteadmin/courses/subedit';
		$this->load->view('common/home.php',$data);
	}

	
	public function updatesubcourse()
	{
		$pageid  = $this->input->post('pageid');
		$subname = $this->input->post('addmore');	

		$data = array(
			'sub_course_name' => $this->input->post('coursename'),	
			'sub_description' => $this->input->post('description'),
			'sub_fees' =>  $this->input->post('fees'),
		);

		if(count($subname)!=0){
            for($i=0; $i< count($subname); $i++){
            
            $details[] = array(
                 'sub_course_id' => $pageid,
                 'sub_course_name'=>$subname[$i],
            );
        }}


		$result = $this->courses_model->subcourse($data ,$details,$pageid);
		if($result)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', ' Course updates Successfully');
			redirect(base_url().'siteadmin/courses');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/courses');
		}
	
	}

	public function deletesub($id)
	{
		$status = $this->courses_model->deletesub($id);
		if($status)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'Sub Course Deteted Successfully');
			redirect(base_url().'siteadmin/courses');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/courses');
		}
		
	}

		

	
	
}
