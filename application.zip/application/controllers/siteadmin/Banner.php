<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner extends CI_Controller {


	function __construct() {
        parent::__construct();
		error_reporting(0);
		$LoggedIn = $this->session->userdata("adm_logged_in");
        if ($LoggedIn == FALSE) {
            $this->session->set_flashdata("danger", "Invalid Request");
            redirect(base_url()."siteadmin", "refresh");
        }
		$this->load->model('banner_model');
    }
	
	
	public function index()
	{
	
		$data['module'] = 'Manage Banner';
		$data['result'] = $this->banner_model->viewrecord();

		$data['main_content'] = 'siteadmin/manage_banner.php';
	    $this->load->view('common/home.php',$data);
	}

	public function add()
	{
	
		$data['module'] = 'Manage add';
		$data['result'] = $this->banner_model->viewrecord();

		$data['main_content'] = 'siteadmin/add_banner.php';
	    $this->load->view('common/home.php',$data);
	}


public function upload() 
{
	$id = 1;
	$type = $this->input->post('banner-type');

    $file_new_name = "";
    $filename      = $_FILES['uploadfile']['name'];
    if ($filename != "" || $filename != null) {
        $temp          = $_FILES['uploadfile']['tmp_name'];
        $file_size     = $_FILES['uploadfile']['size'];
        $ext           = pathinfo($filename, PATHINFO_EXTENSION);
        $base_path     = realpath(dirname(__FILE__) . '/../../../');
        $path          = $base_path . "/assets/media/banner/";
        $file_new_name = rand('11111','99999').'-'.time().'.'.$ext;
        $allowed       = array('jpg','jpeg','bmp','gif','png');
        
        if (!in_array(strtolower($ext), $allowed)) {
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be  jpg, jpeg, bmp, gif or png');
            redirect('banner', 'refresh');
        } elseif (($_FILES['uploadfile']['size'] > 5120000)) {
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be less than or equal to 5mb.');
            redirect('banner', 'refresh');
        }
        move_uploaded_file($temp, $path . $file_new_name);
    }

    $file_new_name1 = "";
    $filename1      = $_FILES['uploadfile1']['name'];

    if ($filename1 != "" || $filename1 != null) {
        $temp          = $_FILES['uploadfile1']['tmp_name'];
        $file_size     = $_FILES['uploadfile1']['size'];
        $ext           = pathinfo($filename, PATHINFO_EXTENSION);
        $base_path     = realpath(dirname(__FILE__) . '/../../../');
        $path          = $base_path . "/assets/media/banner/";
        $file_new_name1 = rand('11111','99999').'-'.time().'.'.$ext;
        $allowed       = array('jpg','jpeg','bmp','gif','png');
        
        if (!in_array(strtolower($ext), $allowed)) {
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be  jpg, jpeg, bmp, gif or png');
            redirect('banner', 'refresh');
        } elseif (($_FILES['uploadfile1']['size'] > 5120000)) {
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be less than or equal to 5mb.');
            redirect('banner', 'refresh');
        }
        move_uploaded_file($temp, $path . $file_new_name1);
    }

      $data = array(
        'image' => $file_new_name,
        'sideimage' => $file_new_name1,
        'type' => $type,
        'title' => $this->input->post('title'),
        'status' => 1, //active
    );

	$status = $this->banner_model->addbanner($data);
    if ($status) {
		$this->session->set_userdata('alert_type', 'success');
		$this->session->set_userdata('msg', 'Banner Updated Successfully');
		redirect(base_url().'siteadmin/banner');

	} else {
		$this->session->set_userdata('alert_type', 'danger');
		$this->session->set_userdata('msg', 'Banner Not Updated!');
		redirect(base_url().'siteadmin/banner');
	}

}


	public function delete($id)
	{
		$status = $this->banner_model->delete($id);
		if($status)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'Banner Deteted Successfully');
			redirect(base_url().'siteadmin/banner');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/exam');
		}
		
	}


}
