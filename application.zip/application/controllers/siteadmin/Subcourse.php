<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subcourse extends CI_Controller {

	function __construct() {
        parent::__construct();
		error_reporting(1);
		$this->load->model('subcourses_model');
    }
	
	public function index()
	{

		/*$data['main_content'] = 'siteadmin/courses/index';
		$this->load->view('common/home.php',$data);*/

		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'Courses';
			$data['result'] = $this->subcourses_model->viewrecord();

			$data['main_content'] = 'siteadmin/subcourse/index';
		    $this->load->view('common/home.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}


	public function subcourse()
	{

		$data['module'] = 'Courses';
		$data['result'] = $this->courses_model->viewrecord();

		$data['main_content'] = 'siteadmin/courses/index';
	    $this->load->view('common/home.php',$data);
		
	}
	
	
	public function add()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'Add Course';
			
			$data['main_content'] = 'siteadmin/courses/add';
			$this->load->view('common/home.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}


	public function addCourse()
	{
		$subname = $this->input->post('addmore');	

		$data = array(
			'course_name' => $this->input->post('coursename'),	
			'description' => $this->input->post('description'),
			'fees' =>  $this->input->post('fees'),
			'created_on' => date("Y-m-d h:i:sa"),
		);

		$result = $this->courses_model->addcourse($data ,$subname);
		if($result > 0)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'New Course Added Successfully');
			redirect(base_url().'siteadmin/courses');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/courses');
		}
	}
	

public function edit()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$pageid = $this->uri->segment(4);

			$data['module'] = 'Edit Course';
			$data['pageid'] = $pageid;
			$data['result'] = $this->courses_model->viewdetails($pageid);

			$data['main_content'] = 'siteadmin/courses/edit';
			$this->load->view('common/home.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function updatepage()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$subname = $this->input->post('addmore');	

			$data = array(
				'course_name' => $this->input->post('coursename'),	
				'description' => $this->input->post('description'),
				'fees' =>  $this->input->post('fees'),
				'created_on' => date("Y-m-d h:i:sa"),
			);

			$result = $this->courses_model->addcourse($data ,$subname);
			if($result > 0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'New Course Added Successfully');
				redirect(base_url().'siteadmin/courses');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
				redirect(base_url().'siteadmin/courses');
			}
		}else{
			redirect(base_url().'siteadmin');
		}
	}



	
}
