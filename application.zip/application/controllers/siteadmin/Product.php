<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
        parent::__construct();
		error_reporting(0);
		$this->load->model('product_model');
    }
	
	public function index()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'product';
			$data['result'] = $this->product_model->viewrecord();
			
			$data['main_content'] = 'product/index';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function add()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'product';
			$data['result'] = $this->product_model->viewrecord();
			
			$data['main_content'] = 'product/add';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function insertproduct()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$categoryid 	= $this->input->post('categoryid');
			$subcategoryid 	= $this->input->post('subcategoryid');
			
			$title 			= $this->input->post('title');
			$description 	= $this->input->post('description');
			
			$mtitle 		= $this->input->post('mtitle');
			$mdescription 	= $this->input->post('mdescription');
			$mkeyword 		= $this->input->post('mkeyword');
			
			//echo preTagdata($_REQUEST);
			//exit;
			
			$data = array(
				'fld_categoryid'		=>	$categoryid,
				'fld_subcategoryid'		=>	$subcategoryid,
				'fld_mtitle'			=>	$mtitle,
				'fld_mdescription'		=>	$mdescription,
				'fld_mkeyword'			=>	$mkeyword,
				'fld_title'				=>	$title,
				'fld_description'		=>	$description,
				'fld_addedon'			=>	date('Y-m-d H:i:s')
			);
			
			$insertid = $this->product_model->insertproduct($data,$title);
			
			if($insertid>0)
			{
				$this->load->library('image_lib');
				
				if (isset ( $_FILES['product_image'] ) && $_FILES['product_image'] ['error'] == 0)
				{
					$ext = end(explode('.',$_FILES ['product_image']['name']));
					
					$new_name = "AABTPRD".rand('1000','9999').time() . '.' . $ext; 
					UPLOADDIRPATH.'/assets/productimg/'.$new_name;
											
					$config['upload_path'] = UPLOADDIRPATH.'/assets/productimg/';
					$config['allowed_types'] = 'gif|jpg|png';
					//$config['max_size']	= '100';
					$config['file_name'] = $new_name;
					
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if ( ! $this->upload->do_upload('product_image'))
					{
						$error = array('error' => $this->upload->display_errors());
						echo preTagdata($error);
						exit;
					}
					else
					{
						list($w, $h) = getimagesize(UPLOADDIRPATH.'/assets/productimg/'.$new_name);
						
						// START SMALL IMG
						$n_w = 277; // destination image's width
						$n_h = 205; // destination image's height
						
						$source_ratio = $w / $h;
						$new_ratio = $n_w / $n_h;
						
						
						$config = array();
						
						// create resized image
						$config['image_library'] = 'GD2';
						$config['source_image']	= UPLOADDIRPATH.'/assets/productimg/'.$new_name;
						$config['new_image'] = UPLOADDIRPATH.'/assets/productimg/'.$new_name;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = true;
						
						if($new_ratio > $source_ratio || (($new_ratio == 1) && ($source_ratio < 1))){
							$config['width'] = $n_w;
							$config['height'] = round($w/$new_ratio);
							$config['y_axis'] = round(($h - $config['height'])/2);
							$config['x_axis'] = 0;
							
						} else {
							
							$config['width'] = round($h * $new_ratio);
							$config['height'] = $n_h;
							$size_config['x_axis'] = round(($w - $config['width'])/2);
							$size_config['y_axis'] = 0;

						}
						
						$this->image_lib->clear();
						$this->image_lib->initialize($config);
						$this->image_lib->resize();
						
						// END SMALL IMG
						
						
						$data = array(
							'fld_image' =>	$new_name,						
						);
						$this->db->where('id',$insertid);	
						$this->db->update('tbl_product',$data);
					}
					
				}
				
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Product Info. Added Successfully');
				redirect(base_url().'siteadmin/product');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Product Info. Already Exist!');
				redirect(base_url().'siteadmin/product');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function edit()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$productid = $this->uri->segment(4);
			
			$data['module'] = 'product';
			$data['productid'] = $productid;
			$data['result'] = $this->product_model->viewrecord($productid);
			
			$data['main_content'] = 'product/edit';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function updateproduct()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$categoryid 	= $this->input->post('categoryid');
			$subcategoryid 	= $this->input->post('subcategoryid');
			
			$productid 		= $this->input->post('productid');
			$title 				= $this->input->post('title');
			$author_name 		= $this->input->post('author_name');
			$shortdescription 	= $this->input->post('shortdescription');
			$description 		= $this->input->post('description');
			
			$mtitle 		= $this->input->post('mtitle');
			$mdescription 	= $this->input->post('mdescription');
			$mkeyword 		= $this->input->post('mkeyword');
			
			//echo preTagdata($_REQUEST);
			//exit;
			
			$data = array(
				'fld_categoryid'		=>	$categoryid,
				'fld_subcategoryid'		=>	$subcategoryid,
				'fld_mtitle'			=>	$mtitle,
				'fld_mdescription'		=>	$mdescription,
				'fld_mkeyword'			=>	$mkeyword,
				'fld_title'				=>	$title,
				'fld_description'		=>	$description,
			);
			
			$result = $this->product_model->updateproduct($data,$productid);
			if($result>0)
			{
				$this->load->library('image_lib');
				
				if (isset ( $_FILES['product_image'] ) && $_FILES['product_image'] ['error'] == 0)
				{
					$oldproduct_image = $this->input->post('oldproduct_image');
					if($oldproduct_image!="")
					{
						unlink(UPLOADDIRPATH.'/assets/productimg/'.$oldproduct_image);
					}
					
					$ext = end(explode('.',$_FILES ['product_image']['name']));
					
					$new_name = "AABTPRD".rand('1000','9999').time() . '.' . $ext; 
					UPLOADDIRPATH.'/assets/productimg/'.$new_name;
											
					$config['upload_path'] = UPLOADDIRPATH.'/assets/productimg/';
					$config['allowed_types'] = 'gif|jpg|png';
					//$config['max_size']	= '100';
					$config['file_name'] = $new_name;
					
					$this->load->library('upload', $config);
					$this->upload->initialize($config);
					if ( ! $this->upload->do_upload('product_image'))
					{
						$error = array('error' => $this->upload->display_errors());
						echo preTagdata($error);
						exit;
					}
					else
					{
						list($w, $h) = getimagesize(UPLOADDIRPATH.'/assets/productimg/'.$new_name);
						
						// START SMALL IMG
						$n_w = 277; // destination image's width
						$n_h = 205; // destination image's height
						
						$source_ratio = $w / $h;
						$new_ratio = $n_w / $n_h;
						
						
						$config = array();
						
						// create resized image
						$config['image_library'] = 'GD2';
						$config['source_image']	= UPLOADDIRPATH.'/assets/productimg/'.$new_name;
						$config['new_image'] = UPLOADDIRPATH.'/assets/productimg/'.$new_name;
						$config['create_thumb'] = false;
						$config['maintain_ratio'] = true;
						
						if($new_ratio > $source_ratio || (($new_ratio == 1) && ($source_ratio < 1)))
						{
							$config['width'] = $n_w;
							$config['height'] = round($w/$new_ratio);
							$config['y_axis'] = round(($h - $config['height'])/2);
							$config['x_axis'] = 0;

						} else {

							$config['width'] = round($h * $new_ratio);
							$config['height'] = $n_h;
							$size_config['x_axis'] = round(($w - $config['width'])/2);
							$size_config['y_axis'] = 0;

						}
						
						$this->image_lib->clear();
						$this->image_lib->initialize($config);
						$this->image_lib->resize();
						
						// END SMALL IMG
						
						$data = array(
							'fld_image' =>	$new_name,						
						);
						$this->db->where('id',$productid);	
						$this->db->update('tbl_product',$data);
					}
				}
				
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Product Info. Updated Successfully');
				redirect(base_url().'siteadmin/product');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Product Info. Not Updated!');
				redirect(base_url().'siteadmin/product');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function deleteproduct()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$productid = $this->uri->segment(4);
			
			$result = $this->product_model->deleteproduct($productid);
			if($result>0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Product Info. Deleted Successfully');
				redirect(base_url().'siteadmin/product');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Product Info. Not Deleted !');
				redirect(base_url().'siteadmin/product');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
}
