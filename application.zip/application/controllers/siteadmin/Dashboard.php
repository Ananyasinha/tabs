<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct() {
        parent::__construct();
		error_reporting(0);
    }
	
	public function index()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'dashboard';
			
			$data['main_content'] = 'dashboard';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function logout()
	{
		$this->session->unset_userdata('adm_logged_in');
		redirect(base_url().'siteadmin');
		exit;
	}
	
}
