<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Exam extends CI_Controller {


    function __construct() {
        parent::__construct();
		error_reporting(0);
		$LoggedIn = $this->session->userdata("adm_logged_in");
        if ($LoggedIn == FALSE) {
            $this->session->set_flashdata("danger", "Invalid Request");
            redirect(base_url()."siteadmin", "refresh");
        }
		$this->load->model('exam_model');
    }
	
	public function index()
	{
		$data['module'] = 'Exam';
		$data['result'] = $this->exam_model->viewrecord();
		$data['main_content'] = 'siteadmin/exam/index';
		$this->load->view('common/home.php',$data);
	}
	
	public function add()
	{
		$data['module'] = 'Add Exam';
		$data['main_content'] = 'siteadmin/exam/add';
		$this->load->view('common/home.php',$data);
	}
	

	public function addExam()
	{
		$subname = $this->input->post('addmore');	
		$data = array(
			'exam_name' => $this->input->post('examname'),	
			'description' => $this->input->post('description'),
			'fees' =>  $this->input->post('exam_fees'),
			'created_on' => date("Y-m-d h:i:sa"),
		);

		$result = $this->exam_model->addExam($data ,$subname);
		if($result > 0)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'New Exam Added Successfully');
			redirect(base_url().'siteadmin/exam');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/exam');
		}
	}


	 public function edit()
	{
		$pageid = $this->uri->segment(4);

		$data['module'] = 'Edit Exam';
		$data['pageid'] = $pageid;
		$data['result'] = $this->exam_model->viewdetails($pageid);

		$data['subresult'] = $this->exam_model->subrecord($pageid);

		$data['main_content'] = 'siteadmin/exam/edit';
		$this->load->view('common/home.php',$data);
	}
	
	public function updateexam()
	{
		$pageid  = $this->input->post('pageid');
		$subname = $this->input->post('addmore');	

		$data = array(
			'exam_name' => $this->input->post('examname'),	
			'description' => $this->input->post('description'),
			'fees' =>  $this->input->post('fees'),
			'created_on' => date("Y-m-d h:i:sa"),
		);

		if(count($subname)!=0){
            for($i=0; $i< count($subname); $i++){
            
            $details[] = array(
                 'exam_id' => $pageid,
                 'sub_exam_name'=>$subname[$i],
            );
        }}


		$result = $this->exam_model->updatecourse($data ,$details,$pageid);
		if($result)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'Exam Updated Successfully');
			redirect(base_url().'siteadmin/exam');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/exam');
		}
		
	}

	public function delete($id)
	{
		$status = $this->exam_model->deletecourse($id);
		if($status)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'Exam Deteted Successfully');
			redirect(base_url().'siteadmin/exam');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/exam');
		}
		
	}


	/*Sub exam*/

	public function subexam()
	{
        $pageid = $this->uri->segment(4);
		$data['module'] = 'Sub exam';
		$data['pageid'] = $pageid;
		$data['result'] = $this->exam_model->subdetails($pageid);
        //$data['subresult'] = $this->exam_model->examdetails($pageid);

		$data['main_content'] = 'siteadmin/exam/examlist';
	    $this->load->view('common/home.php',$data);
	}


/*edit sub exam*/
	public function editsub()
	{
	
		$pageid = $this->uri->segment(4);

		$data['module'] = 'Edit Sub Exam';
		$data['pageid'] = $pageid;
		$data['result'] = $this->exam_model->subexamdetails($pageid);
	
		$data['main_content'] = 'siteadmin/exam/subedit';
		$this->load->view('common/home.php',$data);
	}

	
	public function updatesubexam()
	{
	$pageid  = $this->input->post('pageid');
		$data = array(
			'sub_exam_name' => $this->input->post('exam'),	
			'sub_description' => $this->input->post('description'),
			'sub_fees' =>  $this->input->post('fees'),
		);

		$result = $this->exam_model->examupdate($data,$pageid);
		if($result)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'New Exam Added Successfully');
			redirect(base_url().'siteadmin/exam');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/exam');
		}
	
	}

	public function deletesub($id)
	{
		$status = $this->exam_model->deletesub($id);
		if($status)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'Sub Exam Deteted Successfully');
			redirect(base_url().'siteadmin/exam');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/exam');
		}
		
	}
	
}
