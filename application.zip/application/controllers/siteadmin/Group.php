<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//group Companies managment

class Group extends CI_Controller {


    function __construct() {
        parent::__construct();
		error_reporting(0);
		$LoggedIn = $this->session->userdata("adm_logged_in");
        if ($LoggedIn == FALSE) {
            $this->session->set_flashdata("danger", "Invalid Request");
            redirect(base_url()."siteadmin", "refresh");
        }
		$this->load->model('group_model');
    }
	
	public function index()
	{
		$data['module'] = 'Group';
		$data['result'] = $this->group_model->viewrecord();
		$data['main_content'] = 'siteadmin/group/index';
		$this->load->view('common/home.php',$data);
	}

	public function add()
	{
		$data['module'] = 'Add group';
		$data['main_content'] = 'siteadmin/group/add';
		$this->load->view('common/home.php',$data);
	}
	

	public function addgroup()
	{	
		$name = $this->input->post('groupname');
		$file_new_name = "";
		$filename      = $_FILES['uploadfile']['name'];
		if ($filename != "" || $filename != null) {
		    $temp          = $_FILES['uploadfile']['tmp_name'];
		    $file_size     = $_FILES['uploadfile']['size'];
		    $ext           = pathinfo($filename, PATHINFO_EXTENSION);
		    $base_path     = realpath(dirname(__FILE__) . '/../../../');
		    $path          = $base_path . "/assets/media/group/";
		    $file_new_name = $name. date("his").'.'. $ext;
		    $allowed       = array('jpg','jpeg','bmp','gif','png');
		    
		    if (!in_array(strtolower($ext), $allowed)) {
		        $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be  jpg, jpeg, bmp, gif or png');
		        redirect('group', 'refresh');
		    } elseif (($_FILES['uploadfile']['size'] > 5120000)) {
		        $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be less than or equal to 5mb.');
		        redirect('group', 'refresh');
		    }
		    move_uploaded_file($temp, $path . $file_new_name);
		}
		$data = array(
			'group_name' =>$name,	
			'description' => $this->input->post('description'),
			'image' =>  $file_new_name,
			'created_on' => date("Y-m-d h:i:sa"),
		);

		$result = $this->group_model->addgroup($data ,$subname);
		if($result > 0)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'New group Added Successfully');
			redirect(base_url().'siteadmin/group');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/group');
		}
	}


	 public function edit()
	{
		$pageid = $this->uri->segment(4);

		$data['module'] = 'Edit group';
		$data['pageid'] = $pageid;
		$data['result'] = $this->group_model->viewdetails($pageid);

		$data['main_content'] = 'siteadmin/group/edit';
		$this->load->view('common/home.php',$data);
	}
	
	public function updategroup()
	{
		$pageid  = $this->input->post('pageid');
		$name =$this->input->post('companyname'); 
		$data = array(
			'name' => $name,	
			'title'  => $this->input->post('companytitle'),	
			'grp_content' => $this->input->post('description'),
			'created_on' => date("Y-m-d h:i:sa"),
		);

		$result = $this->group_model->updategroup($data,$pageid);
		if($result > 0)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', $name.' '.'Details Updated Successfully');
			redirect(base_url().'siteadmin/group');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/group');
		}
		
	}

	public function delete($id)
	{
		$status = $this->group_model->delete($id);
		if($status)
		{
			$this->session->set_userdata('alert_type', 'success');
			$this->session->set_userdata('msg', 'group Deteted Successfully');
			redirect(base_url().'siteadmin/group');
		}
		else
		{
			$this->session->set_userdata('alert_type', 'danger');
			$this->session->set_userdata('msg', 'Oops somthing went wrong..!');
			redirect(base_url().'siteadmin/group');
		}
	}
	
}
