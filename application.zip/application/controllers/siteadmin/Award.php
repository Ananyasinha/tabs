<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*manange movie*/
class Award extends CI_Controller {

	function __construct() {
        parent::__construct();
		error_reporting(0);
		$this->load->model('award_model');
    }
	
	public function index()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$data['module'] = 'award';
			$data['result'] = $this->award_model->viewrecord();
			
			$data['main_content'] = 'award/index';
			$this->load->view('siteadmin/common/template.php',$data);
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
	
	public function insertaward()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			if (isset ( $_FILES['file'] ) && $_FILES['file'] ['error'] == 0)
			{	
				$title 	 	= $this->input->post('title');
				$pagename 	= $this->input->post('pagename');
				
				$data = array(
					'fld_addedon'	=>	date('Y-m-d')
				);
				
				$insertid = $this->award_model->insertaward($data);
		
		
				$this->load->library('image_lib');
			
			
				$ext = end(explode('.',$_FILES ['file']['name']));
				
				$new_name = "ABSFTGLRY".rand('1000','9999').time() . '.' . $ext; 
				UPLOADDIRPATH.'/assets/awardimg/'.$new_name;
										
				$config['upload_path'] = UPLOADDIRPATH.'/assets/awardimg/';
				$config['allowed_types'] = 'gif|jpg|png';
				//$config['max_size']	= '100';
				$config['file_name'] = $new_name;
				
				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				if ( ! $this->upload->do_upload('file'))
				{
					$error = array('error' => $this->upload->display_errors());
					echo preTagdata($error);
					exit;
				}
				else
				{
					list($w, $h) = getimagesize(UPLOADDIRPATH.'/assets/awardimg/'.$new_name);
					
					// START RESIZED IMG
					$n_w = 522; // destination image's width
					$n_h = 351; // destination image's height
					
					$source_ratio = $w / $h;
					$new_ratio = $n_w / $n_h;
					
					
					$config = array();
					
					// create resized image
					$config['image_library'] = 'GD2';
					$config['source_image']	= UPLOADDIRPATH.'/assets/awardimg/'.$new_name;
					$config['new_image'] = UPLOADDIRPATH.'/assets/awardimg/'.$new_name;
					$config['create_thumb'] = false;
					$config['maintain_ratio'] = true;
					
					if($new_ratio > $source_ratio || (($new_ratio == 1) && ($source_ratio < 1))){
						$config['width'] = $n_w;
						$config['height'] = round($w/$new_ratio);
						$config['y_axis'] = round(($h - $config['height'])/2);
						$config['x_axis'] = 0;
						
					} else {
						
						$config['width'] = round($h * $new_ratio);
						$config['height'] = $n_h;
						$size_config['x_axis'] = round(($w - $config['width'])/2);
						$size_config['y_axis'] = 0;

					}
					
					$this->image_lib->clear();
					$this->image_lib->initialize($config);
					$this->image_lib->resize();
					
					// END RESIZED IMG
					
					
					$data = array(
						'fld_image' =>	$new_name,						
					);
					$this->db->where('id',$insertid);	
					$this->db->update('tbl_award',$data);
				}
				
				echo 'Award Image Added Successfully';
			}
		}
		else
		{
			echo 'Invalid Access';
		}
	}
	
	public function deleteaward()
	{
		if($this->session->userdata('adm_logged_in') == true)
		{
			$awardid = $this->uri->segment(4);
			
			$result = $this->award_model->deleteaward($awardid);
			if($result>0)
			{
				$this->session->set_userdata('alert_type', 'success');
				$this->session->set_userdata('msg', 'Award Image Deleted Successfully');
				redirect(base_url().'siteadmin/award');
			}
			else
			{
				$this->session->set_userdata('alert_type', 'danger');
				$this->session->set_userdata('msg', 'Award Image Not Deleted !');
				redirect(base_url().'siteadmin/award');
			}
		}
		else
		{
			redirect(base_url().'siteadmin');
		}
	}
}
