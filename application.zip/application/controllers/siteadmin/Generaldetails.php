<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Generaldetails extends CI_Controller {


	function __construct() {
        parent::__construct();
		error_reporting(0);
		$LoggedIn = $this->session->userdata("adm_logged_in");
        if ($LoggedIn == FALSE) {
            $this->session->set_flashdata("danger", "Invalid Request");
            redirect(base_url()."siteadmin", "refresh");
        }
		$this->load->model('general_model');
    }
	
	
	public function index()
	{
	
		$data['module'] = 'General Details';
		$data['result'] = $this->general_model->viewrecord();

		$data['main_content'] = 'siteadmin/general-details';
	    $this->load->view('common/home.php',$data);
	}


public function updatelogo() 
{
	$id = 1;
    $file_new_name = "";
    $filename      = $_FILES['uploadfile']['name'];
    if ($filename != "" || $filename != null) {
        $temp          = $_FILES['uploadfile']['tmp_name'];
        $file_size     = $_FILES['uploadfile']['size'];
        $ext           = pathinfo($filename, PATHINFO_EXTENSION);
        $base_path     = realpath(dirname(__FILE__) . '/../../../');
        $path          = $base_path . "/assets/media/";
        $file_new_name = 'logo'. '.' . $ext;
        $allowed       = array('jpg','jpeg','bmp','gif','png');
        
        if (!in_array(strtolower($ext), $allowed)) {
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be  jpg, jpeg, bmp, gif or png');
            redirect('generaldetails', 'refresh');
        } elseif (($_FILES['uploadfile']['size'] > 5120000)) {
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be less than or equal to 5mb.');
            redirect('generaldetails', 'refresh');
        }
        move_uploaded_file($temp, $path . $file_new_name);
    }

      $data = array(
        'logo' => $file_new_name,
    );

	$status = $this->general_model->updatelogo($data,$id);
    if ($status) {
		$this->session->set_userdata('alert_type', 'success');
		$this->session->set_userdata('msg', 'Logo Updated Successfully');
		redirect(base_url().'siteadmin/generaldetails');

	} else {
		$this->session->set_userdata('alert_type', 'danger');
		$this->session->set_userdata('msg', 'Logo Not Updated!');
		redirect(base_url().'siteadmin/generaldetails');
	}

}



public function updatefavicon() 
{
	$id = 1;
    $file_new_name = "";
    $filename      = $_FILES['uploadfile']['name'];
    if ($filename != "" || $filename != null) {
        $temp          = $_FILES['uploadfile']['tmp_name'];
        $file_size     = $_FILES['uploadfile']['size'];
        $ext           = pathinfo($filename, PATHINFO_EXTENSION);
        $base_path     = realpath(dirname(__FILE__) . '/../../../');
        $path          = $base_path . "/assets/media/";
        $file_new_name = 'favicon'.'.' . $ext;
        $allowed       = array('jpg','jpeg','bmp','gif','png');
        
        if (!in_array(strtolower($ext), $allowed)) {
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be  jpg, jpeg, bmp, gif or png');
            redirect('generaldetails', 'refresh');
        } elseif (($_FILES['uploadfile']['size'] > 5120000)) {
            $this->session->set_flashdata('danger', 'Image Uploading failed.<br/>Image should be less than or equal to 5mb.');
            redirect('generaldetails', 'refresh');
        }
        move_uploaded_file($temp, $path . $file_new_name);
    }

      $data = array(
        'logo' => $file_new_name,
    );

	$status = $this->general_model->updatelogo($data,$id);
    if ($status) {
		$this->session->set_userdata('alert_type', 'success');
		$this->session->set_userdata('msg', 'Favicon Updated Successfully');
		redirect(base_url().'siteadmin/generaldetails');

	} else {
		$this->session->set_userdata('alert_type', 'danger');
		$this->session->set_userdata('msg', 'Favicon Not Updated!');
		redirect(base_url().'siteadmin/generaldetails');
	}

}


 public function updateDetails()
{
	$id=1;

	$contact   = $this->input->post('contact');
    $alt_phone = $this->input->post('altcontact');
    $email     = $this->input->post('email');
    $copyright = $this->input->post('copyright');
    $address   = $this->input->post('address');

	$data = array(
		'contact'	=>	$contact,
		'alt_phone'	=>	$alt_phone,
		'email'		=>	$email,
		'copyright'	=>	$copyright,
		'address'	=>	$address,
	);

	$result = $this->general_model->updatedetails($data,$id);
	if($result>0) {
		$this->session->set_userdata('alert_type', 'success');
		$this->session->set_userdata('msg', 'Details Updated Successfully');
		redirect(base_url().'siteadmin/generaldetails');

	} else {
		$this->session->set_userdata('alert_type', 'danger');
		$this->session->set_userdata('msg', 'Details Not Updated!');
		redirect(base_url().'siteadmin/generaldetails');
	}
		
}




 public function updatesocial()
{
	$id=1;

	$facebook   = $this->input->post('facebook');
    $twitter   = $this->input->post('twitter');
    $linkedIn  = $this->input->post('linkedIn');
    $youtube   = $this->input->post('youtube');
    $pinterest = $this->input->post('pinterest');
    $instagram = $this->input->post('instagram');

	$data = array(
		'facebook'	=>	$facebook,
		'twitter'	=>	$twitter,
		'linkedIn'	=>  $linkedIn,
		'youtube'	=>	$youtube,
		'pinterest'	=>	$pinterest,
		'instagram'	=>	$instagram,
	);

	$result = $this->general_model->updatesocial($data,$id);
	if($result>0) {
		$this->session->set_userdata('alert_type', 'success');
		$this->session->set_userdata('msg', 'Social Media Links Updated Successfully');
		redirect(base_url().'siteadmin/generaldetails');

	} else {
		$this->session->set_userdata('alert_type', 'danger');
		$this->session->set_userdata('msg', 'Social Media  Links Not Updated!');
		redirect(base_url().'siteadmin/generaldetails');
	}
		
}


 public function updatemap()
{
	$id=1;
    $mapurl = $this->input->post('url');

	$data = array(
		'map_url'	=>	$mapurl,
	);

	$result = $this->general_model->updatemap($data,$id);
	if($result>0) {
		$this->session->set_userdata('alert_type', 'success');
		$this->session->set_userdata('msg', 'Map Url Updated Successfully');
		redirect(base_url().'siteadmin/generaldetails');

	} else {
		$this->session->set_userdata('alert_type', 'danger');
		$this->session->set_userdata('msg', 'Map Url Not Updated!');
		redirect(base_url().'siteadmin/generaldetails');
	}
		
}





	
}
