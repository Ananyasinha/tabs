<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct() {
        parent::__construct();
        $this->load->model('ajax_model');
		error_reporting(0);
		$this->load->library('Mandrill_Api');
    }
	
	public function changestatus()
	{
		$this->ajax_model->changestatus();
	}
	
	public function changefeaturedsts()
	{
		$this->ajax_model->changefeaturedsts();
	}
	
	public function getsubcategory()
	{
		$this->ajax_model->getsubcategory();
	}
	
	public function getproductlist()
	{
		$this->ajax_model->getproductlist();
	}
	
	public function contactprocess()
	{
		$this->ajax_model->contactprocess();
	}
	
	public function quickenquiryprocess()
	{
		$this->ajax_model->quickenquiryprocess();
	}
	
	public function enquiryprocess()
	{
		$this->ajax_model->enquiryprocess();
	}
}
