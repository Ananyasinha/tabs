<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {


	function __construct() {
        parent::__construct();
        $this->load->model('ajax_model');
		error_reporting(0);
		$this->load->library('Mandrill_Api');
    }
	
	public function changestatus()
	{
		$this->ajax_model->changestatus();
	}

	public function enquiryprocess()
	{
		$this->ajax_model->sendMsg();
	}
	

}
