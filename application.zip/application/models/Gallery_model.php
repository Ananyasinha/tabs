<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Gallery_model extends CI_Model {

	public function viewrecord($galleryid = "", $limit="", $status = "")
	{
		$this->db->select('*');
		$this->db->from('tbl_gallery');
		if($galleryid!="")
		{
			$this->db->where('id',$galleryid);
		}
		$this->db->order_by("id","desc");
		if($limit!="" && $limit>0)
		{
			$this->db->limit($limit);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($galleryid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result_array();	
			}
		}
		else
		{
			return false;
		}
	}
	
	public function insertgallery($data)
	{
		$query = $this->db->insert('tbl_gallery',$data);
		$insertid = $this->db->insert_id();
		return $insertid;
	}


	public function changestatus()
	{
		$id = $this->input->post('id');
		$status = $this->input->post('status');
		
		if($id!="")
		{
			if($status == 'Active')
			{
				$status = 'Inactive';
			}
			else
			{
				$status = 'Active';
			}
			
			$data = array('status'=> $status);
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_gallery',$data);
		}
		
		echo trim($status);
	}
	

	 public function updatelogo($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}
	

	public function deletegallery($galleryid)
	{
		if($galleryid!="")
		{
			$this->db->select('fld_video');
			$this->db->from('tbl_gallery');
			$this->db->where('id',$galleryid);	
			$query1 = $this->db->get();
			//echo $this->db->last_query();
			//echo $query->num_rows();
			if($query1->num_rows()>0)
			{
				$result1 = $query1->row();
			
				$gallery_image = $result1->fld_video;
				if($gallery_image!="")
				{
					unlink(UPLOADDIRPATH.'/assets/media/'.$gallery_image);
				}
			}
			//exit;
			$this->db->where('id',$galleryid);	
			$query = $this->db->delete('tbl_gallery');
			return true;
		}
		else
		{
			return false;
		}
	}


}
