<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Award_model extends CI_Model {

	public function viewrecord($awardid = "", $limit="", $status = "")
	{
		$this->db->select('*');
		$this->db->from('tbl_award');
		if($awardid!="")
		{
			$this->db->where('id',$awardid);
		}
		if($status!="")
		{
			$this->db->where('status',$status);
		}
		$this->db->order_by('id','desc');
		if($limit!="" && $limit>0)
		{
			$this->db->limit($limit);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($awardid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}
	
	public function insertaward($data)
	{
		$query = $this->db->insert('tbl_award',$data);
		$insertid = $this->db->insert_id();
		return $insertid;
	}
	
	public function deleteaward($awardid)
	{
		if($awardid!="")
		{
			$this->db->select('fld_image');
			$this->db->from('tbl_award');
			$this->db->where('id',$awardid);	
			$query1 = $this->db->get();
			//echo $this->db->last_query();
			//echo $query->num_rows();
			if($query1->num_rows()>0)
			{
				$result1 = $query1->row();
			
				$award_image = $result1->fld_image;
				if($award_image!="")
				{
					unlink(UPLOADDIRPATH.'/assets/awardimg/'.$award_image);
				}
			}
			//exit;
			$this->db->where('id',$awardid);	
			$query = $this->db->delete('tbl_award');
			return true;
		}
		else
		{
			return false;
		}
	}
}
