<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page_model extends CI_Model {

	public function viewrecord($pageid = "")
	{
		$this->db->select('*');
		$this->db->from('tbl_page');
		if($pageid!="")
		{
			$this->db->where('id',$pageid);
		}
		$this->db->order_by('fld_title','asc');
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($pageid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}
	
	public function insertpage($data,$title)
	{
		$this->db->select('*');
		$this->db->from('tbl_page');
		$this->db->where('fld_title',$title);
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()==0 && $title!="")
		{
			$query = $this->db->insert('tbl_page',$data);
			$insertid = $this->db->insert_id();
			return $insertid;
		}
		else
		{
			return false;
		}
	}
	
	public function updatepage($data,$pageid)
	{
		if($pageid!="")
		{
			$this->db->where('id',$pageid);	
			$query = $this->db->update('tbl_page',$data);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function deletepage($pageid)
	{
		if($pageid!="")
		{
			$this->db->where('id',$pageid);	
			$query = $this->db->delete('tbl_page');
			return true;
		}
		else
		{
			return false;
		}
	}
}
