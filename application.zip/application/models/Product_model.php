<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

	public function viewrecord($productid = "", $limit="", $status = "", $featured = "",$maincatid = "")
	{
		$this->db->select('*');
		$this->db->from('tbl_product');
		if($productid!="")
		{
			$this->db->where('id',$productid);
		}
		if($status!="")
		{
			$this->db->where('status',$status);
		}
		if($featured!="")
		{
			$this->db->where('fld_featured',$featured);
		}
		if($maincatid!="")
		{
			$this->db->where('fld_categoryid',$maincatid);
		}
		$this->db->order_by('id','desc');
		if($limit!="" && $limit>0)
		{
			$this->db->limit($limit);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($productid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}
	
	public function insertproduct($data,$title)
	{
		$this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('fld_title',$title);
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()==0 && $title!="")
		{
			$query = $this->db->insert('tbl_product',$data);
			$insertid = $this->db->insert_id();
			return $insertid;
		}
		else
		{
			return false;
		}
	}
	
	public function updateproduct($data,$productid)
	{
		if($productid!="")
		{
			$this->db->where('id',$productid);	
			$query = $this->db->update('tbl_product',$data);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function deleteproduct($productid)
	{
		if($productid!="")
		{
			$this->db->select('fld_image');
			$this->db->from('tbl_product');
			$this->db->where('id',$productid);	
			$query1 = $this->db->get();
			//echo $this->db->last_query();
			//echo $query->num_rows();
			if($query1->num_rows()>0)
			{
				$result1 = $query1->row();
			
				$product_image = $result1->fld_image;
				if($product_image!="")
				{
					unlink(UPLOADDIRPATH.'/assets/productimg/'.$product_image);
				}
			}
			//exit;
			$this->db->where('id',$productid);	
			$query = $this->db->delete('tbl_product');
			return true;
		}
		else
		{
			return false;
		}
	}
}
