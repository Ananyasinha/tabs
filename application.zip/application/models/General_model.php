<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class General_model extends CI_Model {

	public function viewrecord()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_general_details');
	   $query = $this->db->get();
	   return $query->result_array();
	}  
	
	
    public function updatelogo($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}


    public function updatefavicon($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}

	public function updatedetails($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}
	
	public function updatesocial($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}
	

	public function updatemap($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}
	


}
