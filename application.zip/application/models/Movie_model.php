<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Movie_model extends CI_Model {

	public function viewrecord($newsid = "", $limit="", $status = "")
	{
		$this->db->select('*');
		$this->db->from('tbl_movie');
		if($newsid!="")
		{
			$this->db->where('id',$newsid);
		}
		if($status!="")
		{
			$this->db->where('status',$status);
		}
		
		$this->db->order_by('id','desc');
		if($limit!="" && $limit>0)
		{
			$this->db->limit($limit);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($newsid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}
	
	public function addmovie($data,$title)
	{
		$this->db->select('*');
		$this->db->from('tbl_movie');
		$this->db->where('fld_title',$title);
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()==0 && $title!="")
		{
			$query = $this->db->insert('tbl_movie',$data);
			$insertid = $this->db->insert_id();
			return $insertid;
		}
		else
		{
			return false;
		}
	}
	
	public function update($data,$newsid)
	{
		if($newsid!="")
		{
			$this->db->where('id',$newsid);	
			$query = $this->db->update('tbl_movie',$data);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function deletenews($newsid)
	{
		if($newsid!="")
		{
			$this->db->select('fld_image');
			$this->db->from('tbl_movie');
			$this->db->where('id',$newsid);	
			$query1 = $this->db->get();
			//echo $this->db->last_query();
			//echo $query->num_rows();
			if($query1->num_rows()>0)
			{
				$result1 = $query1->row();
			
				$news_image = $result1->fld_image;
				if($news_image!="")
				{
					unlink(UPLOADDIRPATH.'/assets/movieimg/'.$news_image);
				}
			}
			//exit;
			$this->db->where('id',$newsid);	
			$query = $this->db->delete('tbl_movie');
			return true;
		}
		else
		{
			return false;
		}
	}
}
