<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Group_model extends CI_Model {

	public function viewrecord()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_group');
	   $query = $this->db->get();
	   return $query->result();
	}  
	

	public function viewdetails($pageid = "")
	{
		$this->db->select('*');
		$this->db->from('tbl_group');
		if($pageid!="")
		{
			$this->db->where('id',$pageid);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($pageid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}





	 public function updategroup($data,$pageid)
    {
        $this->db->where('id', $pageid);
        $status = $this->db->update('tbl_group', $data);
        if ($status) {
          return true;
           
        } else{
			return false;
		}
    }


	 public function updatecourse($data, $details,$pageid)
    {
        $this->db->where('id', $pageid);
        $status = $this->db->update('tbl_exam', $data);
        if ($status) {
            $this->db->where('exam_id', $pageid);
            $this->db->delete('tbl_sub_exam');
            $this->db->insert_batch('tbl_sub_exam', $details);
          return true;
           
        } else{
			return false;
		}
    }



	public function addservice($data)
	{
		$query = $this->db->insert('tbl_service',$data);
		$insertid = $this->db->insert_id();
		
		if($insertid!=""){
			return true;
		}else{
			return false;
		}
	}



	public function delete($id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->delete('tbl_service');
			return true;
		} else {
			return false;
		}
	}
	

	

}
