<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	public function authenticate($username, $userpass)
	{
		$this->db->select('*');
		$this->db->from('tbl_admin');
		$this->db->where('fld_username',$username);
		$this->db->where('fld_password',md5($userpass));
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			$this->session->set_userdata('adm_logged_in',true);
			return true;
		}
		else
		{
			return false;
		}
	}
}
