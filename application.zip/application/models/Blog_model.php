<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blog_model extends CI_Model {

	public function viewrecord()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_blog');
	   $query = $this->db->get();
	   return $query->result();
	}  
	

	public function viewdetails($pageid = "")
	{
		$this->db->select('*');
		$this->db->from('tbl_blog');
		if($pageid!="")
		{
			$this->db->where('id',$pageid);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($pageid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}




	public function updateblog($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_blog',$data);
			return true;
		} else {
			return false;
		}
	}
	

	
	public function addblog($data)
	{
		$query = $this->db->insert('tbl_blog',$data);
		$insertid = $this->db->insert_id();
		return $insertid;
	}



	public function deleteblog($id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->delete('tbl_blog');
			return true;
		} else {
			return false;
		}
	}
	
	

}
