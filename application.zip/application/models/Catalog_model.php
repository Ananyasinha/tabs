<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog_model extends CI_Model {

	public function viewbannerlist($type = "", $limit="", $status = "")
	{
		$this->db->select('*');
		$this->db->from('tbl_banner');
		if($type!="")
		{
			$this->db->where('fld_pagename',$type);
		}
		if($status!="")
		{
			$this->db->where('status',$status);
		}
		$this->db->order_by('id','desc');
		if($limit!="" && $limit>0)
		{
			$this->db->limit($limit);
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($bannerid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}

	public function generalinfo()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_general_details');
	   $query = $this->db->get();
	   return $query->result_array();
	}

	public function gallerydetails()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_gallery');
	   $query = $this->db->get();
	   return $query->result_array();
	}

    public function galleryinfo()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_gallery');
	   $this->db->order_by('id','desc');
	   $this->db->limit(5);
	   $query = $this->db->get();
	   return $query->result_array();
	}

	
	

	public function gossipsinfo()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_gossips');
	   $query = $this->db->get();
	   return $query->result();
	}

	


	public function getmoviedetails()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_movie');
	   $this->db->where('status','Active');
	   $query = $this->db->get();
	   return $query->result();
	}




}
