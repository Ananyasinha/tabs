<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog_model extends CI_Model {

	public function getuserinfo($userid = "",$status = "", $limit="")
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		if($userid!="")
		{
			$this->db->where('id',$userid);
		}
		if($this->session->userdata('usr_id')!="" && $userid=="")
		{
			$this->db->where('id',$this->session->userdata('usr_id'));
		}
		if($status!="")
		{
			$this->db->where('status',$status);
			$this->db->order_by('id','asc');
		}
		else
		{
			$this->db->order_by('id','desc');
		}
		if($limit!="" && $limit>0)
		{
			$this->db->limit($limit);
		}
		
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($userid!="" || $this->session->userdata('usr_id')!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}
	
	public function verify($verifycode)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('fld_verifycode',$verifycode);
		$this->db->where('status','Inactive');
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		
		if($query->num_rows()>0)
		{
			$data = array('fld_verifycode'=>'', 'status'=>'Active');
			$this->db->where('fld_verifycode',$verifycode);
			$this->db->where('status','Inactive');
			$query = $this->db->update('tbl_user',$data);
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function updatepassword($oldpassword)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('id',$this->session->userdata('usr_id'));
		$this->db->where('fld_password',md5($oldpassword));
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			$password = $this->input->post('password');
			
			$data = array(
				'fld_decrypt_password'	=>	$password,
				'fld_password'			=>	md5($password)
			);
			$this->db->where('id',$this->session->userdata('usr_id'));
			$query = $this->db->update('tbl_user',$data);
			
			return true;
		}
		else
		{
			return false;
		}
	}


	function viewrimage()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_gallery');
	   $this->db->where('status =', 'Active');
	   $this->db->order_by("id","ASC");
	   $query = $this->db->get();
	   return $query->result();
	}  

	function homegallery()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_gallery');
	   $this->db->where('status =', 'Active');
	   $this->db->order_by("id","ASC");
	   $this->db->limit(4);
	   $query = $this->db->get();
	   return $query->result();
	}  

	 

}
