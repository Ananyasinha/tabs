<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog_model extends CI_Model {

	public function getuserinfo($userid = "",$status = "", $limit="")
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		if($userid!="")
		{
			$this->db->where('id',$userid);
		}
		if($this->session->userdata('usr_id')!="" && $userid=="")
		{
			$this->db->where('id',$this->session->userdata('usr_id'));
		}
		if($status!="")
		{
			$this->db->where('status',$status);
			$this->db->order_by('id','asc');
		}
		else
		{
			$this->db->order_by('id','desc');
		}
		if($limit!="" && $limit>0)
		{
			$this->db->limit($limit);
		}
		
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($userid!="" || $this->session->userdata('usr_id')!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}

	public function generalinfo()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_general_details');
	   $query = $this->db->get();
	   return $query->result_array();
	}

	public function getserviceinfo()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_service');
	   $query = $this->db->get();
	   return $query->result_array();
	}


	public function bannerinfo()
	{
	   $this->db->select('*');
	   $this->db->from('site_banners');
	   $query = $this->db->get();
	   return $query->result_array();
	}


	public function getpagedetail()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_page');
	   $this->db->where('id', 6);
	   $query = $this->db->get();
	   return $query->result_array();
	}


	public function viewrimage()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_gallery');
	   $this->db->where('status =', 'Active');
	   $this->db->order_by("id","ASC");
	   $this->db->limit(3);
	   $query = $this->db->get();
	   return $query->result_array();
	}  


	function galleryimage()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_gallery');
	   $this->db->where('status =', 'Active');
	   $this->db->order_by("id","desc");
	   $query = $this->db->get();
	   return $query->result_array();
	}  

	function homegallery()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_gallery');
	   $this->db->where('status =', 'Active');
	   $this->db->order_by("id","ASC");
	   $this->db->limit(4);
	   $query = $this->db->get();
	   return $query->result_array();
	}  

	function groupinfo1()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_group');
	   $this->db->where('id',1);
	   $query = $this->db->get();
	   return $query->result_array();
	}  

	function groupinfo2()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_group');
	   $this->db->where('id',2);
	   $query = $this->db->get();
	   return $query->result_array();
	}  

	function groupinfo3()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_group');
	   $this->db->where('id',3);
	   $query = $this->db->get();
	   return $query->result_array();
	}  

	function groupinfo4()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_group');
	   $this->db->where('id',4);
	   $query = $this->db->get();
	   return $query->result_array();
	}  

	function groupinfo5()
	{
	   $this->db->select('*');
	   $this->db->from('tbl_group');
	   $this->db->where('id',5);
	   $query = $this->db->get();
	   return $query->result_array();
	}  


}
