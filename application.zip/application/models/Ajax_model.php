<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax_model extends CI_Model {

	public function changestatus()
	{
		$id = trim($this->input->post('id'));
		$status = trim($this->input->post('status'));
		$module = trim($this->input->post('module'));
		
		if($id!="")
		{
			if($status == 'Active')
			{
				$status = 'Inactive';
			}
			else
			{
				$status = 'Active';
			}
			
			if($module !="")
			{
				$module = "tbl_".$module;
			}
			
			$data = array('status'=> $status);
			$this->db->where('id',$id);	
			$query = $this->db->update($module,$data);
		}
		
		echo trim($status);
	}
	
	public function changefeaturedsts()
	{
		$id = trim($this->input->post('id'));
		$status = trim($this->input->post('status'));
		$module = trim($this->input->post('module'));
		
		if($id!="")
		{
			if($status == 'Active')
			{
				$status = 'Inactive';
			}
			else
			{
				$status = 'Active';
			}
			
			if($module !="")
			{
				$module = "tbl_".$module;
			}
			
			$data = array('fld_featured'=> $status);
			$this->db->where('id',$id);	
			$query = $this->db->update($module,$data);
		}
		
		echo trim($status);
	}
	
	public function getsubcategory()
	{
		$parentid = trim($this->input->post('id'));
		
		if($parentid!="")
		{
			$this->db->select('*');
			$this->db->from('tbl_category');
			$this->db->where('fld_parentid',$parentid);
			$this->db->order_by('id','desc');
			$query = $this->db->get();
			//echo $this->db->last_query();
			//echo $query->num_rows();
			if($query->num_rows()>0)
			{
				foreach($query->result() as $row)
				{
				?>
				<option value="<?php echo $row->id;?>"> <?php echo $row->fld_title;?></option>
				<?php 
				}
			}
		}
	}
	
	public function getproductlist()
	{
		$subcategoryid = $this->input->post('arr');
		
		//print_r($subcategoryid);
		
		$this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('status','Active');
		
		$this->db->where_in('fld_subcategoryid', $subcategoryid);
		
		$this->db->order_by('id','desc');
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
		foreach($query->result() as $row)
		{
		?>
		<div class="media">
			<div class="media-left">
				<?php if($row->fld_image!=""){?>
				<img src="<?php echo base_url();?>assets/productimg/<?php echo $row->fld_image;?>"  alt="<?php echo $row->fld_title;?>" class="media-object" />
				<?php }?>	
			</div>
			<div class="media-body">
				<h4 class="media-heading"><?php echo $row->fld_title;?></h4>
				<?php echo $row->fld_description;?>
			</div>
		</div>
		<?php
		}
		}
		else
		{
			?>
			<div class="media">
				<div class="alert alert-danger"> Information Not Available!</div>
			</div>
			<?php
		}
	}
	
	public function contactprocess()
	{
		$mandrill = new Mandrill('6NoCf8QjBNpqq4PP4sQGww');
		
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}

		if($_POST['email']!="")
		{

			$Datas['name']=ucfirst($_POST['name']);
			$Datas['email_id']=$_POST['email'];

			$Datas['country']=$_POST['country'];	
			$Datas['phone']= $_POST['phone'];		
			$Datas['message']=$_POST['message'];	
			
				
			

			$Datas['IP_Address'] = $_SERVER['REMOTE_ADDR'];
			$Datas['Page_Referer'] = $_SERVER['HTTP_REFERER'];

			$body='Dear '.$Datas['name'].'<br/><br/>Your Submitted Details as Follows:<br/><br/>';
			$body.='<strong>Name: </strong>'. $Datas['name'].'<br/>';
			$body.='<strong>Email: </strong>'.$Datas['email_id'].'<br/>';
			$body.='<strong>Country: </strong>'.$Datas['country'].'<br/>';
			
			$body.='<strong>Phone: </strong> '.$Datas['phone'].'<br/>';
			
			if($Datas['message']!="")
			{	
				$body.='<strong>Message : </strong>'.$Datas['message'].'<br/>';
			}
			
			$body.='<strong>Refferal Link: </strong>'.$_SERVER["HTTP_REFERER"].'<br/>';                           

			$body.='<br/> Thanks & regards, <br/>AABT<br/>';
			
			$subject = "Contact Us";
			

			$message = array(
			'html' => $body,
			'subject' => $subject.' || AABT',
			'from_email' => 'info@aabt.com',
			'from_name' => 'AABT',
			'to' => array(
				array(
					'email' => $Datas['email_id'],
					'name' => $Datas['name'],
					'type' => 'to'
				),
				array(
					'email' => ADMINEMAIL,
					'name' => 'Admin',
					'type' => 'bcc'
				)
			)
			);
			$async = false;
			$ip_pool = '';


			$result = $mandrill->messages->send($message, $async, $ip_pool); 

			if($result) 
			{
				echo 'success';
			}
			else
			{
				echo 'fail';
			}

		}
	}
	
	public function quickenquiryprocess()
	{
		$mandrill = new Mandrill('6NoCf8QjBNpqq4PP4sQGww');
		
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}

		if($_POST['email']!="")
		{

			$Datas['name']=ucfirst($_POST['name']);
			$Datas['email_id']=$_POST['email'];

			
			$Datas['phone']= $_POST['phone'];		
			$Datas['message']=$_POST['message'];	
			
				
			

			$Datas['IP_Address'] = $_SERVER['REMOTE_ADDR'];
			$Datas['Page_Referer'] = $_SERVER['HTTP_REFERER'];

			$body='Dear '.$Datas['name'].'<br/><br/>Your Submitted Details as Follows:<br/><br/>';
			$body.='<strong>Name: </strong>'. $Datas['name'].'<br/>';
			$body.='<strong>Email: </strong>'.$Datas['email_id'].'<br/>';
			
			
			$body.='<strong>Phone: </strong> '.$Datas['phone'].'<br/>';
			
			if($Datas['message']!="")
			{	
				$body.='<strong>Message : </strong>'.$Datas['message'].'<br/>';
			}
			
			$body.='<strong>Refferal Link: </strong>'.$_SERVER["HTTP_REFERER"].'<br/>';                           

			$body.='<br/> Thanks & regards, <br/>AABT<br/>';
			
			$subject = "Quick Enquiry";
			
			$message = array(
			'html' => $body,
			'subject' => $subject.' || AABT',
			'from_email' => 'info@aabt.com',
			'from_name' => 'AABT',
			'to' => array(
				array(
					'email' => $Datas['email_id'],
					'name' => $Datas['name'],
					'type' => 'to'
				),
				array(
					'email' => ADMINEMAIL,
					'name' => 'Admin',
					'type' => 'bcc'
				)
			)
			);
			$async = false;
			$ip_pool = '';


			$result = $mandrill->messages->send($message, $async, $ip_pool); 

			if($result) 
			{
				echo 'success';
			}
			else
			{
				echo 'fail';
			}

		}
	}
	
	public function enquiryprocess()
	{
		$mandrill = new Mandrill('6NoCf8QjBNpqq4PP4sQGww');
		
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}

		if($_POST['email']!="")
		{

			$Datas['name']=ucfirst($_POST['fname']).' '.ucfirst($_POST['lname']);
			$Datas['email_id']=$_POST['email'];
			$Datas['country']=$_POST['country'];	
			
			$Datas['service']= $_POST['service'];		
			$Datas['phone']= $_POST['country_code'].' '.$_POST['phone'];		
			$Datas['message']=$_POST['message'];	
			
			$Datas['IP_Address'] = $_SERVER['REMOTE_ADDR'];
			$Datas['Page_Referer'] = $_SERVER['HTTP_REFERER'];

			$body='Dear '.$Datas['name'].'<br/><br/>Your Submitted Details as Follows:<br/><br/>';
			$body.='<strong>Name: </strong>'. $Datas['name'].'<br/>';
			$body.='<strong>Email: </strong>'.$Datas['email_id'].'<br/>';
			$body.='<strong>Country: </strong>'.$Datas['country'].'<br/>';
			$body.='<strong>Phone: </strong> '.$Datas['phone'].'<br/>';
			$body.='<strong>Service: </strong>'.$Datas['service'].'<br/>';
			
			if($Datas['message']!="")
			{	
				$body.='<strong>Message : </strong>'.$Datas['message'].'<br/>';
			}
			
			$body.='<strong>Refferal Link: </strong>'.$_SERVER["HTTP_REFERER"].'<br/>';                           

			$body.='<br/> Thanks & regards, <br/>AABT<br/>';
			
			$subject = "Enquiry";
			

			$message = array(
			'html' => $body,
			'subject' => $subject.' || AABT',
			'from_email' => 'info@aabt.com',
			'from_name' => 'AABT',
			'to' => array(
				array(
					'email' => $Datas['email_id'],
					'name' => $Datas['name'],
					'type' => 'to'
				),
				array(
					'email' => ADMINEMAIL,
					'name' => 'Admin',
					'type' => 'bcc'
				)
			)
			);
			$async = false;
			$ip_pool = '';


			$result = $mandrill->messages->send($message, $async, $ip_pool); 

			if($result) 
			{
				echo 'success';
			}
			else
			{
				echo 'fail';
			}

		}
	}
}
