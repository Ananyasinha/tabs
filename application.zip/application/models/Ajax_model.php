<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax_model extends CI_Model {

	public function changestatus()
	{
		$id = trim($this->input->post('id'));
		$status = trim($this->input->post('status'));
		$module = trim($this->input->post('module'));
		
		if($id!="")
		{
			if($status == 'Active')
			{
				$status = 'Inactive';
			}
			else
			{
				$status = 'Active';
			}
			
			if($module !="")
			{
				$module = "tbl_".$module;
			}
			
			$data = array('status'=> $status);
			$this->db->where('id',$id);	
			$query = $this->db->update($module,$data);
		}
		
		echo trim($status);
	}
	

}
