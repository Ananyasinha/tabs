<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax_model extends CI_Model {

	public function changestatus()
	{
		$id = trim($this->input->post('id'));
		$status = trim($this->input->post('status'));
		$module = trim($this->input->post('module'));
		
		if($id!="")
		{
			if($status == 'Active')
			{
				$status = 'Inactive';
			}
			else
			{
				$status = 'Active';
			}
			
			if($module !="")
			{
				$module = "tbl_".$module;
			}
			
			$data = array('status'=> $status);
			$this->db->where('id',$id);	
			$query = $this->db->update($module,$data);
		}
		
		echo trim($status);
	}
	
	public function changefeaturedsts()
	{
		$id = trim($this->input->post('id'));
		$status = trim($this->input->post('status'));
		$module = trim($this->input->post('module'));
		
		if($id!="")
		{
			if($status == 'Active')
			{
				$status = 'Inactive';
			}
			else
			{
				$status = 'Active';
			}
			
			if($module !="")
			{
				$module = "tbl_".$module;
			}
			
			$data = array('fld_featured'=> $status);
			$this->db->where('id',$id);	
			$query = $this->db->update($module,$data);
		}
		
		echo trim($status);
	}
	
	
	public function contactprocess()
	{
		$mandrill = new Mandrill('6NoCf8QjBNpqq4PP4sQGww');
		
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}

		if($_POST['email']!="")
		{

			$Datas['name']=ucfirst($_POST['name']);
			$Datas['email_id']=$_POST['email'];

			
			$Datas['phone']= $_POST['phone'];		
			$Datas['message']=$_POST['message'];	
			
				
			

			$Datas['IP_Address'] = $_SERVER['REMOTE_ADDR'];
			$Datas['Page_Referer'] = $_SERVER['HTTP_REFERER'];

			$body='Dear '.$Datas['name'].'<br/><br/>Your Submitted Details as Follows:<br/><br/>';
			$body.='<strong>Name: </strong>'. $Datas['name'].'<br/>';
			$body.='<strong>Email: </strong>'.$Datas['email_id'].'<br/>';
			
			$body.='<strong>Phone: </strong> '.$Datas['phone'].'<br/>';
			
			if($Datas['message']!="")
			{	
				$body.='<strong>Message : </strong>'.$Datas['message'].'<br/>';
			}
			
			$body.='<strong>Refferal Link: </strong>'.$_SERVER["HTTP_REFERER"].'<br/>';                           

			$body.='<br/> Thanks & regards, <br/>DCX<br/>';
			
			$subject = "Contact Us";
			

			$message = array(
			'html' => $body,
			'subject' => $subject.' || DCX',
			'from_email' => 'info@dcxindia.com',
			'from_name' => 'DCX',
			'to' => array(
				array(
					'email' => $Datas['email_id'],
					'name' => $Datas['name'],
					'type' => 'to'
				),
				array(
					'email' => ADMINEMAIL,
					'name' => 'Admin',
					'type' => 'bcc'
				),
				array(
					'email' => 'info@dcxindia.com',
					'name' => 'Admin',
					'type' => 'bcc'
				)
				
			)
			);
			$async = false;
			$ip_pool = '';


			$result = $mandrill->messages->send($message, $async, $ip_pool); 

			if($result) 
			{
				echo 'success';
			}
			else
			{
				echo 'fail';
			}

		}
	}
}
