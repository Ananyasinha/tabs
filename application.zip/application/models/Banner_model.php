<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Banner_model extends CI_Model {

	public function viewrecord()
	{
	   $this->db->select('*');
	   $this->db->from('site_banners');
	   $query = $this->db->get();
	   return $query->result();
	}  
	
	
    public function addbanner($data)
	{
		$query = $this->db->insert('site_banners',$data);
		$insertid = $this->db->insert_id();
		return $insertid;
	}


    public function updatefavicon($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}

	public function updatedetails($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}
	
	public function updatesocial($data,$id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->update('tbl_general_details',$data);
			return true;
		} else {
			return false;
		}
	}
	


	public function delete($id)
	{
		if($id!="")
		{
			$this->db->where('id',$id);	
			$query = $this->db->delete('site_banners');
			return true;
		} else {
			return false;
		}
	}


}
