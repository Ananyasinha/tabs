<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category_model extends CI_Model {

	public function viewrecord($categoryid = "",$status = "",$parentid="")
	{
		$this->db->select('*');
		$this->db->from('tbl_category');
		if($categoryid!="")
		{
			$this->db->where('id',$categoryid);
		}
		
		if($parentid!="")
		{
			$this->db->where('fld_parentid',$parentid);
		}
		elseif($categoryid=="")
		{
			$this->db->where('fld_parentid','0');
		}
		
		if($status!="")
		{
			$this->db->where('status',$status);
			$this->db->order_by('fld_title','asc');
		}
		else
		{
			$this->db->order_by('id','desc');
		}
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			if($categoryid!="")
			{
				return $query->row();
			}
			else
			{
				return $query->result();	
			}
		}
		else
		{
			return false;
		}
	}
	
	public function insertcategory($data,$title)
	{
		$this->db->select('*');
		$this->db->from('tbl_category');
		$this->db->where('fld_title',$title);
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()==0 && $title!="")
		{
			$query = $this->db->insert('tbl_category',$data);
			$insertid = $this->db->insert_id();
			return $insertid;
		}
		else
		{
			return false;
		}
	}
	
	public function updatecategory($data,$categoryid)
	{
		if($categoryid!="")
		{
			$this->db->where('id',$categoryid);	
			$query = $this->db->update('tbl_category',$data);
			
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public function deletecategory($categoryid)
	{
		if($categoryid!="")
		{
			$this->db->where('id',$categoryid);	
			$query = $this->db->delete('tbl_category');
			return true;
		}
		else
		{
			return false;
		}
	}
}
