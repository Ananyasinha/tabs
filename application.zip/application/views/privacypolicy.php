<section id="innerpage-banner">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1><span>Advance Aqua Bio Technologies</span> Privacy Policy</h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Privacy Policy</li>
  </ol>
</nav>
</div>
</div>
</div>

</section>
<section id="about-us">
<div class="container">
<div class="row">
<div class="col-md-12">
<h2 class="home-section-title">Privacy   <span class="aabt">Policy</span></h2>
<div class="home-border inner-page"></div>
<?php echo $pagedescription;?>
</div>

</div>

</div>
</section>
