<!DOCTYPE html>
<html lang="en">
   <head>
      <title>HLPL Group</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" href="<?php echo base_url();?>assets/site/images/favicon.png" sizes="48x48">	  
      <link rel="stylesheet" href="<?php echo base_url();?>assets/site/css/bootstrap.css">
	  
	  <link href="<?php echo base_url();?>assets/site/css/vlightbox1.css" rel="stylesheet">
	  <link href="<?php echo base_url();?>assets/site/css/visuallightbox.css" rel="stylesheet">

      <link href="<?php echo base_url();?>assets/site/css/menu.css" rel="stylesheet">
      <link href="<?php echo base_url();?>assets/site/css/style.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  
  </head>
   <body>

      <header>
         <div class="container">
            <div class="row">
               <div class="col-lg-6 col-sm-12 col-md-5 pt-3 pb-5"><a href="<?php echo base_url();?>catalog"><img src="<?php echo base_url();?>assets/media/logo.png" class="img-fluid" alt="" style="height:65px;"></a></div>
               <div class="col-lg-6 col-sm-12 col-md-7">
                  <div class="header-contact-info">
                     <ul>
                        <li><img src="<?php echo base_url();?>assets/site/images/call-icon.png" style="float:left;">
                            <?php echo $result['contact'];?> 
                           +91-11-30014100-150 
                        </li>
                       
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <section class="menu">
         <div class="container">
            <nav id='cssmenu'>
               <div id="head-mobile"></div>
               <div class="button"></div>
               <ul>
                  <li><a href='<?php echo base_url();?>catalog'>Home</a></li>
                  <li><a href='<?php echo base_url();?>group-companies'>Group Companies</a>
   				   <ul>
                     <li><a href='<?php echo base_url();?>him-logistic'> HIM Logistics</a></li>
                     <li><a href='<?php echo base_url();?>apace-transport'>Apace Transports</a> </li>
                     <li><a href='<?php echo base_url();?>oak-shipping'>OAK Shipping Services</a></li>
                     <li><a href='<?php echo base_url();?>winsum-holidays'>Winsum Holidays</a> </li>
                     <li><a href='<?php echo base_url();?>hlpl-global'>HLPL Global</a> </li>
                  </ul>
   				  
   				  </li>
                  <li>
                     <a href='<?php echo base_url();?>infrastructure'>Infrastructure</a>
                  </li>
				      <li><a href='<?php echo base_url();?>career'>Career</a></li>
				      <li><a href='<?php echo base_url();?>management'>Management</a></li>
					   <li><a href='<?php echo base_url();?>gallery'>Gallery</a></li>
                  <li><a href='<?php echo base_url();?>contact-us'>Contacts</a></li>
               </ul>
            </nav>
         </div>
      </section>