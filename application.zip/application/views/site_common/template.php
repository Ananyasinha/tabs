<?php
$this->load->view('site_common/header');
$this->load->view($main_content);
$this->load->view('site_common/footer');
?>