<style type="text/css">
  .alert-dismissible{
    text-align: center;
  }
</style>

<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">SEND US A MESSAGE</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <form>

					 <div class="row">
           <div class="col-sm-12">
            <div class="alert alert-success alert-dismissible success_show" style="display:none">
               <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong class="success_msg"></strong> 
             </div>

             <div class="alert alert-danger alert-dismissible error_show" style="display:none">
               <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong class="error_msg"></strong> 
             </div>
           </div>
						<div class="col-sm-6">
						<div class="form-group">
							<input type="text" placeholder="Name" class="form-control name">
							</div>
							
							<div class="form-group">
							<input type="text" placeholder="Email" class="form-control email">
							</div>
							
							<div class="form-group">
							<input type="text" placeholder="Contact No" class="form-control contact">
						</div>
						
						
						</div>
						<div class="col-sm-6">
							<textarea rows="5" class="form-control message" placeholder="Message"></textarea>
						<input type="submit" class="btn btn-primary float-right mt-4" id="send" value="Submit">
						</div>
						</div>
						</form>
      </div>

      <!-- Modal footer -->
      

    </div>
  </div>
</div>
<section class="contact">
	<div class="container">
		<div class="row pt-5 pb-5">
			<div class="col-sm-6">
			   <div class="dt-sc-icon-box type6 ">
   <div class="icon-wrapper"><img width="77" height="77" src="<?php echo base_url();?>assets/site/images/icon10.png" class="attachment-full" alt=""></div>
   <div class="icon-content">
      <h5>HAVE ANY QUESTIONS? CALL US NOW.</h5>
      <h3 class="text-light"> <?php echo $result[0]['contact']?></h3>
   </div>
</div>
</div>
					<div class="col-sm-6">
			   <div class="dt-sc-icon-box type6 ">
   <div class="icon-wrapper"><img width="77" height="77" src="<?php echo base_url();?>assets/site/images/req.png" class="attachment-full" alt=""></div>
   <div class="icon-content">
      <h5>REQUEST A CALL BACK</h5>
      <a href="#" class="btn btn-primary"  data-toggle="modal" data-target="#myModal">CLICK HERE</a>
   </div>
</div>
</div>
		</div>
	</div>
</section>




<footer class="">
   <div class="container">
      <div class="row pl-4 pr-4">
        
         <div class="col-sm-8 pt-4">
            <div class="footer-block information-block">
               <h2>Quick Links</h2>
               <ul class="point2 mt-4">
                  <li><a href="<?php echo base_url();?>catalog">Home
                     </a>
                  </li>
                  <li><a href="<?php echo base_url();?>group-companies">Group Companies</a></li>
                  <li><a href="<?php echo base_url();?>infrastructure">Infrastructure</a></li>
           <li><a href="<?php echo base_url();?>career">Career</a></li>
            <li><a href="<?php echo base_url();?>management">Management</a></li>
           <li><a href="<?php echo base_url();?>gallery">Gallery</a></li>
                  <li><a href="<?php echo base_url();?>contact-us">Contact Us</a></li>
               </ul>
            </div>
         </div>
         <div class="col-sm-4 pt-4">
            <div class="footer-block information-block">
               <h2>Newsletter Signup</h2>
                
          <div class="input-group mt-4">
         <input type="email" class="form-control" placeholder="Enter your email">
         <span class="input-group-btn">
         <button class="btn btn-theme" type="submit">Subscribe</button>
         </span>
          </div>
            </div>
         </div>
         
      </div>
   </div>
   <div class="col-sm-10 copyright bg-dark pt-3 pb-1 mt-5 mx-auto">
      <p class="text-center"> <?php echo $result[0]['copyright']?> ,Designed by <a href="https://www.360websitedesign.in/" target="_blank">360 Website Design</a> </p>
   
   </div>
</footer>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<script src="<?php echo base_url();?>assets/site/js/menu.js"></script>
<script src="<?php echo base_url();?>assets/site/js/jquery-1.9.1.min.js"></script>
<script src="<?php echo base_url();?>assets/site/js/visuallightbox.js"></script>
<script src="<?php echo base_url();?>assets/site/js/vlbdata1.js"></script>
<script src="<?php echo base_url();?>assets/js/common.js"></script>



</body>
</html>