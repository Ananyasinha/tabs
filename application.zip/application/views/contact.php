

<ul class="breadcrumb mb-0">
<li class="breadcrumb-item"><a href="<?php echo base_url();?>catalog">Home</a></li>
<li class="breadcrumb-item"><a href="#">Contact Us</a></li>
</ul>

<section class="contact-bg">
	<div class="container">
		<div class="row pt-5 pb-5">
			<div class="col-sm-8 contact-page">
				<h5>SEND US A MESSAGE</h5>
				   
					<form>
					 <div class="row">
						<div class="col-sm-6">
						<div class="form-group">
							<input type="text" placeholder="Name" class="form-control">
							</div>
							
							<div class="form-group">
							<input type="text" placeholder="Email" class="form-control">
							</div>
							
							<div class="form-group">
							<input type="text" placeholder="Contact No" class="form-control">
						</div>
						
						
						</div>
						<div class="col-sm-6">
							<textarea rows="5" class="form-control" placeholder="Message"></textarea>
						<input type="submit" class="btn btn-warning float-right mt-4" value="Submit">
						</div>
						</div>
						</form>
					
				
			</div>
			<div class="col-sm-4 contact-page">
			     <h5>Corporate Office</h5>
			      <div class="col-sm-12 contact-info">
                           <h3 class="text-warning"><i class="fa fa-phone"></i> <?php echo $result[0]['contact'];?> </h3>
                           <p><i class="fa fa-fax" aria-hidden="true"></i> <?php echo $result[0]['alt_phone'];?> </p>
						  <p><i class="fa fa-map-marker"></i> <strong> Corporate Head Quarters : </strong> <?php echo $result[0]['address'];?> </p>
                        </div>
			</div>
		</div>
	</div>
</section>

 <iframe src="<?php echo $result[0]['map_url'];?>" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen=""></iframe>

<!-- <iframe src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d56020.27203671797!2d77.154939!3d28.651723!3m2!1i1024!2i768!4f13.1!2m1!1s2151%2F11B+New+Patel+Nagar%2C+Shadipur+New+Delhi%2C+Delhi+110008!5e0!3m2!1sen!2sin!4v1541055258511" width="100%" height="350" frameborder="0" style="border:0" allowfullscreen></iframe> -->
