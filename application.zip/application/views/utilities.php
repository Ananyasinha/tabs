<?php include('include/header.php'); ?>

<ul class="breadcrumb mb-0">
<li class="breadcrumb-item"><a href="index.php">Home</a></li>
<li class="breadcrumb-item"><a href="#">Utilities</a></li>
</ul>
<!--
<section class="bg-primary inner-banner">
	<div class="container">
			<div class="row text-center pt-4 pb-4">
				<div class="col-sm-12 text-center">
				<h2 class="text-light">Utilities</h2>
				<p class="col-sm-8 mx-auto text-light">The HLPL Group is one of the fastest progressing Custom House Agents, International freight forwarders, Transport Fleet owners & contractors.</p>
				</div>
				
				
			</div>
	</div>
</section>-->


<section>
	<div class="container">
		<div class="row pt-5 pb-5">
		<div class="col-sm-12 text-center services">
		     <h2><span>CONVERTER</span></h2>
			
		</div>
		
		     <div class="col-sm-3"><iframe src="http://converter.eu/api/content/?size=1&amp;colors[b]=%23888888&amp;colors[tc]=%23c7c7c7&amp;colors[tbg]=white&amp;colors[c]=black&amp;colors[bg]=%23e1e1e1" frameborder="0" width="100%" height="218"></iframe></div>    
			  <div class="col-sm-9"><iframe src="http://localtimes.info/timediff.php?lcid=USCA0638,USNY0996,BRXX0201,UKXX0085,FRXX0076,RSXX0063,INXX0096,SNXX0006,JAXX0085,ASXX0112&amp;cp=FFFFFF,000000" seamless="" frameborder="0" width="100%" height="385" style="background:white"></iframe></div>   
		
		</div>
	</div>
</section>




<?php include('include/footer.php'); ?>