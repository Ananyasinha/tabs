<ul class="breadcrumb mb-0">
    <li class="breadcrumb-item"><a href="<?php echo base_url();?>catalog">Home</a></li>
    <li class="breadcrumb-item"><a href="#">Career</a></li>
</ul>

<section>
    <div class="container">
        <div class="row pt-5 pb-5">
            <div class="col-sm-12 text-center services">
                <h2><span>Career</span></h2>

            </div>

            <div class="col-sm-12 career mt-4">
                <p> Our company is managed by professionals who are highly qualified and dedicated in their respective field of activities. We promote the best talents in every field and believe that a young and energetic team of well qualified personnel can achieve the impossible.</p>

                <h6>
				Be part of our vibrant, fast-paced environment. You will be expected to conquer professional challenges, but we'll also find time for fun. We prize out-of-the box thinking and we reward excellence.
				</h6>
            </div>

            <div class="col-sm-10 mx-auto border p-3 mt-3">
                <div class="col-sm-12 text-center services">
                    <h2>Fill in your details below and <br/> We will contact you</h2>
                </div>
                <form class="mt-3">
                    <div class="row text-left">
                        <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Enter Name</label>
                            <input type="text" class="form-control" placeholder="Enter First Name">
                        </div>
                        <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Enter Email</label>
                            <input type="text" class="form-control" placeholder="Enter Email">
                        </div>

                        <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Contact No</label>
                            <input type="text" class="form-control" placeholder="Enter Contact No">
                        </div>

                        <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">City</label>
                            <input type="text" class="form-control" placeholder="Enter City">
                        </div>
                        <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">State</label>
                            <input type="text" class="form-control" placeholder="Enter State">
                        </div>

                        <div class="col-sm-6 form-group">
                            <label for="exampleInputEmail1">Upload Resume</label>
                            <div class="file-field form-control pb-3">
                                <div class="btn btn-default btn-sm float-left">

                                    <input type="file">
                                </div>
                            </div>

                        </div>

                        <div class="col-sm-12 form-group">
                            <label for="exampleInputEmail1">Why Should We Hire You?</label>
                            <textarea type="text" class="form-control" placeholder="Enter Message"></textarea>
                        </div>
                        <div class="col-sm-12 form-group">
                            <div class="row ml-1 mr-1">

                                <div class="col-sm-12 text-center pr-0">
                                    <input type="submit" class="col-sm-2 btn btn-primary" name="submit" value="Submit">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>