<?php include('include/header.php'); ?>

<ul class="breadcrumb mb-0">
<li class="breadcrumb-item"><a href="index.php">Home</a></li>
<li class="breadcrumb-item"><a href="#">Services</a></li>
</ul>

<section class="bg-primary inner-banner">
	<div class="container">
			<div class="row text-center pt-4 pb-4">
				<div class="col-sm-12 text-center">
				<h2 class="text-light">Services</h2>
				<p class="col-sm-8 mx-auto text-light">The HLPL Group is one of the fastest progressing Custom House Agents, International freight forwarders, Transport Fleet owners & contractors.</p>
				</div>
				
				
			</div>
	</div>
</section>


<section>
	<div class="container">
	<div class="clearfix pt-3"></div>
	
		<div class="row pt-3 pb-3 mb-2 border-bottom">
	            <div class="col-sm-3"><img src="images/custom.jpg" class="img-fluid"></div>
		         <div class="col-sm-9 career"><h4>Custom House Agents</h4>
				 <p class="mt-4">Leading custom clearance agency with customs stations in the Northern Indian Region with our own dedicated staff manning at all the major Northern Indian ports.</p>
				 </div>
		
		</div>
		
		
			<div class="row pt-3 pb-3 mb-2 border-bottom">
	            <div class="col-sm-3"><img src="images/em.jpg" class="img-fluid"></div>
		         <div class="col-sm-9 career"><h4>Expo/IMPO Consultancy</h4>
				 <p class="mt-4">Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy</p>
				 </div>
		
		</div>
		
		
				<div class="row pt-3 pb-3 mb-2 border-bottom">
	            <div class="col-sm-3"><img src="images/inter.jpg" class="img-fluid"></div>
		         <div class="col-sm-9 career"><h4>International Freight Forwarders</h4>
				 <p class="mt-4">Well established name in international freight forwarding industry and proudly offer the most competitive rates, reliable and value oriented services and always open to add value to your business.</p>
				 </div>
		
		</div>
		
		
			<div class="row pt-3 pb-3 mb-2 border-bottom">
	            <div class="col-sm-3"><img src="images/tr-tour.jpg" class="img-fluid"></div>
		         <div class="col-sm-9 career"><h4>Travel & Tourism</h4>
				 <p class="mt-4">There are many variations of passages of Lorem Ipsum available, suffered alteration in some form, by injected humouror randomised words which don't look even slightly believable.</p>
				 </div>
		
		</div>
		
		
				<div class="row pt-3 pb-3 mb-2 border-bottom">
	            <div class="col-sm-3"><img src="images/fleet.jpg" class="img-fluid"></div>
		         <div class="col-sm-9 career"><h4>Transport Fleet</h4>
				 <p class="mt-4">Provides fleet of Trailers, Mini Trucks, Cargo Vans to cater to the demands of Door-to-Door Delivery for our valued customers.</p>
				 </div>
		
		</div>
	
	
	
	
	</div>
</section>




<?php include('include/footer.php'); ?>