<style>
  #sticky-top{
    position-fixed:
}

.img-fluid {
    max-width: 70% !important;
   /* height: 70% !important;*/
}
</style>
    <!-- Side Navbar -->
    <nav class="side-navbar" id="sticky-top" >
      <!-- Sidebar Header-->
      <div class="sidenav-header-inner text-center">
        <div class="title">

          <img src="<?php echo base_url();?>assets/img/logo.png" alt="..." class="img-fluid rounded-circle">


        </div>
      </div>
      <!-- Sidebar Navidation Menus-->
      <ul class="list-unstyled ">
        <li  class="nav-item <?php if($module == 'dashboard'){ echo 'active';}?>"><a href="<?php echo base_url();?>siteadmin/dashboard" class="nav-link"> <i class="icon-home"></i>Dashboard </a></li>


        <li class="nav-item has-treeview <?php if($module == 'General Details'){ echo 'active';}?>">
          <a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse" class="nav-link">
           <i class="icon-interface-windows"></i>Manage Site Details </a>
          <ul id="exampledropdownDropdown" class="collapse list-unstyled <?php if($module =='General Details'){ echo 'show';}?>">
            <li class="nav-item"><a  href="<?php echo base_url();?>siteadmin/generaldetails">Manage General Details</a></li>
            
          </ul>
        </li>

        <li class="nav-item has-treeview <?php if($module == 'Manage Banner'){ echo 'active';}?>">
          <a href="#example7" aria-expanded="false" data-toggle="collapse" class="nav-link">
           <i class="icon-interface-windows"></i>Manage Banners </a>
          <ul id="example7" class="collapse list-unstyled <?php if($module =='Manage Banner'){ echo 'show';}?>">
             <li class="nav-item <?php if($module =='Manage Banners'){ echo 'active';}?>"><a href="<?php echo base_url();?>siteadmin/banner"> site Banners</a></li>
            
          </ul>
        </li>

        <li class="nav-item <?php if($module =='Manage Page'){ echo 'active';}?>"><a href="<?php echo base_url();?>siteadmin/page"> <i class="fa fa-file"></i>Manage Page</a></li>

         
        <li class="nav-item <?php if($module == 'Service'){ echo 'active';}?>"><a href="#example22" aria-expanded="false" data-toggle="collapse" class="nav-link"> <i class="fa fa-bars"></i>Manage Service </a>
          <ul id="example22" class="collapse list-unstyled <?php if($module =='Service'){ echo 'show';}?>">
           <li class="nav-item"><a href="<?php echo base_url();?>siteadmin/service">view Service</a></li>

          </ul>
        </li>


        <li class="nav-item <?php if($module == 'Group'){ echo 'active';}?>"><a href="#example12" aria-expanded="false" data-toggle="collapse" class="nav-link"> <i class="fa fa-building-o"></i>Manage Group </a>
          <ul id="example12" class="collapse list-unstyled <?php if($module =='Group'){ echo 'show';}?>">
           <li class="nav-item"><a href="<?php echo base_url();?>siteadmin/group">View Group Companies</a></li>

          </ul>
        </li>



        <li class="nav-item <?php if($module == 'Gallery'){ echo 'active';}?>"><a href="#example" aria-expanded="false" data-toggle="collapse" class="nav-link"> <i class="fa fa-image"></i>Manage Gallery </a>
          <ul id="example" class="collapse list-unstyled <?php if($module =='Gallery'){ echo 'show';}?>">
            <li class="nav-item "><a href="<?php echo base_url();?>siteadmin/gallery">View Gallery</a></li>
          </ul>
        </li>


       <li><a href="<?php echo base_url();?>siteadmin/dashboard/logout"> <i class="fa fa-sign-out"></i>LOGOUT </a></li>
      </ul>
    </nav>
     <!-- Side Navbar end -->