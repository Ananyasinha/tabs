<footer>
<div class="container">
<div class="row">
<div class="col-md-4">
<div class="footer-logo"><img src="images/footer-img.jpg" alt="footer-img.jpg" class="footer-img"></div>
</div>
<div class="col-md-2">
<h5 class="footer-title">Quick Links</h5>
<ul class="footer-menu">
<li><a href="<?php echo base_url();?>">Home</a></li>
        <li><a href="<?php echo base_url();?>about-us">About Us</a></li>
        <li><a href="<?php echo base_url();?>products">Products</a></li>
		<li><a href="<?php echo base_url();?>enquiry">Enquiry</a></li>
		<li><a href="<?php echo base_url();?>certificates">Certificates</a></li>
		<li><a href="<?php echo base_url();?>gallery">Gallery</a></li>
		<li><a href="<?php echo base_url();?>contact-us">Contact</a></li>
</ul>
</div>
<div class="col-md-2">
<h5 class="footer-title">Products</h5>
<ul class="footer-menu">
<?php
if(count(array_filter(getcategory()))>0)
{
foreach(getcategory() as $row)
{
?>
<li><a href="<?php echo base_url();?>category/<?php echo generatePermaLink(trim($row->fld_title));?>-<?php echo $row->id;?>"><?php echo $row->fld_title;?></a></li>
<?php 
}
}
?>
</ul>
</div>
<div class="col-md-4">
<h5 class="footer-title">Reach us here</h5>
<ul class="reach-us">
<li><i class="fa fa-map-marker" aria-hidden="true"></i>“<strong>AABT House</strong> No. 62, P&amp;t New Colony - 2, 
Near Saibaba Temple, Vijayawada, Andhra Pradesh, India - 520008
</li>
<li><i class="fa fa-volume-control-phone" aria-hidden="true"></i> +91-866-2485361, +91-866-2485371<br></li>
<li><i class="fa fa-fax" aria-hidden="true"></i> +91-866-2485371</li>
<li><i class="fa fa-mobile" aria-hidden="true"></i> +91-8501931999, +91-9010598309</li>
<li><i class="fa fa-globe" aria-hidden="true"></i> <a href="http://www.aabt.in/" target="_blank">www.aabt.in</a></li>
<li><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:aabtindia@yahoo.co.in">aabtindia@yahoo.co.in</a></li>
</ul>
<p class="social-links">
<a href="#" target="_blank" title="Facebook"><i class="fa fa-facebook-square" aria-hidden="true"></i></a> 
<a href="#" target="_blank" title="Twitter"><i class="fa fa-twitter-square" aria-hidden="true"></i></a> 
<a href="#" target="_blank" title="Google Plus"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a> 
<a href="#" target="_blank" title="Linkdin"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
<a href="#" target="_blank" title="Youtube"><i class="fa fa-youtube-square" aria-hidden="true"></i></i></a> 
</p>
</div>
</div>
<div class="mp-image"><img src="images/imgmap.jpg" alt="mp-images" class="map-img"></div>
</div>
<div class="copyright">
<div class="container">
<div class="col-md-4">
<p>Copyright ©2018 . All Rights Reserved</p>
</div>
<div class="col-md-4">
<p>Designed by <a href="https://www.360websitedesigning.com/" target="_blank" title="360websitedesigning">360websitedesigning.com</a></p>
</div>
<div class="col-md-4">
<ul class="copyright-menu">
<li><a href="<?php echo base_url();?>terms-of-use">Terms of use</a></li>
<li><a href="<?php echo base_url();?>privacy-policy">Privacy Policy</a></li>
<li><a href="<?php echo base_url();?>sitemap">Sitemap</a> </li>
</ul>
</div>
</div>
</div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script src="function/common_function.js"></script>
<?php if($module == "contactus" || $module == "home" || $module == "enquiry"){?>
<script>
$("input").focus(function(){
	 var id=this.id;
	 $("#"+id+"Err").html('');
	 $("#"+id).css('border','1px solid #ccc');
});
$("textarea").focus(function(){
	 var id=this.id;
	 $("#"+id+"Err").html('');
	 $("#"+id).css('border','1px solid #ccc');
});
$("select").focus(function(){
	 var id=this.id;
	 $("#"+id+"Err").html('');
	 $("#"+id).css('border','1px solid #ccc');
});
</script>
<?php }?>
</body>
</html>