        <footer>

            <div class="container">
                <div class="row">

                    <div class="col-sm-4 mb-3">
                        <h2>Copyright</h2>
                        <p>Movies © 2018 • <a href="#">Privacy Policy</a></p>
                    </div>

                    <div class="col-sm-4 mb-3">
                        <h2>Contact Us</h2>
                        <ul>
                            <li><i class="fa fa-envelope-o"></i> <a href="#">
                            <?php echo $details[0]['email']?></a></li>

                            <li><i class="fa fa-home"></i><?php echo $details[0]['address']?> </li>

                            <li><i class="fa fa-phone"></i> <a href="#"><?php echo $details[0]['contact']?></a></li>
                        </ul>
                    </div>

                    <div class="col-sm-4">
                        <h2>Follow Us</h2>
                        <div class="social">
                            <a href="<?php echo $details[0]['facebook']?>" target="_blank"class="facebook"><i class="fa fa-facebook"></i></a>

                            <a href="<?php echo $details[0]['twitter']?>" target="_blank" class="twitter"><i class="fa fa-twitter"></i></a>

                            <a href="<?php echo $details[0]['linkedin']?>" target="_blank" class="linkedin"><i class="fa fa-linkedin"></i></a>

                            <a href="<?php echo $details[0]['gplus']?>" target="_blank" class="google"><i class="fa fa-google-plus"></i></a>
                        </div>
                    </div>

                </div>
            </div>

            <div class="clearfix"></div>
        </footer>

        <div class="clearfix"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="<?php echo base_url();?>assets/site/js/bootstrap.js"></script>

    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.2/dist/jquery.fancybox.min.js"></script>
    <script>
        $(document).ready(function() {
            //FANCYBOX
            //https://github.com/fancyapps/fancyBox
            $(".fancybox").fancybox({
                openEffect: "none",
                closeEffect: "none"
            });
        });
    </script>
</body>
</html>