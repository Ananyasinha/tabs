          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>Copyright © 2018 HLPL Group.All Right Reserved.</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by 360WebsiteDesign</p>
                </div>
              </div>
            </div>
          </footer>
        </div> <!-- content end -->
      </div><!-- page content -->
    </div><!-- page end -->

    
    <!-- JavaScript files-->
    <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/popper.js/umd/popper.min.js"> </script>
    <script src="<?php echo base_url();?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets/vendor/jquery.cookie/jquery.cookie.js"> </script>
  <!--   <script src="<?php echo base_url();?>assets/vendor/chart.js/Chart.min.js"></script> -->
    <script src="<?php echo base_url();?>assets/vendor/jquery-validation/jquery.validate.min.js"></script>
  <script src="<?php echo base_url()?>assets/dropzone/dropzone.min.js"></script>


  <script src="<?php echo base_url();?>assets/ckeditor/ckeditor/ckeditor.js"></script>
  <script src="<?php echo base_url();?>assets/ckeditor/ckfinder/ckfinder.js"></script>

   <script type="text/javascript">
  var editor = CKEDITOR.replace( 'order_summary', {
      filebrowserBrowseUrl : 'ckeditor/ckfinder/ckfinder.html',
      filebrowserImageBrowseUrl : 'ckeditor/ckfinder/ckfinder.html?type=Images',
      filebrowserFlashBrowseUrl : 'ckeditor/ckfinder/ckfinder.html?type=Flash',
      filebrowserUploadUrl : 'ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
      filebrowserImageUploadUrl : 'ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
      filebrowserFlashUploadUrl : 'ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
  });
  CKFinder.setupCKEditor( editor, '../' );
  </script>  


<script type="text/javascript" src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/1.10.18/js/dataTables.bootstrap4.min.js"></script>


<script src="<?php echo base_url();?>assets/js/front.js"></script>


 
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script> 
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip(); 
});

</script>

 <script>
   $(document).ready( function () {
    $('.table_id').DataTable();
} );
 </script>


  </body>
</html>