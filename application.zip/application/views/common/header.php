<!DOCTYPE html>
<html>
<head>
<?php if($module == "product_list"){?>
<title><?php echo $result->fld_mtitle;?></title>
<meta name="description" content="<?php echo $result->fld_mdescription;?>" >
<meta name="keyword" content="<?php echo $result->fld_mkeyword;?>" >
<?php 
}
else
{ 
?>
<title><?php echo $mtitle;?></title>
<meta name="description" content="<?php echo $mdescription;?>" >
<meta name="keyword" content="<?php echo $mkeyword;?>" >
<?php 
}
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<base href="<?php echo base_url();?>assets/" />
<link rel="icon" href="images/favicon.png" type="image/gif" sizes="48x48">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src='https://www.google.com/recaptcha/api.js'></script>
<style>
.error{
	color:#f00;
}
</style>
</head>
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<body>
<header>
<div class="container">
<nav class="navbar navbar-inverse">
  <div class="container-fluid-custome">
  <div class="top-bar">
<p class="social-links"><span class="call-today"><strong><i class="fa fa-volume-control-phone" aria-hidden="true"></i></strong> +91-866-2485371</span>
<a href="#" target="_blank" title="Facebook"><i class="fa fa-facebook-square" aria-hidden="true"></i></a> 
<a href="#" target="_blank" title="Twitter"><i class="fa fa-twitter-square" aria-hidden="true"></i></a> 
<a href="#" target="_blank" title="Google Plus"><i class="fa fa-google-plus-square" aria-hidden="true"></i></a> 
<a href="#" target="_blank" title="Linkdin"><i class="fa fa-linkedin-square" aria-hidden="true"></i></a>
<a href="#" target="_blank" title="Youtube"><i class="fa fa-youtube-square" aria-hidden="true"></i></a> 
</p>
  </div>
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="<?php echo base_url();?>"><img src="images/logo.jpg" alt="logo"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li <?php if($module == "home"){?>class="active"<?php }?>><a href="<?php echo base_url();?>">Home</a></li>
        <li <?php if($module == "aboutus"){?>class="active"<?php }?>><a href="<?php echo base_url();?>about-us">About Us</a></li>
        <li <?php if($module == "products"){?>class="active"<?php }?>><a href="<?php echo base_url();?>products">Products</a></li>
		<li <?php if($module == "enquiry"){?>class="active"<?php }?>><a href="<?php echo base_url();?>enquiry">Enquiry</a></li>
		<li <?php if($module == "certificates"){?>class="active"<?php }?>><a href="<?php echo base_url();?>certificates">Certificates</a></li>
		<li <?php if($module == "gallery"){?>class="active"<?php }?>><a href="<?php echo base_url();?>gallery">Gallery</a></li>
		<li <?php if($module == "contactus"){?>class="active"<?php }?>><a href="<?php echo base_url();?>contact-us">Contact</a></li>
		<li class="select-lang">
		<!-- <select><option>Select Language</option>
		<option>English</option>
		<option>Hindi</option></select></li> -->
		<div id="google_translate_element"></div>
      </ul>
     
    </div>
  </div>
</nav>
</div>

</header>



