<!DOCTYPE html>
<html lang="en">
<head>

<?php if($module == "products"){?>
<title><?php echo $result_product->fld_mtitle;?></title>
<meta name="description" content="<?php echo $result_product->fld_mdescription;?>" >
<meta name="keyword" content="<?php echo $result_product->fld_mkeyword;?>" >
<?php 
}
else
{ 
?>
<title>Hot Spot | <?php echo $module;?></title>
<meta name="description" content="<?php echo $mdescription;?>" >
<meta name="keyword" content="<?php echo $mkeyword;?>" >
<?php 
}
?>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo base_url();?>assets/media/<?php echo $details[0]['favicon'];?>">
    
    <link href="<?php echo base_url();?>assets/site/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/site/css/bootstrap.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.2/dist/jquery.fancybox.min.css" />
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
</head>



<script>
$('li.dropdown').on('click', function() {
    var $el = $(this);
    if ($el.hasClass('open')) {
        var $a = $el.children('a.dropdown-toggle');
        if ($a.length && $a.attr('href')) {
            location.href = $a.attr('href');
        }
    }
});</script>

<script>
$(document).ready(function() {
    $("img").on("contextmenu",function(e){
       return false;
    }); 
}); 


</script>

<body>

    <div class="wrapper">
        <header>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <a href="<?php echo base_url();?>catalog" class="logo"><img src="<?php echo base_url();?>assets/site/images/logo.png"></a>
                    </div>
                </div>
            </div>

            <nav class="navbar navbar-expand-lg">
                <div class="container">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarsExample07">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>catalog">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>movie">Movie</a></li>
                            <li class="nav-item"><a class="nav-link" href="#">Gossips</a></li>
                            <li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>gallery">Gallery</a></li>
                            
                            <li class="nav-item"><a class="nav-link" href="#">Latest </a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <div class="clearfix"></div>
        </header>