<ul class="breadcrumb mb-0">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item"><a href="#">Group Companies</a></li>
</ul>

<section>
    <div class="container">
        <div class="row pt-5 pb-5">
            <div class="col-sm-12 text-center services">
                <h2><span>About</span> <strong>Group Companies</strong></h2>
            </div>

            <div class="col-sm-12 text-justify">

                <p>The HLPL Group Traces its history back to the year 2007. Started with a solo performance of Mr Prakash Chand Sharma, he conceived and propelled a visionary dream team of professionals in rendering services to import and export in the field of customs clearances and its auxiliary services. 10 years down the line, his vision grows leaps and bounds with 5 world class companies under the HLPL umbrella. The foundation of our business is our willingness to honestly put an Extraordinary effort that works to achieve the requisite goal.
                </p>

                <p>
                    We value our customer's time and money and prioritize to provide the best services without loss to anyone. </p>

                <p>
                    The Group and its companies have multiplied in size and volume over the years and aspire to further engrave its global imprints to emerge as a leading supply chain management player. It is consistently endeavoring to incorporate new technological breakthroughs in its operations and surpass customer expectations. Since its inception in the year 2007, we have garnered the trust and goodwill of our clients and their counterparts alike.
                </p>

                <p>
                    Through unremitting technology adoption and process improvement in all its operations, HLPL group has successfully evolved as the most preferred business alliance partner for clientele who are spread all over the country & world over. The Group companies are capable of cost-effective handling of shipments with requisite solutions as per the customer's demands, with the added advantage of serving from the pickup stage of a given shipment from the supplier/manufacturers to the door steps of Importers/ exporters - a dedicated team of more than 300 young industry professionals is incessantly striving to further enhance the company's credibility to new levels of excellence at all stages and times.
                </p>
            </div>
        </div>
    </div>
</section>