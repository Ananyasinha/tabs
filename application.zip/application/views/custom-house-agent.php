
<ul class="breadcrumb mb-0">
<li class="breadcrumb-item"><a href="index.php">Home</a></li>
<li class="breadcrumb-item"><a href="#">Custom House Agent</a></li>
</ul>
<!--
<section class="bg-primary inner-banner">
	<div class="container">
			<div class="row text-center pt-4 pb-4">
				<div class="col-sm-12 text-center">
				<h2 class="text-light">Custom House Agents</h2>
				<p class="col-sm-8 mx-auto text-light">The HLPL Group is one of the fastest progressing Custom House Agents, International freight forwarders, Transport Fleet owners & contractors.</p>
				</div>
				
				
			</div>
	</div>
</section>-->

<section>
	<div class="container">
		<div class="row pt-5 pb-5">
		<div class="col-sm-12 text-center">
				<h2 class="">Custom House Agents</h2>
				<p class="col-sm-8 mx-auto">The HLPL Group is one of the fastest progressing Custom House Agents, International freight forwarders, Transport Fleet owners & contractors.</p>
				</div>

			<?php if(count(array_filter($details)) > 0){
				foreach ($details as $row) { ?>
					
				<div class="col-sm-4 mt-3">
				    <a class="vlightbox1" href="<?php echo base_url();?>assets/galleryimg/<?php echo $row['fld_image']?>"> <img src="<?php echo base_url();?>assets/galleryimg/<?php echo $row['fld_image']?>" class="img-fluid">
	                </a>
				</div>
			<?php } } ?>

		</div>
	</div>
</section>
