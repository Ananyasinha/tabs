<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Hot Spot</title>

    <link href="css/style.css" rel="stylesheet">
	
	<link href="css/bootstrap.css" rel="stylesheet">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.2/dist/jquery.fancybox.min.css" />
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

  </head>
  <body>


 <div class="wrapper">
 
   <header>
   
    <div class="container">
	  <div class="row">
	    <div class="col-sm-12">
		  <a href="index.html" class="logo"><img src="images/logo.png"></a>
		</div>
	  </div>
	</div>
	
	
	    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExample07">
          <ul class="navbar-nav mr-auto">
           <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
			<li class="nav-item"><a class="nav-link" href="movie.html">Movie</a></li>
			<li class="nav-item"><a class="nav-link" href="gossip.html">Gossips</a></li>
			<li class="nav-item"><a class="nav-link" href="gallery.html">Gallery</a></li>
			<li class="nav-item"><a class="nav-link" href="latest.html">Latest </a></li>
          </ul>
        </div>
      </div>
    </nav>
   
     <div class="clearfix"></div>
   </header>
   
   
    <div class="middile">
	
	  <div class="container">
	    <div class="row">
		   
		   <div class="col-sm-9">
		     <div class="row">
			 <div class="col-sm-8">
			   <div class="home-slide">
			           <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="first-slide" src="images/gallery1.jpg" alt="First slide">
          </div>
          <div class="carousel-item">
            <img class="second-slide" src="images/gallery1.jpg"  alt="Second slide">
          </div>
          <div class="carousel-item">
            <img class="third-slide" src="images/gallery1.jpg"  alt="Third slide">
          </div>
        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
			   </div>
			 
			   <div class="latest-gallery mt-5">
			      
				  <nav class="mb-5">
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active" id="nav-Latest-tab" data-toggle="tab" href="#nav-Latest" role="tab" aria-controls="nav-home" aria-selected="true">Latest</a>
    <a class="nav-item nav-link" id="nav-Gallery-tab" data-toggle="tab" href="#nav-Gallery" role="tab" aria-controls="nav-profile" aria-selected="false">Gallery</a>
  </div>
</nav>
<div class="tab-content" id="nav-tabContent">
  <div class="tab-pane fade show active" id="nav-Latest" role="tabpanel" aria-labelledby="nav-Latest-tab">
  
   <div class="row">
   
    <div class="col-sm-6">
	<div class="gallery-home">
	 <h3>Lorem Ispum</h3>
	   <img src="images/gallery1.jpg" class="img-fluid">
	   <div class="overlay">
                <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
            </div>
			</div>
			<h4>10th Sep 2014</h4>
			<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
	 </div>
	 
	 
	 <div class="col-sm-6">
	<div class="gallery-home">
	 <h3>Lorem Ispum</h3>
	   <img src="images/gallery1.jpg" class="img-fluid">
	   <div class="overlay">
                <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
            </div>
			</div>
			<h4>10th Sep 2014</h4>
					<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
	 </div>
	 
	 
	 <div class="col-sm-6">
	<div class="gallery-home">
	 <h3>Lorem Ispum</h3>
	   <img src="images/gallery1.jpg" class="img-fluid">
	   <div class="overlay">
                <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
            </div>
			</div>
			<h4>10th Sep 2014</h4>
					<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
	 </div>
	 
	 
	 <div class="col-sm-6">
	<div class="gallery-home">
	 <h3>Lorem Ispum</h3>
	   <img src="images/gallery1.jpg" class="img-fluid">
	   <div class="overlay">
                <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
            </div>
			</div>
			<h4>10th Sep 2014</h4>
					<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
	 </div>
	 
	 
	 <a class="see-all" href="#">See All</a>
	 
   </div>
  
  </div>
  

  <div class="tab-pane fade" id="nav-Gallery" role="tabpanel" aria-labelledby="nav-Gallery-tab">
  
   <div class="row">
   
    <div class="col-sm-6">
	<div class="gallery-home">
	 <h3>Lorem Ispum</h3>
	   <img src="images/gallery4.jpg" class="img-fluid">
	   <div class="overlay">
                <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
            </div>
			</div>
			<h4>10th Sep 2014</h4>
					<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
	 </div>
	 
	 
	 <div class="col-sm-6">
	<div class="gallery-home">
	 <h3>Lorem Ispum</h3>
	   <img src="images/gallery1.jpg" class="img-fluid">
	   <div class="overlay">
                <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
            </div>
			</div>
			<h4>10th Sep 2014</h4>
					<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
	 </div>
	 
	 
	 <div class="col-sm-6">
	<div class="gallery-home">
	 <h3>Lorem Ispum</h3>
	   <img src="images/gallery1.jpg" class="img-fluid">
	   <div class="overlay">
                <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
            </div>
			</div>
			<h4>10th Sep 2014</h4>
					<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
	 </div>
	 
	 
	 <div class="col-sm-6">
	<div class="gallery-home">
	 <h3>Lorem Ispum</h3>
	   <img src="images/gallery1.jpg" class="img-fluid">
	   <div class="overlay">
                <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
            </div>
			</div>
			<h4>10th Sep 2014</h4>
					<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
	 </div>
	 
	 
	 <a class="see-all" href="#">See All</a>
	 
	
	 
   </div>
  

   

  
  
  </div>
</div>
				  
			   </div>
			 
			 </div>
			 
			 
			 <div class="col-sm-4 mt-5">
			   <div class="events-home">
			     <h1 class="heading">Events</h1>
				 
				 <div class="inner hovereffect">
                  <img class="img-responsive" src="images/gallery1.jpg" alt="">
                  <div class="overlay">
                  <h3>2nd Jan 2013 <span>VOLUPTATE VELIT ESSE</span></h3>
                 <a class="info" href="#"></a>
                 </div>
                </div>
				
				<div class="inner hovereffect">
                  <img class="img-responsive" src="images/gallery1.jpg" alt="">
                  <div class="overlay">
                  <h3>2nd Jan 2013 <span>VOLUPTATE VELIT ESSE</span></h3>
                 <a class="info" href="#"></a>
                 </div>
                </div>
				
				
				<div class="inner hovereffect">
                  <img class="img-responsive" src="images/gallery1.jpg" alt="">
                  <div class="overlay">
                  <h3>2nd Jan 2013 <span>VOLUPTATE VELIT ESSE</span></h3>
                 <a class="info" href="#"></a>
                 </div>
                </div>
				
				 
			   </div>
			   
			   <div class="popular-home mt-3 text-center">
			    <h2 class="heading">Popular</h2>
				
				<div class="inner">
				   <a href="#">
				   <h3>2nd Jan 2013</h3>
				 <a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
				   </a>
				</div>
				
				<div class="inner">
				   <a href="#">
				   <h3>13th Feb 2013</h3>
				<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
				   </a>
				</div>
				
				<div class="inner">
				   <a href="#">
				   <h3>14th Feb 2013</h3>
			<a href="gossip-review.html"><p>Curabitur facilisis pellentesque pharetra donec justo urna</p> </a>
				   </a>
				</div>
				
				<a class="see-all" href="#">See All</a>
				
			   </div>
			   
			   
			 </div>
			 
			 
		
 <div class="clearfix"></div>




			 
			 <div class="col-sm-12 mt-5">
			 <div class="row">
			 
			  <div class="col-sm-4 mb-3 text-center">
			   
			    <h2 class="heading light text-center">Gossips</h2>
				
				<div class="home-bottom text-center">
				<a href="gossip-review.html">  <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3> </a>
				  <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis,  dignissim, pulvinar ac,...</p>
				</div>
				<div class="home-bottom text-center">
					<a href="gossip-review.html">  <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3> </a>
				  <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis,  dignissim, pulvinar ac,...</p>
				</div>
				
				<div class="home-bottom text-center">
				<a href="gossip-review.html">  <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3> </a>
				  <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis,  dignissim, pulvinar ac,...</p>
				</div>
				
				<a class="see-all" href="#">See All</a>
			  
			  </div>
			  
			  
			  <div class="col-sm-4 mb-3 text-center">
			   
			    <h2 class="heading light text-center">Now in Theaters</h2>
				
				<div class="home-bottom text-center">
				  <img src="images/gallery1.jpg" class="img-fluid">
					<a href="gossip-review.html">  <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3> </a>
				  <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis,  dignissim, pulvinar ac,...</p>
				</div>
				
				
			<!--	<a class="see-all" href="#">Read More</a> -->
			  
			  </div>
			  
			  <div class="col-sm-4  text-center">
			   
			    <h2 class="heading light text-center">Gallery</h2>
				
				<div class="home-bottom text-center">
				  <img src="images/gallery1.jpg" class="img-fluid">
					<a href="gossip-review.html">  <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3> </a>
				  <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis,  dignissim, pulvinar ac,...</p>
				</div>
				
				
				<a class="see-all" href="#">See All</a>
			  
			  </div>
			  
			  
			 </div>
			 </div>
			 
			 
			</div> 
		   </div>
		   
		   
		   <div class="col-sm-3 mt-5">

			 <div class="col-sm-12 pr-0 pl-0">
			   <div class="home-right-box">
			     <h3>Lorem Ispum</h3>
				 <a href="#"><img src="images/gallery1.jpg" class="img-fluid"></a>
				 <a href="#">
				   <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
				 </a>
			   </div>
			 </div>
			 
			<div class="col-sm-12 pr-0 pl-0">
			   <div class="home-right-box">
			     <h3>Lorem Ispum</h3>
				 <a href="#"><img src="images/gallery1.jpg" class="img-fluid"></a>
				 <a href="#">
				   <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
				 </a>
			   </div>
			 </div>
			 
			 <div class="col-sm-12 pr-0 pl-0">
			   <div class="home-right-box last">
				 <a href="#"><img src="images/gallery1.jpg" class="img-fluid"></a>
				 <a href="#">
				   <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
				 </a>
			   </div>
			 </div>
			 

		   </div>
		   
		   
		   
		</div>
	  </div>
	  
	 <div class="clearfix"></div> 
	</div>
	
	
	<footer>
	
	  <div class="container">
	    <div class="row">
		  
		  <div class="col-sm-4 mb-3">
		    <h2>Copyright</h2>
			<p>Movies © 2018 • <a href="#">Privacy Policy</a></p>
		  </div>
		  
		  <div class="col-sm-4 mb-3">
		    <h2>Contact Us</h2>
			<ul>
			  <li><i class="fa fa-envelope-o"></i> <a href="#">mail@demolink.org</a></li>
			  <li><i class="fa fa-home"></i> Mill Road,Cambridge,</li>
			  <li><i class="fa fa-phone"></i> <a href="#">+1 800 559 6580</a></li>
			</ul>
		  </div>
		  
		  <div class="col-sm-4">
		    <h2>Follow Us</h2>
			 <div class="social">
			   <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
			   <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
			   <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
			   <a href="#" class="google"><i class="fa fa-google-plus"></i></a>
			 </div>
		  </div>
		  
		</div>
	  </div>
	
	 <div class="clearfix"></div>  
	</footer>
	
 
   <div class="clearfix"></div>   
 </div>
 


<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/bootstrap.js"></script>

<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.2/dist/jquery.fancybox.min.js"></script>

<script>$(document).ready(function(){
    //FANCYBOX
    //https://github.com/fancyapps/fancyBox
	
	
	
    $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
    });
	

	
});
   </script>
   

   




</body>
</html>
