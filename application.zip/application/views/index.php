<?php include('include/header.php'); ?>
  <section>
      <div id="demo" class="carousel carousel-fade" data-ride="carousel">

          <!-- Indicators -->
          <ul class="carousel-indicators">
              <li data-target="#demo" data-slide-to="0" class="active"></li>
              <li data-target="#demo" data-slide-to="1"></li>
              <li data-target="#demo" data-slide-to="2"></li>
              <li data-target="#demo" data-slide-to="3"></li>
              <li data-target="#demo" data-slide-to="4"></li>
              <li data-target="#demo" data-slide-to="5"></li>
          </ul>

          <!-- The slideshow -->
          <div class="carousel-inner">
            <?php 
              $i=1;
                if(count(array_filter($banner)) > 0){
                 foreach($banner as $row){
                ?>

            <div class="carousel-item <?=($i==1)?"active":""?>">
              <img src="<?php echo base_url();?>assets/media/banner/<?php echo $row['image'] ?>" alt="Los Angeles" class="banner-img">

                <?php if($row['sideimage']!=""){ ?>
                <div class="carousel-caption">
                    <div class="row">
                      <div class="col-sm-5">
                          <h3><?php echo $row['title'];?></h3>
                      </div>

                      <div class="col-sm-6">
                        <img src="<?php echo base_url();?>assets/media/banner/<?php echo $row['sideimage'] ?>">
                      </div>
                  </div>
                </div>
                <?php } else{ ?>
                  <div class="carousel-caption">
                    <div class="col-sm-10 text-center">
                      <h3 class="venture"><?php echo $row['title'];?></h3>
                    </div>
                  </div>
              
                  <?php } ?>
            </div>
       <?php $i++ ; } } ?>
        </div>
          <!-- Left and right controls -->
          <a class="carousel-control-prev" href="#demo" data-slide="prev">
              <span class="carousel-control-prev-icon"></span>
          </a>
          <a class="carousel-control-next" href="#demo" data-slide="next">
              <span class="carousel-control-next-icon"></span>
          </a>
      </div>
  </section>

  <section>
    <div class="container pt-4 pb-4">
      <div class="col-sm-12 text-center services">
          <h2><span>OUR</span> <strong>SERVICES</strong></h2>
          <p class="col-sm-8 mx-auto">Services we provide to meet the requirements of customers!</p>
      </div>

      <div class="row mt-5">
          <div class="col-sm-4">
              <div class="dt-sc-icon-box type4 ">
                  <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/icon1.png" class="img-fluid" alt=""></div>
                  <div class="icon-content">
                      <h4>Custom Clearing Services</h4>
                      <p class="pt-3">Providing Smooth,easy and hassle-free clearence of cargo goods across India</p>
                  </div>
              </div>
          </div>

          <div class="col-sm-4">
              <div class="dt-sc-icon-box type4 ">
                  <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/icon3.png" class="img-fluid" alt=""></div>
                  <div class="icon-content">
                      <h4>Freight Forwarding</h4>
                      <p class="pt-3">We ensure to transport your precious cargo from the anywhere in the world to your desired destination </p>
                  </div>
              </div>
          </div>

          <div class="col-sm-4">
              <div class="dt-sc-icon-box type4 ">
                  <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/icon2.png" class="img-fluid" alt=""></div>
                  <div class="icon-content">
                      <h4>EXIM consultancy</h4>
                      <p class="pt-3">Are you a first time Importer/Exporter? Bringing in new products? Confused about the HSN code? Our team of experts and consultants provide the best solution and consultancy!</p>
                  </div>
              </div>
          </div>

          <div class="col-sm-4 offset-2 mt-3">
              <div class="dt-sc-icon-box type4 ">
                  <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/icon5.png" class="img-fluid" alt=""></div>
                  <div class="icon-content">
                      <h4>Transportation</h4>
                      <p class="pt-3">We provide wheels to your cargo. Logistics solution for the last mile coonectivity till your premises</p>
                  </div>
              </div>
          </div>

          <div class="col-sm-4 mt-3">
              <div class="dt-sc-icon-box type4 ">
                  <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/icon4.png" class="img-fluid" alt=""></div>
                  <div class="icon-content">
                      <h4>Travel & Tourism</h4>
                      <p class="pt-3">Providing relaxing and memorable holidays. Fun,adventure and excitement all around</p>
                  </div>
              </div>
          </div>

      </div>
    </div>
  </section>

  <section class="group">
      <div class="container pt-4 pb-4">
          <div class="col-sm-12 text-center services">
              <h2><span>GROUP</span> <strong>COMPANIES</strong></h2>
              <p class="col-sm-8 mx-auto">The HLPL Group Traces its history back to the year 2007. Started with a solo performance of Mr Prakash Chand Sharma, he conceived and propelled a visionary dream team of professionals in rendering services to import and export in the field of customs clearances and its auxiliary services. 10 years down the line, his vision grows leaps and bounds with 5 world class companies under the HLPL umbrella</p>
          </div>

      </div>
  </section>



  <div class="row group-box mr-0">
      <div class="col-sm-3 pl-0 pr-0">
          <div class="vc_column-inner ">
              <div class="wpb_wrapper">
                  <div class="dt-sc-image-caption type6 blue">
                      <div class="dt-sc-image-wrapper">
                          <img width="768" height="480" src="<?php echo base_url();?>assets/site/images/9.jpg" class="img-fluid">
                          <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/b.png"></div>
                      </div>
                      <div class="dt-sc-image-content">
                          <div class="dt-sc-image-title">
                              <h3><a href="<?php echo base_url();?>him-logistic">HIM LOGISTICS PVT. LTD.</a></h3>
                          </div>
                          <p>An ISO 9001:2008 certified company, Him Logistocs Pvt Ltd is the flagship company of HLPL group...
                              <a href="<?php echo base_url();?>him-logistic" class="know">Know More</a>
                          </p>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <div class="col-sm-3 pl-0 pr-0">
          <div class="vc_column-inner ">
              <div class="wpb_wrapper">
                  <div class="dt-sc-image-caption type6 blue">
                      <div class="dt-sc-image-wrapper">
                          <img width="768" height="480" src="<?php echo base_url();?>assets/site/images/9.jpg" class="img-fluid">
                          <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/a.png"></div>
                      </div>
                      <div class="dt-sc-image-content">
                          <div class="dt-sc-image-title">
                              <h3><a href="<?php echo base_url();?>apace-transport"> Apace Transport Pvt. Ltd.</a></h3>
                          </div>
                          <p>Incorporated in 2009, APACE TRANCO PVT LTD has grown from few small trucks to a strong fleet...
                              <a href="<?php echo base_url();?>apace-transport" class="know">Know More</a>
                          </p>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <div class="col-sm-3 pl-0 pr-0">
          <div class="vc_column-inner ">
              <div class="wpb_wrapper">
                  <div class="dt-sc-image-caption type6 blue">
                      <div class="dt-sc-image-wrapper">
                          <img width="768" height="480" src="<?php echo base_url();?>assets/site/images/9.jpg" class="img-fluid">
                          <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/de.png"></div>
                      </div>
                      <div class="dt-sc-image-content">
                          <div class="dt-sc-image-title">
                              <h3><a href="<?php echo base_url();?>oak-shipping"> Oak Shipping Services Pvt. Ltd.</a></h3>
                          </div>
                          <p>Established as a Indian Freight forwarding company in 2005, OSS - Oak Shipping Services Pvt Ltd...
                              <a href="<?php echo base_url();?>oak-shipping" class="know">Know More</a>
                          </p>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <div class="col-sm-3 pl-0 pr-0">
          <div class="vc_column-inner ">
              <div class="wpb_wrapper">
                  <div class="dt-sc-image-caption type6 blue">
                      <div class="dt-sc-image-wrapper">
                          <img width="768" height="480" src="<?php echo base_url();?>assets/site/images/9.jpg" class="img-fluid">
                          <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/de.png"></div>
                      </div>
                      <div class="dt-sc-image-content">
                          <div class="dt-sc-image-title">
                              <h3><a href="<?php echo base_url();?>winsum-holidays"> Winsum Holidays </a></h3>
                          </div>
                          <p>Winsum is the dedicated arm of HLPL group committed to reward you with exciting and memorable holidays...
                              <a href="<?php echo base_url();?>winsum-holidays" class="know">Know More</a>
                          </p>
                      </div>
                  </div>
              </div>
          </div>
      </div>

      <div class="col-sm-3 pl-0 pr-0">
          <div class="vc_column-inner ">
              <div class="wpb_wrapper">
                  <div class="dt-sc-image-caption type6 blue">
                      <div class="dt-sc-image-wrapper">
                          <img width="768" height="480" src="<?php echo base_url();?>assets/site/images/9.jpg" class="img-fluid">
                          <div class="icon-wrapper"><img src="<?php echo base_url();?>assets/site/images/f.png"></div>
                      </div>
                      <div class="dt-sc-image-content">
                          <div class="dt-sc-image-title">
                              <h3><a href="<?php echo base_url();?>hlpl-global"> HLPL Global</a></h3>
                          </div>
                          <p>HLPL Global is a joint venture between the Gastl de group, Italy and HLPL group, India. It marks the international...
                              <a href="<?php echo base_url();?>hlpl-global" class="know">Know More</a>
                          </p>

                      </div>
                  </div>
              </div>
          </div>
      </div>

  </div>

  <!--
<section>
<div class="container">
  <div class="row mt-5 mb-5">
    <div class="col-sm-4 feature">
      <div class="card">
        <img src="images/frieght1.png" class="img-fluid">
        <h3>ROADWAY FREIGHT</h3>
        <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
      </div>
    </div>

      <div class="col-sm-4 feature">
      <div class="card">
        <img src="images/frieght2.png" class="img-fluid">
        <h3>ROADWAY FREIGHT</h3>
        <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
      </div>
    </div>

      <div class="col-sm-4 feature">
      <div class="card">
        <img src="images/frieght3.png" class="img-fluid">
        <h3>ROADWAY FREIGHT</h3>
        <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
      </div>
    </div>

  </div>

</div>
</section>-->

  <section class="counter">
      <div class="container">
          <div class="row">

              <div class="col-sm-12 text-center services">
                  <h2><span>FACTS AND</span> <strong>FIGURE</strong></h2>

              </div>

              <div class="col-sm-3">
                  <div class="dt-sc-counter type1  ">
                      <div class="dt-sc-couter-icon-holder">
                          <div class="icon-wrapper"><span><img src="images/unemployee.png" class="img-fluid" alt=""></span></div>
                          <div class="dt-sc-counter-number" data-value="251112">251112</div>
                      </div>
                      <p>Packages Delivered</p>
                  </div>
              </div>

              <div class="col-sm-3">
                  <div class="dt-sc-counter type1  ">
                      <div class="dt-sc-couter-icon-holder">
                          <div class="icon-wrapper"><span><img src="images/counter-icon2-1.png" class="img-fluid" alt=""></span></div>
                          <div class="dt-sc-counter-number" data-value="251112">19223</div>
                      </div>
                      <p>Repeat Customers</p>
                  </div>
              </div>

              <div class="col-sm-3">
                  <div class="dt-sc-counter type1  ">
                      <div class="dt-sc-couter-icon-holder">
                          <div class="icon-wrapper"><span><img src="images/counter-icon3-2.png" class="img-fluid" alt=""></span></div>
                          <div class="dt-sc-counter-number" data-value="251112">2331</div>
                      </div>
                      <p>Our Clients</p>
                  </div>
              </div>

              <div class="col-sm-3">
                  <div class="dt-sc-counter type1  border-0">
                      <div class="dt-sc-couter-icon-holder">
                          <div class="icon-wrapper"><span><img src="images/counter-icon4-1.png" class="img-fluid" alt=""></span></div>
                          <div class="dt-sc-counter-number" data-value="251112">1126336</div>
                      </div>
                      <p>Commercial Goods</p>
                  </div>
              </div>

          </div>
      </div>
  </section>

  <section class="testimonial-bg">
      <div class="container">
          <div class="row">
              <div class="col-sm-8 mx-auto">
                  <div class="testimonial-back">
                      <p>" What we require from our business partners is effective, quick and faultless logistics management. HIM Logistics not only achieves all of this, but is also a pleasure to work with and provides us with a personal and professional customer service. We can therefore confirm that we will count on HIM Logistics for all our future needs.</p>
                  </div>
              </div>
          </div>
      </div>
  </section>

  <?php include('include/footer.php'); ?>