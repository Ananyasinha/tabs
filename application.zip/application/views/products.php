<section id="innerpage-banner">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1><span>Advance Aqua Bio Technologies</span> Products</h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Products</li>
  </ol>
</nav>
</div>
</div>
</div>

</section>


<section id="certificate-page">
<div class="container">
<h2 class="home-section-title section-title">Our Products</h2>
<div class="home-border section-border inner-page"></div>
<div class="row">
<div class="col-md-3 col-sm-4 col-xs-12 sidebar">

<div class="sidebar-categories">
<h4>Categories</h4>
<?php
if(count(array_filter(getcategory()))>0)
{
$i=0;
foreach(getcategory() as $row)
{
?>	
<div class="main-categories">
	<h4><?php echo $row->fld_title;?></h4>
	<ul>
		<?php 
		$this->db->select('*');
		$this->db->from('tbl_category');
		$this->db->where('fld_parentid',$row->id);
		$this->db->where('status','Active');
		$this->db->order_by('fld_title','asc');
		$query = $this->db->get();
		//echo $this->db->last_query();
		//echo $query->num_rows();
		if($query->num_rows()>0)
		{
			
			foreach($query->result() as $row)
			{
			$i++;
			?>
			<li>
			<input type="checkbox" class="chkproduct" id="product<?php echo $i;?>" style="display:inline-block" onclick="return getproductlist('<?php echo base_url();?>','<?php echo $row->id;?>');" value="<?php echo $row->id;?>">
			<?php echo $row->fld_title;?>
			<span class="product-available">(<?php echo gettotalcatproduct($row->id)?>)</span>
			
			<!-- <label for="product<?php echo $i;?>" onclick="return getproductlist('<?php echo base_url();?>','<?php echo $row->id;?>');"><?php echo $row->fld_title;?> <span class="product-available">(<?php echo gettotalcatproduct($row->id)?>)</span></label>-->
			</li>
			<?php 
			}
		}
		?>
	</ul>
</div>
<?php 
}
}
?>


</div>

</div>
<div class="col-md-9 col-sm-8 col-xs-12">
<div class="main-product-row">
<div class="product" id="product-list">
	<?php 
	if(count(array_filter($result_product)) > 0){
	foreach($result_product as $row)
	{
	?>
	<div class="media">
		<div class="media-left">
			<?php if($row->fld_image!=""){?>
			<img src="<?php echo base_url();?>assets/productimg/<?php echo $row->fld_image;?>"  alt="<?php echo $row->fld_title;?>" class="media-object" />
			<?php }?>	
		</div>
		<div class="media-body">
			<h4 class="media-heading"><?php echo $row->fld_title;?></h4>
			<?php echo $row->fld_description;?>
		</div>
	</div>
    <?php
	}
	}
	?>
  
</div>

</div>
</div>
</div>

</div>


</div>
</div>

</section>