<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.ico">

    <title>Hot Spot</title>

    <link href="css/style.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.2/dist/jquery.fancybox.min.css" />
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

	


  </head>
  <body>


 <div class="wrapper">
 
   <header>
   
    <div class="container">
	  <div class="row">
	    <div class="col-sm-12">
		  <a href="index.html" class="logo"><img src="images/logo.png"></a>
		</div>
	  </div>
	</div>
	
	
	    <nav class="navbar navbar-expand-lg">
      <div class="container">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample07" aria-controls="navbarsExample07" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarsExample07">
          <ul class="navbar-nav mr-auto">
         <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
			<li class="nav-item"><a class="nav-link" href="movie.html">Movie</a></li>
			<li class="nav-item"><a class="nav-link" href="gossip.html">Gossips</a></li>
			<li class="nav-item"><a class="nav-link" href="gallery.html">Gallery</a></li>
			<li class="nav-item"><a class="nav-link" href="latest.html">Latest </a></li>
          </ul>
        </div>
      </div>
    </nav>
   
     <div class="clearfix"></div>
   </header>
   
   
    <div class="middile">
	<div class="container">
	<div class="row">
	<div class="col-md-8">
	<h3>Section 1.10.32 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC</h3>
	<p><a href="#">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, </a> "Lorem ipsum dolor sit amet, consectetur </p>
	<p> "But I must explain to you how all this mistaken idea of denouncing pleasure and"</p>
	<div class="row">
	<div class="col-md-12">
	<iframe width="100%" height="500px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div></div>

	<br>
	
	
	
		<p style="width:100%; border:1px solid red;paddind-top:6px;"></p>
	<h3 style="color:red">  More Videos</h3>
	<div class="row">
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	
	</div>
		<div class="row">
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	
	</div>
		<div class="row">
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	
	</div>
		<div class="row">
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	
	</div>
		<div class="row">
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	<div class="col-md-3">
	<iframe width="100%" height="100px" src="https://www.youtube.com/embed/lcL678AASFc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	<a href="#"><h5>Lorem Ipsum  Lorem Ipsum </h5></a>
	<p>But I must explain to you how all this mistaken idea of </p>
	
	</div>
	
	</div>
		<!-- <a href="#"> <b> Read More </b> </a> -->
	<br>
	

	
		<br>
			
	
	
	</div>
	<div class="col-md-4">
		<br>
	<p style="width:100%; border:1px solid red;paddind-top:6px;"></p>
	
		<h3 style="color:red"> We recommeded best for You</h3>
	
			<div class="row">
	<div class="col-md-6"> 
	<img src="images/gallery1.jpg" style="width:100%;">
	<a href="#"> 
	"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed 
	</a>
	</div>
	<div class="col-md-6"> 
	<img src="images/gallery1.jpg" style="width:100%;">
	<a href="#"> 
	"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed 
	</a>
	</div>


		

	</div>
	
				<div class="row">
	<div class="col-md-6"> 
	<img src="images/gallery1.jpg" style="width:100%;">
	<a href="#"> 
	"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed 
	</a>
	</div>
	<div class="col-md-6"> 
	<img src="images/gallery1.jpg" style="width:100%;">
	<a href="#"> 
	"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed 
	</a>
	</div>


		

	</div>

	</div>
	  </div>
	  </div>
	 <div class="clearfix"></div> 
	</div>
	
	
	<footer>
	
	  <div class="container">
	    <div class="row">
		  
		  <div class="col-sm-4 mb-3">
		    <h2>Copyright</h2>
			<p>Movies © 2018 • <a href="#">Privacy Policy</a></p>
		  </div>
		  
		  <div class="col-sm-4 mb-3">
		    <h2>Contact Us</h2>
			<ul>
			  <li><i class="fa fa-envelope-o"></i> <a href="#">mail@demolink.org</a></li>
			  <li><i class="fa fa-home"></i> Mill Road,Cambridge,</li>
			  <li><i class="fa fa-phone"></i> <a href="#">+1 800 559 6580</a></li>
			</ul>
		  </div>
		  
		  <div class="col-sm-4">
		    <h2>Follow Us</h2>
			 <div class="social">
			   <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
			   <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
			   <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
			   <a href="#" class="google"><i class="fa fa-google-plus"></i></a>
			 </div>
		  </div>
		  
		</div>
	  </div>
	
	 <div class="clearfix"></div>  
	</footer>
	
 
   <div class="clearfix"></div>   
 </div>
 

<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="js/bootstrap.js"></script>

<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.2/dist/jquery.fancybox.min.js"></script>
<script>$(document).ready(function(){
    //FANCYBOX
    //https://github.com/fancyapps/fancyBox
    $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
    });
});
   </script>



</body>
</html>
