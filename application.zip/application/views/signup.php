<style>
.overlay {
    padding-bottom: 3vh;
}
h1.mt-text {
    margin-top: 43px;
    color: #fff;
    font-family: 'Montserrat-Light';
}
.error {
    color: #f00;
}
.captchapanel {
    position: relative;
}
.captchapanel .captcha {
    position: absolute;
    right: 18px;
    top: 5px;
    background: #00c6ff;
    padding: 8px 24px;
    border-radius: 7px;
    color: #fff;
}
</style>
<section>
<ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="index.php">Home</a></li>
  <li class="breadcrumb-item active">Signup</li>
</ol>
</section>
<section>
   <div class="container">
      <div class="row form-back">
	<?php 
	if($this->session->userdata('alert_type')!="")
	{
		?>
		<div class="alert alert-<?php echo $this->session->userdata('alert_type');?>" style="text-align:center">
			<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
			<?php echo $this->session->userdata('msg');?>
		</div>
		<?php
	}
	?>  
<nav>
  <div class="nav nav-tabs" id="nav-tab" role="tablist">
    <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Personal Account
	  <p>I Am Looking For A Job</p>
	</a>
    <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Company Account
	<p>We Are Hiring Employees</p>
	</a>

  </div>
</nav>

<div class="tab-content" id="nav-tabContent">
<!--ist tab-->
  <div class="tab-pane fade show active bg-color" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
     <form id="userinfo" onsubmit="return signup('<?php echo base_url();?>');">
	 <div class="row">
                                        
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="text" name="usr_name" id="usr_name" value="" placeholder="Full Name*" class="form-control">
			<span class="error" id="usr_nameErr"></span>
		</div>

		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="text" name="usr_email" id="usr_email" value="" placeholder="Email*" class="form-control">
			<span class="error" id="usr_emailErr"></span>
		</div>
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">

			<input type="password" name="usr_password" id="usr_password" value="" placeholder="Password*" class="form-control">
			<span class="error" id="usr_passwordErr"></span>
		</div>
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="password" name="usr_cnfpassword" id="usr_cnfpassword" value="" placeholder="Re-enter password*" class="form-control">
			<span class="error" id="usr_cnfpasswordErr"></span>
		</div>
		
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
		<select class="form-control" name="usr_state" id="usr_state">
			<option value=""> Select State</option>
			<?php
			if(count(array_filter(getstate()))>0)
			{
				foreach(getstate() as $key=>$value)
				{
				?>
				<option value="<?php echo $value;?>"> <?php echo $value;?></option>
				<?php
				}
			}
			?>
			
		</select>
		<span class="error" id="usr_stateErr"></span>
		</div>
		
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="text" name="usr_city" id="usr_city" value="" placeholder="City*" class="form-control">
			<span class="error" id="usr_cityErr"></span>
		</div>
		
		
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">

			<input type="text" name="usr_phone" id="usr_phone" value="" placeholder="Phone" class="form-control">
			<span class="error" id="usr_phoneErr"></span>
		</div>

		<div class="form-group col-md-6 col-sm-6 col-xs-12">

			<textarea type="text" name="usr_address" id="usr_address" value="" placeholder="Address" class="form-control"></textarea>
			<span class="error" id="usr_addressErr"></span>
		</div>
		  <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="check-box text-center">
				<input type="checkbox" name="shipping-option" id="usr_iagree"> &ensp;
				<label for="account-option_1">I agreed to the <a href="terms-condition.php" class="check_box_anchr">Terms and Conditions</a> governing the use of jobportal</label>
				<span class="error" id="usr_iagreeErr"></span>
			</div>
		</div>
		<div class="col-sm-6 text-left captchapanel">
			<input name="usr_c_captcha" id="usr_c_captcha" placeholder="Enter Code *" type="text" class="form-control">
			<div class="captcha"><?php echo $captchacode = rand(111111,999999);?></div>
			<input type="hidden" id="usr_ccode" value="<?php echo $captchacode;?>" />
			<span id="usr_cmntcaptcha" class="error"></span>
			<div id="msgloader"></div>
		</div>
		
		<div class="col-sm-6 text-right">
		<input type="submit" class="btn btn-primary login_btn" id="sbmtbtn" value="Register"> 
		</div>	
	</div>
  </form>
  </div>
  <!--ist tab-->
  
  
  <!--iind tab-->
  <div class="tab-pane fade bg-color" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
	<form id="companyinfo" onsubmit="return signupcomp('<?php echo base_url();?>');">
	<div class="row">
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="text" name="cmp_name" id="cmp_name" value="" placeholder="Full Name*" class="form-control">
			<span class="error" id="cmp_nameErr"></span>
		</div>

		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="text" name="cmp_email" id="cmp_email" value="" placeholder="Email*" class="form-control">
			<span class="error" id="cmp_emailErr"></span>
		</div>
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="password" name="cmp_password" id="cmp_password" value="" placeholder="Password*" class="form-control">
			<span class="error" id="cmp_passwordErr"></span>
		</div>
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="password" name="cmp_cnfpassword" id="cmp_cnfpassword" value="" placeholder="Re-enter password*" class="form-control">
			<span class="error" id="cmp_cnfpasswordErr"></span>
		</div>
		
		<!--Form Group-->
		<div class="form-group col-md-4 col-sm-6 col-xs-12">
		<select class="form-control" name="cmp_state" id="cmp_state">
			<option value=""> Select State</option>
			<?php
			if(count(array_filter(getstate()))>0)
			{
				foreach(getstate() as $key=>$value)
				{
				?>
				<option value="<?php echo $value;?>"> <?php echo $value;?></option>
				<?php
				}
			}
			?>
			
		</select>
		<span class="error" id="cmp_stateErr"></span>
		</div>
		
		<div class="form-group col-md-4 col-sm-6 col-xs-12">
			<input type="text" name="cmp_city" id="cmp_city" value="" placeholder="City*" class="form-control">
			<span class="error" id="cmp_cityErr"></span>
		</div>
		
		<div class="form-group col-md-4 col-sm-6 col-xs-12">
			<input type="text" name="cmp_company" id="cmp_company" value="" placeholder="Company Name*" class="form-control">
			<span class="error" id="cmp_companyErr"></span>
		</div>
		
		
		<!--Form Group-->
		<div class="form-group col-md-6 col-sm-6 col-xs-12">
			<input type="text" name="cmp_phone" id="cmp_phone" value="" placeholder="Phone" class="form-control">
			<span class="error" id="cmp_phoneErr"></span>
		</div>

		<div class="form-group col-md-6 col-sm-6 col-xs-12">

			<textarea type="text" name="cmp_address" id="cmp_address" value="" placeholder="Address" class="form-control"></textarea>
			<span class="error" id="cmp_addressErr"></span>
		</div>
		  <div class="form-group col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="check-box text-center">
				<input type="checkbox" name="shipping-option" id="cmp_iagree"> &ensp;
				<label for="account-option_1">I agreed to the <a href="terms-condition.php" class="check_box_anchr">Terms and Conditions</a> governing the use of jobportal</label>
				<span class="error" id="cmp_iagreeErr"></span>
			</div>
		</div>
		<div class="col-sm-8 text-left captchapanel">
			<input name="cmp_c_captcha" id="cmp_c_captcha" placeholder="Enter Code *" type="text" class="form-control">
			<div class="captcha"><?php echo $captchacode = rand(111111,999999);?></div>
			<input type="hidden" id="cmp_ccode" value="<?php echo $captchacode;?>" />
			<span id="cmp_cmntcaptcha" class="error"></span>
			<div id="cmp_msgloader"></div>
		</div>
		
		<div class="col-sm-4 text-right">
		<input type="submit" class="btn btn-primary login_btn" id="cmp_sbmtbtn" value="Register"> 
		</div>
		
	</div>
	</form>
  </div>
  <!--iind tab-->

</div>
			 
			 
      </div>
   </div>
</section>