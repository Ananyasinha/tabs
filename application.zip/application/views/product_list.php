<section id="innerpage-banner">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1><span>ADVANCE AQUA BIO TECHNOLOGIES</span><?php echo $result->fld_title;?></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo $result->fld_title;?></li>
  </ol>
</nav>
</div>
</div>
</div>

</section>


<section id="certificate-page">
<div class="container">
<h2 class="home-section-title section-title"><?php echo $result->fld_title;?></h2>
<div class="home-border section-border inner-page"></div>
<div class="row">

<div class="col-md-12 col-sm-12 col-xs-12">
<div class="main-product-row">
<div class="product">
	<?php 
	if(count(array_filter($result_product)) > 0){
	foreach($result_product as $row)
	{
	?>
	<div class="media">
		<div class="media-left">
			<?php if($row->fld_image!=""){?>
			<img src="<?php echo base_url();?>assets/productimg/<?php echo $row->fld_image;?>"  alt="<?php echo $row->fld_title;?>" class="media-object" />
			<?php }?>	
		</div>
		<div class="media-body">
			<h4 class="media-heading"><?php echo $row->fld_title;?></h4>
			<?php echo $row->fld_description;?>
		</div>
	</div>
    <?php
	}
	}
	?>
  
  
</div>

</div>
</div>
</div>

</div>


</div>
</div>

</section>
