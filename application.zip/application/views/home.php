<section id="homepageslider">
<div class="container-fluid">
<div class="row">
<div class="col-md-6 res-co">
</div>
<div class="col-md-6 slider-text">
<div class="inner-slider-content">
<h1><?php echo $pageshortdescription;?></h1>
<p><?php echo $pagedescription;?></p>
<a href="<?=base_url()?>contact-us" class="contact-us">Contact Us</a>
</div>
</div>
</div>
</div>
</section>
<section id="homeaboutus">
<div class="container">
<div class="row">
<div class="col-md-7">
<h2 class="home-section-title">About Us</h2>
<div class="home-border"></div>
<p><?php echo word_limiter($pagedescriptionabout,210);?></p>
<p><a href="<?=base_url()?>about-us" class="read-more">Read more</a></p>
</div>
<div class="col-md-5 quick-enq">
<h2 class="home-section-title">Quick Enquiry</h2>
<div class="home-border"></div>
 <div class="clearfix"></div>
 <div id="msgloader"></div>
 <form class="form-horizontal" id="quickenquiryfrm">
    <div class="form-group">
      <div class="col-sm-12">
        <input type="text" name="name" id="name" class="form-control" placeholder="Name">
		<span id="nameErr" class="error"></span>
      </div>
    </div>
	<div class="form-group">
      <div class="col-sm-12">
        <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone No.">
		<span id="phoneErr" class="error"></span>
      </div>
    </div>
	<div class="form-group">
      <div class="col-sm-12">
        <input type="text" name="email" id="email" class="form-control"  placeholder="Email ID">
		<span id="emailErr" class="error"></span>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-12">    
		<textarea class="form-control" rows="3" name="message" id="message" placeholder="Comment"></textarea>
		<span id="messageErr" class="error"></span>
      </div>
    </div>
	<div class="form-group">
	  <div class="col-sm-12"> 
		<div class="g-recaptcha" data-sitekey="6LekO0IUAAAAAJ4vXxHLtIihh7aAGQAnS-ZRnfkU"></div>
		<span id="captcha" class="error" style="margin-left:30px;color:red" /></span>
	  </div>
	</div>
    <div class="form-group">        
      <div class="col-sm-12">
        <button type="button" id="sbmtbtn" onclick="return validatequickenquiry('<?php echo base_url();?>');" class="btn btn-default homeenq">Send</button>
      </div>
    </div>
  </form>
</div>
</div>
</div>
</section>
<section id="ourproduct">
<div class="container">
<div class="row">
<h2 class="home-section-title section-title">Our Category </h2>
<div class="home-border section-border"></div>
<div class="row pro-row">
<?php if(count(array_filter($result_category)) > 0){
foreach($result_category as $row){
?>
<div class="col-md-3 col-sm-6 fish">
<div class="home-product">
<?php if($row->fld_image!=""){?>
<img src="<?php echo base_url();?>assets/productimg/<?php echo $row->fld_image;?>"  alt="<?php echo $row->fld_title;?>" />
<?php }?>
<h4><a href="<?php echo base_url();?>category/<?php echo generatePermaLink(trim($row->fld_title));?>-<?php echo $row->id;?>"><?php echo $row->fld_title;?></a></h4>
</div>
</div>
<?php 
	}
}
?>
</div>
</div>
</div>
</section>
<section id="gallery">
<div class="container-fluid">
<h2 class="home-section-title section-title">Gallery</h2>
<div class="home-border section-border"></div>

<div class="row pro-row view-all">
	<a href="<?php echo base_url();?>gallery" class="view-button">View All <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
	<?php
    if(count(array_filter($result)) > 0){
	  $i=0;
	  foreach($result as $row){
	  $i++;
      if($row->fld_image!=""){?>
			<div class="col-md-3 col-sm-3 col-xs-12">
			<img src="<?php echo base_url();?>assets/galleryimg/<?php echo $row->fld_image;?>" alt="gallery" height='220px';>
			</div>
   <?php } } }?>
	
</div>
</div>
<div class="container gallery">
<div class="row">
<div class="col-md-4 tag-im">
<img src="images/red-tag.jpg" alt="Red Tag">
<h2>Our Certifications</h2>
<div class="home-border section-border gallery-bor"></div>
</div>
<div class="col-md-8">
<div class="row right-side-certificates">
<?php if(count(array_filter($result_certificate)) > 0){
foreach($result_certificate as $row){
?>
<div class="col-md-4 certificates">
<img src="<?php echo base_url();?>assets/certificateimg/<?php echo $row->fld_image;?>" alt="certificate 1">
<p><a href="<?php echo base_url();?>certificates"><?php echo $row->fld_title;?></a></p>
</div>
<?php 
	}
}
?>
</div>
</div>
</div>
</div>
</section>
<section id="fivesec">
<div class="container">
<ul class="five-sec">
<li><span class="img-container"><img src="images/like.jpg" alt="like"></span><p>Lorem Ipsum</p></li>
<li><span class="img-container"><img src="images/clock.jpg" alt="clock"></span><p>Lorem Ipsum</p></li>
<li><span class="img-container"><img src="images/right.jpg" alt="right"></span><p>Lorem Ipsum</p></li>
<li><span class="img-container"><img src="images/star.jpg" alt="star"></span><p>Lorem Ipsum</p></li>
<li><span class="img-container"><img src="images/badge.jpg" alt="badge"></span><p>Lorem Ipsum</p></li>
</ul>
</div>
</section>