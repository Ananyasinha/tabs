
<div class="middile">
    <div class="container">
        <div class="row">
            <div class="col-sm-9">
                <div class="row">
                    <div class="col-sm-8">
                        <div class="home-slide">
                            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                                <ol class="carousel-indicators">
                                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                    <li data-target="#myCarousel" data-slide-to="1"></li>
                                    <li data-target="#myCarousel" data-slide-to="2"></li>
                                </ol>
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img class="first-slide" src="<?php echo base_url();?>assets/site/images/banner1.jpg" alt="First slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="second-slide" src="<?php echo base_url();?>assets/site/images/banner1.jpg" alt="Second slide">
                                    </div>
                                    <div class="carousel-item">
                                        <img class="third-slide" src="<?php echo base_url();?>assets/site/images/banner1.jpg" alt="Third slide">
                                    </div>
                                </div>
                                <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                        </div>

                        <div class="latest-gallery mt-5">

                            <nav class="mb-5">
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <a class="nav-item nav-link active" id="nav-Latest-tab" data-toggle="tab" href="#nav-Latest" role="tab" aria-controls="nav-home" aria-selected="true">Latest</a>

                                    <a class="nav-item nav-link" id="nav-Gallery-tab" data-toggle="tab" href="#nav-Gallery" role="tab" aria-controls="nav-profile" aria-selected="false">Gallery</a>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-Latest" role="tabpanel" aria-labelledby="nav-Latest-tab">

                                    <div class="row">

                                        <div class="col-sm-6">
                                            <div class="gallery-home">
                                                <h3>Lorem Ispum</h3>
                                                <img src="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="img-fluid">
                                                <div class="overlay">
                                                    <a href="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                                </div>
                                            </div>
                                            <h4>10th Sep 2014</h4>
                                            <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                        </div>

                                        <div class="col-sm-6">

                                          

                                            <div class="gallery-home">
                                                <h3>Lorem Ispum</h3>
                                                <img src="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="img-fluid">
                                                <div class="overlay">
                                                    <a href="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                                </div>
                                            </div>

                                            <h4>10th Sep 2014</h4>
                                            <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                      
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="gallery-home">
                                                <h3>Lorem Ispum</h3>
                                                <img src="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="img-fluid">
                                                <div class="overlay">
                                                    <a href="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                                </div>
                                            </div>
                                            <h4>10th Sep 2014</h4>
                                            <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="gallery-home">
                                                <h3>Lorem Ispum</h3>
                                                <img src="<?php echo base_url();?>assets/site/images/gallery4.jpg" class="img-fluid">
                                                <div class="overlay">
                                                    <a href="<?php echo base_url();?>assets/site/images/gallery4.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                                </div>
                                            </div>
                                            <h4>10th Sep 2014</h4>
                                            <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                        </div>

                                        <a class="see-all" href="#">See All</a>

                                    </div>

                                </div>
                                <div class="tab-pane fade" id="nav-Gallery" role="tabpanel" aria-labelledby="nav-Gallery-tab">

                                    <div class="row">

                                       
                                    <?php
                                     if(count(array_filter($gallery)) > 0){
                                          $i=0;
                                          foreach($gallery as $row){
                                          $i++;
                                          if($row->fld_image!=""){?>

                                        <div class="col-sm-6">
                                            <div class="gallery-home">
                                                <h3>Lorem Ispum</h3>
                                                <img src="<?php echo base_url();?>assets/site/images/gallery4.jpg" class="img-fluid">
                                                <div class="overlay">
                                                    <a href="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                                </div>
                                            </div>
                                            <h4>10th Sep 2014</h4>
                                            <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                        </div>
                                    <?php } } } ?>
                                      <!--   <div class="col-sm-6">
                                            <div class="gallery-home">
                                                <h3>Lorem Ispum</h3>
                                                <img src="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="img-fluid">
                                                <div class="overlay">
                                                    <a href="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                                </div>
                                            </div>
                                            <h4>10th Sep 2014</h4>
                                            <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="gallery-home">
                                                <h3>Lorem Ispum</h3>
                                                <img src="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="img-fluid">
                                                <div class="overlay">
                                                    <a href="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                                </div>
                                            </div>
                                            <h4>10th Sep 2014</h4>
                                            <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                        </div>

                                        <div class="col-sm-6">
                                            <div class="gallery-home">
                                                <h3>Lorem Ispum</h3>
                                                <img src="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="img-fluid">
                                                <div class="overlay">
                                                    <a href="<?php echo base_url();?>assets/site/images/gallery4.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                                </div>
                                            </div>
                                            <h4>10th Sep 2014</h4>
                                            <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                        </div>
 -->
                                        <a class="see-all" href="#">See All</a>

                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="col-sm-4 mt-5">
                        <div class="events-home">
                            <h1 class="heading">Events</h1>

                            <div class="inner hovereffect">
                                <img class="img-responsive" src="<?php echo base_url();?>assets/site/images/event1.jpg" alt="">
                                <div class="overlay">
                                    <h3>2nd Jan 2013 <span>VOLUPTATE VELIT ESSE</span></h3>
                                    <a class="info" href="#"></a>
                                </div>
                            </div>

                            <div class="inner hovereffect">
                                <img class="img-responsive" src="<?php echo base_url();?>assets/site/images/event2.jpg" alt="">
                                <div class="overlay">
                                    <h3>2nd Jan 2013 <span>VOLUPTATE VELIT ESSE</span></h3>
                                    <a class="info" href="#"></a>
                                </div>
                            </div>

                            <div class="inner hovereffect">
                                <img class="img-responsive" src="<?php echo base_url();?>assets/site/images/event3.jpg" alt="">
                                <div class="overlay">
                                    <h3>2nd Jan 2013 <span>VOLUPTATE VELIT ESSE</span></h3>
                                    <a class="info" href="#"></a>
                                </div>
                            </div>

                        </div>

                        <div class="popular-home mt-3 text-center">
                            <h2 class="heading">Popular</h2>

                            <div class="inner">
                                <a href="#">
                                    <h3>2nd Jan 2013</h3>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </a>
                            </div>

                            <div class="inner">
                                <a href="#">
                                    <h3>13th Feb 2013</h3>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </a>
                            </div>

                            <div class="inner">
                                <a href="#">
                                    <h3>14th Feb 2013</h3>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </a>
                            </div>

                            <a class="see-all" href="#">See All</a>

                        </div>

                    </div>

                    <div class="clearfix"></div>

                    <div class="col-sm-12 mt-5">
                        <div class="row">

                            <div class="col-sm-4 mb-3 text-center">

                                <h2 class="heading light text-center">Gossips</h2>

                                <?php if(count(array_filter($result)) > 0){
                                   foreach($result as $row){
                                ?>
                                <div class="home-bottom text-center">
                                    <h3><?php echo $row->gossips_title;?></h3>

                                    <p><?php echo $row->description;?></p>
                                </div>

                                <?php } } ?>

                                <div class="home-bottom text-center">
                                    <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3>
                                    <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, dignissim, pulvinar ac,...</p>
                                </div>

                                <div class="home-bottom text-center">
                                    <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3>
                                    <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, dignissim, pulvinar ac,...</p>
                                </div>

                                <a class="see-all" href="#">See All</a>

                            </div>

                            <div class="col-sm-4 mb-3 text-center">

                                <h2 class="heading light text-center">Now in Theaters</h2>

                                <div class="home-bottom text-center">
                                    <img src="<?php echo base_url();?>assets/site/images/theater.jpg" class="img-fluid">
                                    <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3>
                                    <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, dignissim, pulvinar ac,...</p>
                                </div>

                                <a class="see-all" href="#">Read More</a>

                            </div>

                            <div class="col-sm-4  text-center">

                                <h2 class="heading light text-center">Gallery</h2>

                                <div class="home-bottom text-center">
                                    <img src="<?php echo base_url();?>assets/site/images/gallery.jpg" class="img-fluid">
                                    <h3>Lorem ipsum dolor sit amet ce ctetur adipis</h3>
                                    <p>Aliquam dapibus tincidunt metus. Praesent justo dolor, lobortis quis, dignissim, pulvinar ac,...</p>
                                </div>

                                <a class="see-all" href="#">See All</a>

                            </div>

                        </div>
                    </div>

                </div>
            </div>

            <div class="col-sm-3 mt-5">

                <div class="col-sm-12 pr-0 pl-0">
                    <div class="home-right-box">
                        <h3>Lorem Ispum</h3>
                        <a href="#"><img src="<?php echo base_url();?>assets/site/images/right1.jpg" class="img-fluid"></a>
                        <a href="#">
                            <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
                        </a>
                    </div>
                </div>

                <div class="col-sm-12 pr-0 pl-0">
                    <div class="home-right-box">
                        <h3>Lorem Ispum</h3>
                        <a href="#"><img src="<?php echo base_url();?>assets/site/images/right1.jpg" class="img-fluid"></a>
                        <a href="#">
                            <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
                        </a>
                    </div>
                </div>

                <div class="col-sm-12 pr-0 pl-0">
                    <div class="home-right-box last">
                        <a href="#"><img src="<?php echo base_url();?>assets/site/images/right2.jpg" class="img-fluid"></a>
                        <a href="#">
                            <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
                        </a>
                    </div>
                </div>

            </div>

        </div>
    </div>

    <div class="clearfix"></div>
</div>

