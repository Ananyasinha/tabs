<ul class="breadcrumb mb-0">
    <li class="breadcrumb-item"><a href="<?php echo base_url();?>catalog">Home</a></li>
    <li class="breadcrumb-item"><a href="#">Management</a></li>
</ul>

<section>
    <div class="container">
        <div class="row pt-5 pb-5">

            <div class="col-sm-12 text-center services">
                <h2><span>Message</span> <strong>From Chairman</strong></h2>

            </div>

        </div>
        <?php echo $pagedetail[0]['fld_description']?>

       <!--  <div class="row">
            <p class="text-justify"><img src="assets/site/images/management.png" style="float: left;
             margin-right: 10px;">
                <strong class="pb-3"> Dear Patron!</strong>
                <br/> I am pleased to reach you through this letter to inform you that…. We are a different company in the industry and understand your timely requirements! We stick to our commitments and meet your expectations every time and all the time! The way we plan, execute and handle a given assignment makes all the difference! The shortest time we take to achieve and deliver of sea/air/ road mode of - Exports/imports - is.... all it counts!
                <br/>
                <br/>
                <strong>
             We know the knack to crack an issue!</strong>
                <br/> Our professionally trained teams work on the basis of our company’s philosophy – turn impossibilities to possibilities - and it makes all the difference! We take things to our heart and put our best plans and brain to execute the way it should be! In crisp, we know what and how the industry wants us to handle and execute. We have been doing our best work and that is the reason you put us at The top of the line of performers in this service industry….. by taking us to

            </p>
        </div>

        <div class="row">
            <h5>Number one slot!</h5>

            <p>
                Not once ……….but thrice for the past three years …….…every year in a row. Our heart is filled with gratitude and we keep marching with your support and assure you a good return every time you trust us. Yes this is our Him Logistics Pvt. Ltd….. just -not a team……..
            </p>
            <div class="col-sm-12">
                <p>
                    <h4>
					But an Extended  Family of Performers!</h4> We turn all impossible to possible! Best regards and seasons compliments
                 <br/><br/>
             <strong> P.C.Sharma <br/>
Chairman and Managing Director</strong></p>
            </div>
        </div>
 -->
    </div>
</section>
