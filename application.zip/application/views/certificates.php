<section id="innerpage-banner">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1><span>Advance Aqua Bio Technologies</span> Certificates</h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Certificates</li>
  </ol>
</nav>
</div>
</div>
</div>

</section>


<section id="certificate-page">
<div class="container">
<h2 class="home-section-title section-title">Certificates </h2>
<div class="home-border section-border inner-page"></div>
<div class="row">
<?php if(count(array_filter($result)) > 0){
foreach($result as $row){
?>
<div class="col-md-3 col-sm-6 col-xs-12">
	<div class="certi">
		<div class="cerimg">
		
		<?php if($row->fld_image!=""){?>
		<img src="<?php echo base_url();?>assets/certificateimg/<?php echo $row->fld_image;?>" />
		<?php }?>
		</div>
		<ul>
		<?php if($row->fld_industry!=""){?> <li><span>Industry :</span> <?php echo $row->fld_industry;?></li> <?php }?>
		<?php if($row->fld_country!=""){?> 	<li><span>Country :</span> <?php echo $row->fld_country;?></li> <?php }?>
		<?php if($row->fld_toolused!=""){?> 	<li><span>Tools Used :</span> <?php echo $row->fld_toolused;?></li> <?php }?>
		</ul>
	</div>
</div>
<?php 
	}
}
?>

</div>
</div>

</section>