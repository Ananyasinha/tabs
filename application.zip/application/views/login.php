
<style>
.overlay {
    padding-bottom: 3vh;
}
h1.mt-text {
    margin-top: 43px;
    color: #fff;
    font-family: 'Montserrat-Light';
}
.error {
    color: #f00;
}
</style>
<section>
<ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="index.php">Home</a></li>
  <li class="breadcrumb-item active">Login</li>
</ol>
</section>

<section>
   <div class="container">
      <div class="row form-back">
	      
		<div class="login-box mx-auto">
		  <h2 class="text-center pb-3">Login</h2>
							
			<form id="loginform" class="form-horizontal" role="form" onsubmit="return loginuser('<?php echo base_url();?>');">			
			<div class="form-group i-email">
				<input type="text" class="form-control"  name="useremail" id="useremail" value="" placeholder="Email" />
				<span id="useremailErr" class="error"></span>
			</div>
	
	
			<div class="form-group i-password">
				<input type="password" class="form-control" name="userpassword" id="userpassword" placeholder="password" />
				<span id="userpasswordErr" class="error"></span>
			</div>
		
			
			<div class="login_btn_wrapper">
				<input type="submit" class="btn btn-primary login_btn" value="Login">
				<div id="loginloader"></div>
			</div>
			</form>
			<div class="login_remember_box mb-3">								
				<a href="forgot-password.php" class="forget_password">
					Forgot Password
				</a>
			</div>
			<div class="login_message">
				<p>Don’t have an account ? <a href="<?php echo base_url();?>signup"> Register Now </a> </p>
			</div>
		</div>
			 
			 
      </div>
   </div>
</section>