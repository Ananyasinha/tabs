
<ul class="breadcrumb mb-0">
<li class="breadcrumb-item"><a href="<?php echo base_url();?>catalog">Home</a></li>
<li class="breadcrumb-item"><a href="#">HLPL Global</a></li>
</ul>
<!--
<section class="bg-primary inner-banner">
	<div class="container">
			<div class="row text-center pt-4 pb-4">
	
			</div>
	</div>
</section>
-->

<section>
	<div class="container">
		<div class="row pt-5 pb-5">
			<div class="col-sm-12 text-center services mt-0 mb-2">
			    <h2><span>About</span> <strong><?php echo $details[0]['title'];?></strong></h2>
	       </div>
			<div class="col-sm-12 text-justify">
				<?php echo $details[0]['grp_content'];?>
			</div>  
		</div>
	</div>
</section>
