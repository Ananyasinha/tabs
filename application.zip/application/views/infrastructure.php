<ul class="breadcrumb mb-0">
	<li class="breadcrumb-item"><a href="<?php echo base_url();?>catalog">Home</a></li>
	<li class="breadcrumb-item"><a href="#">Infrastructure</a></li>
</ul>

<section>
	<div class="container">
	    <div class="row pt-5 pb-5">
	        <div class="col-sm-12 text-center">
	            <h2 class="">Infrastructure</h2>
	            <p class="col-sm-8 mx-auto">The HLPL Group is one of the fastest progressing Custom House Agents, International freight forwarders, Transport Fleet owners & contractors.</p>
	        </div>
	        <div class="col-sm-6 infra"><img src="<?php echo base_url();?>assets/site/images/infrastructure.jpg" class="img-fluid"></div>
	        <div class="col-sm-6 text-justify infra-point">
	            <ol>
	                <li>Well established company owned office premises in the heart of the capital city - New Delhi</li>
	                <li>Offices at every major port of the country</li>
	                <li>Vast Warehouse area of 50000 sq. ft. to store & handle goods.</li>
	                <li>A unit of 10,000 sq ft. at Foreign Trade zone.</li>
	                <li>Fleet of 190 plus trailers; include 40ft & 20 ft container trucks, Tata 407, canter, small intercity vehicles and long haul trans-country vehicles. </li>
	                <li>A fully equipped and modern material tracking system to ensure error free distribution of goods</li>
	                <li>A well trained professional team of Re-packing and palletizing for handling re-distribution and labeling of cargoes.</li>
	                <li>A dedicated labor force for proper handling by forklifts/cranes as well as manually for any size of cargo entrusted on us.</li>
	                <li>Dedicated work force of 300 plus employees.</li>

	            </ol>
	        </div>
	    </div>
	</div>
</section>