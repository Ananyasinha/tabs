
<ul class="breadcrumb mb-0">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item"><a href="#">Gallery</a></li>
</ul>
<!--
<section class="bg-primary inner-banner">
<div class="container">
		<div class="row text-center pt-4 pb-4">
			<div class="col-sm-12 text-center">
			<h2 class="text-light">Gallery</h2>
			<p class="col-sm-8 mx-auto text-light">The HLPL Group is one of the fastest progressing Custom House Agents, International freight forwarders, Transport Fleet owners & contractors.</p>
			</div>

		</div>
</div>
</section>-->
<section>
    <div class="container">
        <div class="row pt-5 pb-5">

        	<?php if(count(array_filter($result1)) > 0){ 
        		foreach($result1 as $row){
            ?>
            <div class="col-sm-4">
                <div class="card gallery">
                    <img src="<?php echo base_url();?>assets/galleryimg/<?php echo $row['fld_image'];?>" class="img-fluid" style="height: 232px !important;">
                    <h3><?php echo $row['title'];?></h3>
                    <a href="<?php echo base_url();?>custom-house-agent" class="btn btn-warning float-right">View All</a>
                </div>
            </div>

        <?php } } ?>

        </div>
    </div>
</section>
