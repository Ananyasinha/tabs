<style>
img.hover-shadow.cursor {
    height: 210px!important;
    width: 100%!important;
    margin-top: 10%;
}
</style>

<section id="innerpage-banner">
<div class="container">
<div class="row">
<div class="col-md-12">
<h1><span>Advance Aqua Bio Technologies</span> Gallery</h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Gallery</li>
  </ol>
</nav>
</div>
</div>
</div>
</section>

<section id="gallery">
<div class="container">
<div class="row">
<h2 class="home-section-title section-title">Our Gallery</h2>
<div class="home-border section-border"></div>
<div class="col-md-12">
<div class="row product-row">
    <?php
    if(count(array_filter($result)) > 0){
	  $i=0;
	  foreach($result as $row){
	  $i++;
      if($row->fld_image!=""){?>

			<div class="column">
				<img src="<?php echo base_url();?>assets/galleryimg/<?php echo $row->fld_image;?>" onclick="openModal();currentSlide(<?php echo $i;?>)" class="hover-shadow cursor">
			</div>
     <?php } } }?>


</div>

<div id="myModal" class="modal">
  <span class="close cursor" onclick="closeModal()">&times;</span>
  <div class="modal-content">
    <?php
	    if(count(array_filter($result)) > 0){
	    	$num_files = count($result)-2;
		  $i=0;
		  foreach($result as $row){
		  $i++;
			?>
			<div class="mySlides">
			  <div class="numbertext"><?php echo $i;?> / <?php echo $num_files;?></div>
			  <img src="<?php echo base_url();?>assets/galleryimg/<?php echo $row->fld_image;?>" >
			</div>
			<?php
		  }
		}
	?>
    
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>

    <div class="caption-container">
      <p id="caption"></p>
    </div>


    
    <?php
	 if(count(array_filter($result)) > 0){
		  $i=0;
		  foreach($result as $row){
		  $i++;
	      if($row->fld_image!=""){?>

			<div class="column">
			  <img class="demo cursor" src="<?php echo base_url();?>assets/galleryimg/<?php echo $row->fld_image;?>" onclick="currentSlide(<?php echo $i;?>)" alt="Prawn Products" style="margin-top: 8%;">
			</div>
	<?php } } }?>

  </div>
</div>

<script>
function openModal() {
  document.getElementById('myModal').style.display = "block";
}

function closeModal() {
  document.getElementById('myModal').style.display = "none";
}

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>

</div>
</div>
</div>

</section>