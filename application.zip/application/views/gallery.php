
<div class="middile">

<div class="container">
    <div class="row">

        <div class="col-sm-12">
            <div class="row">
                <div class="col-sm-12">

                    <div class="latest-gallery mt-5">

                        <nav class="mb-5">
                            <div class="nav nav-tabs" id="nav-tab" role="tablist">

                                <a class="nav-item nav-link" id="nav-Gallery-tab" data-toggle="tab" href="#nav-Gallery" role="tab" aria-controls="nav-profile" aria-selected="false">Gallery</a>
                            </div>
                        </nav>

                        <div class="tab-pane fade in" id="nav-Gallery" role="tabpanel" aria-labelledby="nav-Gallery-tab">

                            <div class="row">

                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery4.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery1.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>

                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery3.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery2.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>
                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery3.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery2.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>

                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery2.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>
                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery2.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>
                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery2.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>
                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery2.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>
                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery2.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>
                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery2.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>
                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery2.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>
                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery2.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery3.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>

                                <div class="col-sm-3">
                                    <div class="gallery-home">
                                        <h3>Lorem Ispum</h3>
                                        <img src="images/gallery1.jpg" class="img-fluid">
                                        <div class="overlay">
                                            <a href="images/gallery4.jpg" class="link thumbnail fancybox" data-fancybox="gallery">+</a>
                                        </div>
                                    </div>
                                    <h4>10th Sep 2014</h4>
                                    <p>Curabitur facilisis pellentesque pharetra donec justo urna</p>
                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    </div>

    <div class="clearfix"></div>
</div>