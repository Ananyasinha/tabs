<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Gossips Section </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">gossips</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
    <!-- Main content -->
    <section class="content">
	<?php 
	if($this->session->userdata('alert_type')!="")
	{
		?>
		<div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
			<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
			<?php echo $this->session->userdata('msg');?>
		</div>
		<?php
		$this->session->unset_userdata('alert_type');
		$this->session->unset_userdata('msg');
	}
	?>
      <div class="row">
        <div class="col-12">
         
		 <div class="card">
            
            <!-- /.card-header -->
            <div class="card-body table-responsive">
              <table id="example1" class="table table-bordered table-striped text-center">
                <thead>
                <tr>
                  <th>S.no</th>
                  <th>Title</th>
                   <th>Description</th>
				  <th style="text-align:center">Posted On</th>
                  <th style="text-align:center">Action</th>
                </tr>
                </thead>
                <tbody>
				<?php 
				$i=1;
				if(count(array_filter($result)) > 0){
					foreach($result as $row){
					?>
					<tr>
					  <td><?php echo $i;?></td>
					  <td><?php echo $row->gossips_title;?></td>
					  <td><?php echo $row->description;?></td>

					  <td style="text-align:center"><?php echo convertdate($row->created_on,'d M Y')?></td>
					
					  <td style="text-align:center">
						
						<a href="<?php echo base_url();?>siteadmin/gossips/edit/<?php echo $row->id;?>" title="Edit"><i class="fa fa-pencil"></i></a> &nbsp; &nbsp;

						<a href="<?php echo base_url();?>siteadmin/gossips/delete/<?php echo $row->id;?>" title="Delete" onclick="return confirm('Are you sure, want to delete this record?');"><i class="fa fa-trash" style="color: red"></i></a>
					  </td>
					</tr>
					<?php $i++; 
					}
				}
				?>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->