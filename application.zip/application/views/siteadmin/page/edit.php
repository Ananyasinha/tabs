
  <style type="text/css">
  .form-group {
    margin-bottom: 20px;
}
</style>

<div class="content-inner">
  <!-- Page Header-->
  <header class="page-header">
    <div class="container-fluid">
      <h2 class="no-margin-bottom">Edit Page </h2>
    </div>
  </header>

  <!-- Forms Section-->
  <section class="forms"> 
    <div class="container-fluid">
      <div class="row">

        <!-- Manage Contact Details-->
        <div class="col-lg-11 ml-auto mr-auto">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4"></h3>
            </div>
            <div class="card-body">
             
	          <form method="post" action="<?php echo base_url();?>siteadmin/page/updatepage" enctype="multipart/form-data">
			  <input type="hidden" name="pageid" id="pageid" value="<?php echo $result->id;?>" />

                <div class="form-group">
                  <label class="form-control-label"> Page Title</label>
                  <input type="text" class="form-control" name="title" value="<?php echo $result->fld_page_title;?>" required="" readonly>
                </div>

                <div class="form-group">
                  <label class="form-control-label">Page Description</label>
                 <textarea class="form-control ckeditor"  name="description"  id="page-content" size="15"><?php echo $result->fld_description;?></textarea>
                </div>

                <div class="form-group">
                  <label class="form-control-label"> Meta Title</label>
                  <input type="text" class="form-control" name="mtitle" value="<?php echo $result->fld_mtitle;?>" required>
                </div>

                <div class="form-group">
                  <label class="form-control-label"> Meta Description</label>
                   <textarea class="form-control" rows="2" name="mdescription" id="mdescription" ><?php echo $result->fld_mdescription;?></textarea>
                </div>

                <div class="form-group">
                  <label class="form-control-label"> Meta Keyword</label>
                  <input type="text" class="form-control" name="mkeyword" value="<?php echo $result->fld_mkeyword;?>" required="">
                </div>
                
                <hr>
                <div class="form-group">       
                  <input type="submit" value="Submit" class="btn btn-primary">
                </div>
              </form>

            </div>
          </div>
        </div>

      </div>
    </div>
  </section>


