<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Page</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Page</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
        <form method="post" action="<?php echo base_url();?>siteadmin/page/updatepage" enctype="multipart/form-data">
		     <input type="hidden" name="pageid" id="pageid" value="<?php echo $result->id;?>" />
         
		  <div class="row">
          <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="card card-info">
      				<div class="card-body">
      					<div class="form-group">
      						<label for="company_name">Page Title</label>
      						<input type="text" class="form-control" name="title" id="title" value="<?php echo $result->fld_page_title;?>" required readonly />
      					</div>
                     
				      <?php if($result->fld_info_type!="Only Content"){?>

                  <div class="">
                    <label for="mtitle">Meta Title</label>
                    <input type="text" class="form-control" name="mtitle" id="mtitle"  value="<?php echo $result->fld_mtitle;?>" required />
					          <span style="color:#f00">&nbsp;</span>
                  </div>
				
                  <div class="">
                    <label for="mdescription">Meta Description</label>
                    <textarea class="form-control" rows="3" name="mdescription" id="mdescription" ><?php echo $result->fld_mdescription;?></textarea>
					         <span style="color:#f00">&nbsp;</span>
                  </div>
             
                  <div class="">
                    <label for="mkeyword">Meta Keyword</label>
                    <textarea class="form-control" rows="3" name="mkeyword" id="mkeyword" ><?php echo $result->fld_mkeyword;?></textarea>
					          <span style="color:#f00">&nbsp;</span>
                  </div>
				      <?php } ?>
				<div class="card-footer">
					<button type="submit" class="btn btn-primary">Update</button>
				</div>

			</div>
		  </div>
		  </div>
		</form>
    <!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->