<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Page</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Page</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
          <form method="post" action="<?php echo base_url();?>siteadmin/page/updatepage" enctype="multipart/form-data">
		  <input type="hidden" name="pageid" id="pageid" value="<?php echo $result->id;?>" />
		  <div class="row">
          
		  
		  
		  
          <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="card card-info">
				<div class="card-body">
					<div class="form-group">
						<label for="company_name">Page Title</label>
						<input type="text" class="form-control" name="title" id="title" value="<?php echo $result->fld_title;?>" required readonly />
					</div>
                
                </div>
                
				<?php if($result->fld_info_type!="Only Meta"){?>
				<div class="card-body">
				  <?php
				  if($result->id!=1 && $result->id!=2 && $result->id!=7 && $result->id!=8 && $result->id!=9)
				  {
				  ?>
				  <div class="form-group">
					<label for="logo">Image</label>
					<input type="file" class="form-control" name="page_image" id="page_image" value="" />
					<input type="hidden" class="form-control" name="oldpage_image" id="oldpage_image" value="<?php echo $result->fld_image;?>" />
					<span style="color:#f00">[Dimension: 349 x 244 Pixel]</span>
				  </div>
				  <?php 
				  }
				  ?>
				  <?php
				  if($result->id!=7 && $result->id!=8 && $result->id!=9)
				  {
				  ?>
				  <div class="form-group">
                    <label for="description">Short Description</label>
                    <textarea class="form-control" rows="3" name="shortdescription" id="shortdescription" required ><?php echo $result->fld_shortdescription;?></textarea>
                  </div>
				  <?php 
				  }
				  ?>
				</div>
				
				<div class="card-body">
                  <div class="form-group">
                    <label for="description">Page Description</label>
                    <textarea class="form-control" rows="3" name="description" id="description" required ><?php echo $result->fld_description;?></textarea>
					
					<script>CKEDITOR.replace('description');</script>
                  </div>
				</div>
				<?php } ?>
				<?php if($result->fld_info_type!="Only Content"){?>
				<div class="card-body">
                  <div class="form-group">
                    <label for="mtitle">Meta Title</label>
                    <input type="text" class="form-control" name="mtitle" id="mtitle"  value="<?php echo $result->fld_mtitle;?>" required />
					<span style="color:#f00">&nbsp;</span>
                  </div>
                </div>
				
				<div class="card-body">
                  <div class="form-group">
                    <label for="mdescription">Meta Description</label>
                    <textarea class="form-control" rows="3" name="mdescription" id="mdescription" ><?php echo $result->fld_mdescription;?></textarea>
					<span style="color:#f00">&nbsp;</span>
                  </div>
                </div>
				
				<div class="card-body">
                  <div class="form-group">
                    <label for="mkeyword">Meta Keyword</label>
                    <textarea class="form-control" rows="3" name="mkeyword" id="mkeyword" ><?php echo $result->fld_mkeyword;?></textarea>
					<span style="color:#f00">&nbsp;</span>
                  </div>
                </div>
				<?php } ?>
				<div class="card-footer">
					<button type="submit" class="btn btn-primary">Update</button>
				</div>
			</div>
		  </div>
		  </div>
		  
		  </form>
        
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->