
  <style type="text/css">
  .form-group {
    margin-bottom: 20px;
}
</style>

<div class="content-inner">
  <!-- Page Header-->
  <header class="page-header">
    <div class="container-fluid">
      <h2 class="no-margin-bottom">Add Blog</h2>
    </div>
  </header>
  <!-- Breadcrumb-->
 <!--  <div class="breadcrumb-holder container-fluid">
    <ul class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
      <li class="breadcrumb-item active">  </li>
    </ul>
  </div> -->
  <!-- Forms Section-->
  <section class="forms"> 
    <div class="container-fluid">
      <div class="row">

        <!-- Manage Contact Details-->
        <div class="col-lg-11 ml-auto mr-auto">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4">Edit Page</h3>
            </div>
            <div class="card-body">
              <form>
                <div class="form-group">
                  <label class="form-control-label"> Page Title</label>
                  <input type="text" class="form-control" required="">
                </div>

                <div class="form-group">
                  <label class="form-control-label">Page Description</label>
                 <textarea class="form-control ckeditor"  name="page-content"  id="page-content" size="15"></textarea>
                </div>

                <div class="form-group">
                  <label class="form-control-label"> Meta Title</label>
                  <input type="text" class="form-control" required="">
                </div>

                <div class="form-group">
                  <label class="form-control-label"> Meta Description</label>
                  <input type="text" class="form-control" required="">
                </div>

                <div class="form-group">
                  <label class="form-control-label"> Meta Keyword</label>
                  <input type="text" class="form-control" required="">
                </div>
                
                <hr>
                <div class="form-group">       
                  <input type="submit" value="Submit" class="btn btn-primary">
                </div>
              </form>

            </div>
          </div>
        </div>

      </div>
    </div>
  </section>


