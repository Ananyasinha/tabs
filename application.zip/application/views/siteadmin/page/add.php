<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add Page</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Page</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
          <form method="post" action="<?php echo base_url();?>siteadmin/page/insertpage"  enctype="multipart/form-data">
		  <div class="row">
          
		
		
          <div class="col-md-12">
            <!-- Horizontal Form -->
            <div class="card card-info">
				<div class="card-body">
                  <div class="form-group">
                    <label for="company_name">Page Title</label>
                    <input type="text" class="form-control" name="title" id="title" value="" required />
					<span style="color:#f00">&nbsp;</span>
                  </div>
                </div>
            
				<div class="card-body">
                  <div class="form-group">
                    <label for="description">Page Description</label>
                    <textarea class="form-control" rows="3" name="description" id="description" required ></textarea>
					<script>CKEDITOR.replace('description');</script>
                  </div>
				</div>
				<div class="card-body">
                  <div class="form-group">
                    <label for="mtitle">Meta Title</label>
                    <input type="text" class="form-control" name="mtitle" id="mtitle"  value="" required />
					<span style="color:#f00">&nbsp;</span>
                  </div>
                </div>
				
				<div class="card-body">
                  <div class="form-group">
                    <label for="mdescription">Meta Description</label>
                    <textarea class="form-control" rows="3" name="mdescription" id="mdescription" ></textarea>
					<span style="color:#f00">&nbsp;</span>
                  </div>
                </div>
				
				<div class="card-body">
                  <div class="form-group">
                    <label for="mkeyword">Meta Keyword</label>
                    <textarea class="form-control" rows="3" name="mkeyword" id="mkeyword" ></textarea>
					<span style="color:#f00">&nbsp;</span>
                  </div>
                </div>
				<div class="card-footer">
					<button type="submit" class="btn btn-primary">Submit</button>
				</div>
			</div>
		  </div>
		  
		  
		  
          </div>
		  
		  </form>
        
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->