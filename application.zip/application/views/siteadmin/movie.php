<div class="middile">

    <section class="breadcrumb-back">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Movie</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <div class="clearfix"></div>

    <div class="container">
        <div class="row">

            <div class="col-sm-9 mt-5">
                <h1 class="heading border-none">Movies</h1>
                <div class="inner-page">
                    <h2 class="sub-heading">Movie Reviews</h2>

                    <div class="row">

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <a class="see-all" href="#">See All</a>

                    </div>

                </div>

                <div class="inner-page">
                    <h2 class="sub-heading">Movie Trailers</h2>

                    <div class="row">

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <a class="see-all" href="#">See All</a>

                    </div>

                </div>

                <div class="inner-page">
                    <h2 class="sub-heading">Songs</h2>

                    <div class="row">

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery1.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery3.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <div class="col-sm-4 mb-3 listing">
                            <div class="gallery-home">
                                <h3>Lorem Ispum</h3>
                                <a href=""><img src="<?php echo base_url();?>assets/site/images/gallery2.jpg" class="img-fluid"></a>
                                <div class="overlay"></div>
                            </div>
                            <h4><a href="#">Movie Review:</a></h4>
                            <p>Curabitur facilisis pellentesque pharetra donec justo urna...</p>
                        </div>

                        <a class="see-all" href="#">See All</a>

                    </div>

                </div>

            </div>

            <div class="col-sm-3 mt-5">

                <div class="col-sm-12 pr-0 pl-0">
                    <div class="home-right-box">
                        <h3>Lorem Ispum</h3>
                        <a href="#"><img src="<?php echo base_url();?>assets/site/images/right1.jpg" class="img-fluid"></a>
                        <a href="#">
                            <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
                        </a>
                    </div>
                </div>

                <div class="col-sm-12 pr-0 pl-0">
                    <div class="home-right-box">
                        <h3>Lorem Ispum</h3>
                        <a href="#"><img src="<?php echo base_url();?>assets/site/images/right1.jpg" class="img-fluid"></a>
                        <a href="#">
                            <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
                        </a>
                    </div>
                </div>

                <div class="col-sm-12 pr-0 pl-0">
                    <div class="home-right-box last">
                        <a href="#"><img src="<?php echo base_url();?>assets/site/images/right2.jpg" class="img-fluid"></a>
                        <a href="#">
                            <h4 class="text-center">SED DO EIUSMOD TEMPOR INCIDIDUNT UT LABORE ET DOLORE MAGNA ALIQUAMINIM</h4>
                        </a>
                    </div>
                </div>

            </div>

        </div>
    </div>

    <div class="clearfix"></div>
</div>
