<style type="text/css">
  .form-group.row {
    margin-bottom: 25px;
}
button.btn.btn-danger {
    background: #ff3f3f!important;
}
/*section.content {
    margin-top: 20px!important;
}*/
.alert.alert-success {
    text-align: center;
}
.alert.alert-danger{
    text-align: center;
}
</style>


<div class="content-wrapper">
  <!-- Page Header-->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage General Details</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">General Details</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

  <!-- Forms Section-->
  <section class="content"> 
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 ml-auto mr-auto">
        <?php 
          if($this->session->userdata('alert_type')!="")
          {
            ?>
            <div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
              <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
              <?php echo $this->session->userdata('msg');?>
            </div>
            <?php
            $this->session->unset_userdata('alert_type');
            $this->session->unset_userdata('msg');
          }
          ?>
        </div>



        <!-- manage logo-->
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4">Manage Logo</h3>
            </div>
            <div class="card-body">

              <div class="row">
                <div class="form-group">  
                  <div class="col-sm-12">
                    <img src="<?php echo base_url().'assets/media/'.$result[0]['logo'];?>" height="100px" width="100px">
                  </div>
                </div>
              </div>

            <form method="post" action="<?php echo base_url();?>siteadmin/generaldetails/updatelogo" enctype="multipart/form-data">
                <div class="row">
                  <div class="form-group">    
                    <div class="col-md-12">
                      <div class="input-group">
                        <input type="file"  id="uploadfile" name="uploadfile" accept="image/*" class="form-control" required="" multiple>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group">       
                 <button type="submit" name="update-logo" class="btn btn-danger">Upload Logo</button>
                  <div class="clearfix"></div>
                </div>
              </form>
            </div>
          </div>
        </div>


        <!-- manage favicon Form-->
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4">Manage Favicon</h3>
            </div>
            <div class="card-body">

              <div class="row">
                <div class="form-group">  
                  <div class="col-sm-12">
                    <img src="<?php echo base_url().'assets/media/'.$result[0]['favicon'];?>" height="80px" width="80px">
                  </div>
                </div>
              </div>

              <form method="post"  action="<?php echo base_url();?>siteadmin/generaldetails/updatefavicon"  enctype="multipart/form-data">
                <div class="row">
                  <div class="form-group">    
                    <div class="col-md-12">
                      <div class="input-group">
                        <input type="file" name="uploadfile" accept="image/*" class="form-control" required="">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group">       
                 <button type="submit"  class="btn btn-danger">Upload Favicon</button>
                  <div class="clearfix"></div>
                </div>
              </form>
            </div>
          </div>
        </div>


        <!-- Manage Contact Details-->
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4">Manage Contact Details</h3>
            </div>
            <div class="card-body">
              <form method="post" action="<?php echo base_url();?>siteadmin/generaldetails/updateDetails">
                <div class="form-group">
                  <label class="form-control-label">Contact Number</label>
                  <input type="text" class="form-control" name="contact"  value="<?php echo $result[0]['contact'];?>" required="">
                </div>

                <div class="form-group">
                  <label class="form-control-label">E-Mail</label>
                  <input type="text" class="form-control" name="email" value="<?php echo $result[0]['email'];?>" required="">
                </div>
                
                <div class="form-group">       
                  <label class="form-control-label">Copyright Name</label>
                  <input type="text" class="form-control" name="copyright" value="<?php echo $result[0]['copyright'];?>" required="">
                </div>


                <div class="form-group">
                  <label class="form-control-label">Address</label>
                   <textarea rows="4" cols="50" type="text" name="address" class="form-control" required=""><?php echo $result[0]['address'];?></textarea>
                </div>
                
                <div class="form-group">       
                  <button type="submit" class="btn btn-danger">Update</button>
                </div>
              </form>
            </div>
          </div>
        </div>



        <!-- Manage social media-->
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4">Manage Social Media Links</h3>
            </div>
            <div class="card-body">
              <form class="form-horizontal" method="post" action="<?php echo base_url();?>siteadmin/generaldetails/updatesocial">
                
                <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Facebook</label>
                  <div class="col-sm-9">
                    <input id="" type="text" placeholder="" class="form-control"  value="<?php echo $result[0]['facebook'];?>" name="facebook">
                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Twitter</label>
                  <div class="col-sm-9">
                    <input id="" type="text" placeholder=""  value="<?php echo $result[0]['twitter'];?>" class="form-control" name="twitter">
                  </div>
                </div>

               <div class="form-group row">
                  <label class="col-sm-3 form-control-label">LinkedIn</label>
                  <div class="col-sm-9">
                    <input id="" type="text" placeholder="" class="form-control" name="linkedIn" value="<?php echo $result[0]['linkedin'];?>" >
                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Google+</label>
                  <div class="col-sm-9">
                    <input id="" type="text" placeholder="" class="form-control" name="youtube" value="<?php echo $result[0]['gplus'];?>">

                  </div>
                </div>


                <div class="form-group row">       
                  <div class="col-sm-9 offset-sm-3">
                     <button type="submit" class="btn btn-danger">Update</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
    
      </div>
    </div>
  </section>
</div>