  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css"></style> 
<!-- Content Wrapper. Contains page content -->
 <div class="content-inner">
    <!-- Page Header-->
    <header class="page-header">
      <div class="container-fluid">
        <h2 class="no-margin-bottom">Manage EXAMINATIONS </h2>
      </div>
    </header>
    <!-- Breadcrumb-->
  <!--   <div class="breadcrumb-holder container-fluid">
      <ul class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item active">Tables            </li>
      </ul>
    </div> -->
    <section class="tables">   
      <div class="container-fluid">
        <div class="row">

          <div class="col-lg-12">
            
            <?php 
            if($this->session->userdata('alert_type')!="")
            {
              ?>
              <div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                <?php echo $this->session->userdata('msg');?>
              </div>
              <?php
              $this->session->unset_userdata('alert_type');
              $this->session->unset_userdata('msg');
            }
            ?>
            <div class="card">
             
              <div class="card-header d-flex align-items-center">
                <h3 class="h4">EXAMINATIONS  List</h3>

                <span style="margin-left:62%;">
                <a name="" type="button" href="<?php echo base_url();?>siteadmin/exam/add" class="btn btn-primary" >Add EXAMINATIONS </a>
                  </span>
              </div>
              <div class="card-body">
                <div class="table-responsive">  
                <!--   <table class="table table-striped"> -->

                  <table id="example" class="table table-striped table-bordered text-center" style="width:100%">
                    <thead>
                      <tr>
                        <th>S.no</th>
                        <th>Exam Name</th>
                        <th>Description</th>
                        <th>Fees</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>

                    
                      <?php 
                      $i=1;
                      if(count(array_filter($result)) > 0){
                        foreach($result as $row){
                        ?>

                      <tr>
                        <th scope="row"><?php echo $i;?></th>
                         <td>
                         <a data-toggle="tooltip" title="View Sub Courses" data-placement="top" href="<?php echo base_url();?>siteadmin/exam/subexam/<?php echo $row->id;?>""><?php echo $row->exam_name;?> </a></td>

                        <td><?php echo $row->description;?></td>
                        <td><?php echo $row->fees;?></td>

                        <td>

                          <a href="<?php echo base_url();?>siteadmin/exam/edit/<?php echo $row->id;?>" title="Edit">
                            <i class="fa fa-edit"></i>
                          </a> &nbsp;&nbsp;&nbsp;&nbsp;

                         <a href="<?php echo base_url();?>siteadmin/exam/delete/<?php echo $row->id;?>" title="Delete">
                            <i class="fa fa-trash" style="color:#f55145!important;"></i>
                          </a>


                        </td>
                                      
                      </tr>
                      <?php 
                        $i++ ;}
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  <!-- /.content-wrapper -->

