<style type="text/css">
  .form-group {
    margin-bottom: 20px;
}
</style>

<div class="content-inner">
  <!-- Page Header-->
  <header class="page-header">
    <div class="container-fluid">
      <h2 class="no-margin-bottom">Edit Sub Exam</h2>
    </div>
  </header>

  <!-- Forms Section-->
  <section class="forms"> 
    <div class="container-fluid">
      <div class="row">

        <!-- Manage social media-->
        <div class="col-lg-11 ml-auto mr-auto">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4"></h3>
            </div>
            <div class="card-body">
              <form class="form-horizontal" method="post" action="<?php echo base_url();?>siteadmin/exam/updatesubexam" >
              	 <input type="hidden" name="pageid" id="pageid" value="<?php echo $result->id;?>" />
                
                
                <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Exam Name</label>
                  <div class="col-sm-9">
                    <input id="" type="text" placeholder="" name="exam" class="form-control form-control-warning" value="<?php echo $result->sub_exam_name;?>">
                  </div>
                </div>

  

               <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Description</label>
                  <div class="col-sm-9">
                   <!--  <input id="" type="password" placeholder="" class="form-control form-control-warning"> -->

                    <textarea rows="4" cols="50" type="text" name="description" class="form-control" ><?php echo $result->sub_description;?></textarea>
                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Fees</label>
                  <div class="col-sm-9">
                    <input id="" type="text" placeholder="" value="<?php echo $result->sub_fees;?>" name="fees" class="form-control form-control-success">

                  </div>
                </div>


                <div class="form-group row">       
                  <div class="col-sm-9 offset-sm-3">
                    <input type="submit" value="Submit" class="btn btn-primary">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>


<script type="text/javascript">
  $(document).ready(function() {
      $(".add-more").click(function(){
          var html = $(".copy").html();
          $(".after-add-more").after(html);
      });
      $("body").on("click",".remove",function(){ 
          $(this).parents(".control-group").remove();
      });
    });

     var scnt = 1;

    function AddMoreServices() {

        scnt++;
        var objTo = document.getElementById('services_fields')
        var divtest = document.createElement("div");
        divtest.setAttribute("class", "form-group removeclassBlog" + scnt);
        var rdiv = 'removeclassBlog' + scnt;
        var html = "";
        html += '<div id="removeclassService' + scnt + '"><div class="form-group row"><div class="col-sm-1"><div class="form-group">';
       
        html += ' </div></div>';
        html += '<div class="col-md-7"><div class="form-group"><label class="control-label">Sub Exam Name</label><input type="text" class="form-control" name="addmore[]" id="service_price' + scnt + '" value="" placeholder="Sub Course Name"></div></div>';
      
        html += '<div class="col-md-1"><div class=""><label class="control-label">&nbsp;</label><div class="clearfix"></div><a class="btn btn-success2" type="button"  onclick="remove_service_fields(' + scnt + ');"> <span class="fa fa-minus" aria-hidden="true"></span> </a></div></div>';
        html += '</div></div>';
        $("#services_fields").append(html);
    }

    function remove_service_fields(rid) {
        $('#removeclassService' + rid).remove();
    }
</script>
</script>