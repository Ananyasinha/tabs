<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Movie Section </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Movie</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
    <!-- Main content -->
    <section class="content">
	<?php 
	if($this->session->userdata('alert_type')!="")
	{
		?>
		<div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
			<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
			<?php echo $this->session->userdata('msg');?>
		</div>
		<?php
		$this->session->unset_userdata('alert_type');
		$this->session->unset_userdata('msg');
	}
	?>
      <div class="row">
        <div class="col-12">
         
		 <div class="card">
            
            <!-- /.card-header -->
            <div class="card-body table-responsive">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
				  <th>Image</th>
                  <th>Title</th>
                  <th style="text-align:center">Release On</th>
                  <th style="text-align:center">YouTube Url</th>
				  <th style="text-align:center">Posted On</th>
                  <th style="text-align:center">Status</th>
                  <th style="text-align:center">Action</th>
                </tr>
                </thead>
                <tbody>
				<?php if(count(array_filter($result)) > 0){
					foreach($result as $row){
					?>
					<tr>
					  <td>
						<?php if($row->fld_image!=""){?>
						<img src="<?php echo base_url();?>assets/movieimg/<?php echo $row->fld_image;?>" style="width:130px;height: 100px" />
						<?php }?>
					  </td>
					   <td><?php echo $row->fld_title;?></td>

					   <td style="text-align:center"><?php echo convertdate($row->release_date,'d M Y')?></td>

					  <td><a href="<?php echo $row->youtube_url;?>" target="_blank"><?php echo $row->youtube_url;?></a> </td>
					
					  <td style="text-align:center"><?php echo convertdate($row->fld_addedon,'d M Y')?></td>
					  
					  <td style="text-align:center">
						  <?php if($row->status == "Active"){?>
							<span class="label-success" style="cursor:pointer;padding: 3px;border-radius: 100%;" onclick="return changestatus('<?php echo base_url();?>','newsstatus<?php echo $row->id;?>',this,'<?php echo $row->id;?>','movie');"><i class="fa fa-check"></i></span>
						  <?php }else{?>
							<span class="label-danger" style="cursor:pointer;padding: 3px;border-radius: 100%;" onclick="return changestatus('<?php echo base_url();?>','newsstatus<?php echo $row->id;?>',this,'<?php echo $row->id;?>','movie');"><i class="fa fa-times" style="width: 16px;"></i></span>
						  <?php }?>
						  <input type="hidden" id="newsstatus<?php echo $row->id;?>" value="<?php echo $row->status;?>" />  
					  </td>
					  <td style="text-align:center">
						
						<a href="<?php echo base_url();?>siteadmin/movie/edit/<?php echo $row->id;?>" title="Edit"><i class="fa fa-pencil"></i></a> &nbsp; &nbsp;

						<a href="<?php echo base_url();?>siteadmin/movie/deletenews/<?php echo $row->id;?>" title="Delete" onclick="return confirm('Are you sure, want to delete this record?');"><i class="fa fa-trash" style="color: red"></i></a>
					  </td>
					</tr>
					<?php 
					}
				}
				?>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->