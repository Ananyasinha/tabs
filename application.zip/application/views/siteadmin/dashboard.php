<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
	<div class="row mb-2">
	  <div class="col-sm-6">
		<h1 class="m-0 text-dark">Dashboard</h1>
	  </div><!-- /.col -->
	  <div class="col-sm-6">
		<ol class="breadcrumb float-sm-right">
		  <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
		  <li class="breadcrumb-item active">Dashboard</li>
		</ol>
	  </div><!-- /.col -->
	</div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
	
		<div class="row">
			<div class="col-md-12 connectedSortable ui-sortable">
				<div class="card">
					
					<!-- /.card-header -->
					<div class="card-body table-responsive">
						<div class="card-body">
						<h4>Recent Product</h4>
						<table id="example1" class="table table-bordered table-striped">
						
						<tbody>
						<?php if(count(array_filter($result)) > 0){
							foreach($result as $row){
							?>
							<tr>
								<td><?php echo $row->fld_title;?></td>
								<td style="text-align:center"><?php echo convertdate($row->fld_addedon,'d M Y')?></td>
								<td style="text-align:center"><a href="<?php echo base_url();?>siteadmin/product/edit/<?php echo $row->id;?>" title="View"><i class="fa fa-pencil"></i></a></td>
							</tr>
							<?php 
							}
						}
						else
						{
							?>
							<tr>
								<td><div class="alert alert-danger">Information Not Available!</div></td>
							</tr>
							<?php
						}
						?>
						</tfoot>
					    </table>
					  </div>
					  
					</div>
					<!-- /.card-body -->
				 </div>
			</div>
			
		</div>
	
  </div><!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

