<!-- page content start -->
<div class="content-inner">
          <!-- Page Header-->
	<header class="page-header">
	    <div class="container-fluid">
	      <h2 class="no-margin-bottom">Dashboard</h2>
	    </div>
	</header>
		<!-- Dashboard Counts Section-->
	  <section class="dashboard-counts no-padding-bottom">
	    <div class="container-fluid">
	      <div class="row bg-white has-shadow">
	        <!-- Item -->
	    <!--     <div class="col-xl-12 col-sm-6" style="height: 100px;">
	          <div class="item d-flex align-items-center">
	             <center><h2>Welcome Admin..!</h2></center>
	          </div>
	        </div> -->
	        <div class="col-md-12 col-sm-6" style="height: 80px;">
	        	<center><h2>Welcome Admin..!</h2></center>
	        </div>

	      </div>
	    </div>
	  </section>
	 
<!-- /.page content end -->

