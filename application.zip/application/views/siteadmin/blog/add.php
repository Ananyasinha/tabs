<style type="text/css">
  .form-group {
    margin-bottom: 20px;
}
</style>

<div class="content-inner">
  <!-- Page Header-->
  <header class="page-header">
    <div class="container-fluid">
      <h2 class="no-margin-bottom">Add Blog</h2>
    </div>
  </header>
  <!-- Breadcrumb-->
 <!--  <div class="breadcrumb-holder container-fluid">
    <ul class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
      <li class="breadcrumb-item active">  </li>
    </ul>
  </div> -->
  <!-- Forms Section-->
  <section class="forms"> 
    <div class="container-fluid">
      <div class="row">

        <!-- Manage Contact Details-->
        <div class="col-lg-11 ml-auto mr-auto">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4">Add New Blog</h3>
            </div>
            <div class="card-body">
              <form class="form-horizontal" method="post" action="<?php echo base_url();?>siteadmin/blog/addblog" >
                <div class="form-group">
                  <label class="form-control-label"> Blog Title </label>
                  <input type="text" class="form-control" name="name" required="">
                </div>

                <div class="form-group">       
                  <label class="form-control-label">Blog Date</label>
                  <input type="date" class="form-control" name="date" required="">
                </div>

                

                <div class="form-group">
                  <label class="form-control-label">Blog Description</label>
                 <textarea class="form-control ckeditor"  name="description"  id="page-content" size="15"></textarea>
                </div>
                
                <hr>
                <div class="form-group">       
                  <input type="submit" value="Submit" class="btn btn-primary">
                </div>
              </form>

            </div>
          </div>
        </div>

      </div>
    </div>
  </section>


