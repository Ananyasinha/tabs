<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">

<!-- Content Wrapper. Contains page content -->
<div class="content-inner">
<!-- Page Header-->
<header class="page-header">
    <div class="container-fluid">
        <h2 class="no-margin-bottom">Manage Gallery </h2>
    </div>
</header>

<section class="tables">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <?php 
        if($this->session->userdata('alert_type')!=""){ ?>
            <div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                <?php echo $this->session->userdata('msg');?>
            </div>
        <?php
          $this->session->unset_userdata('alert_type');
          $this->session->unset_userdata('msg');
        } ?>

          <div class="col-lg-8 ml-auto mr-auto">
              <div class="card">
                  <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Upload Image</h3>
                  </div>
                  <div class="card-body">

                      <form method="post" action="<?php echo base_url();?>siteadmin/gallery/addgallery" enctype="multipart/form-data">
                          <div class="row">
                              <div class="form-group">
                                  <div class="col-md-12">
                                      <div class="input-group">
                                          <input type="file" name="uploadfile" id="img" accept="image/*" class="form-control" required="">
                                      </div>
                                  </div>
                              </div>
                          </div>

                          <div class="row" style="margin-top:20px;margin-bottom: 20px">
                              <div class="col-md-12">
                                  <div class="input-group">
                                      <input id="" type="text" placeholder="Title" name="title" class="form-control form-control-warning">
                                  </div>
                              </div>
                          </div>

                          <div class="form-group">
                              <button type="submit" class="btn btn-primary">Upload </button>
                              <div class="clearfix"></div>
                          </div>
                      </form>
                  </div>
              </div>
          </div>

          <div class="card">
            <div class="card-body">
              <div class="card-body table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                  <tbody>
                    <?php if(count(array_filter($result)) > 0){?>
                <tr>
                  <?php 
                    $i=0;
                    foreach($result as $row){
                    $i++;
                    ?>
                    <td style="text-align: center;vertical-align: middle;">
                      <?php if($row->fld_image!=""){?>

                        <img src="<?php echo base_url();?>assets/galleryimg/<?php echo $row->fld_image;?>" style='width:220px;height:160px;' />
                          <?php }?>
                            <br><br>
                        <h6><?php echo $row->title;?></h6>

                        <a href="<?php echo base_url();?>siteadmin/gallery/deletegallery/<?php echo $row->id;?>" title="Delete" onclick="return confirm('Are you sure, want to delete this record?');" class="btn btn-danger"><i class="fa fa-trash"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;

                              <label class="switch" data-toggle="tooltip" title="change Status">
                                  <input class="change-status" type="checkbox" data-this-id="<?php echo $row->id;?>" <?php if($row->status=='Active'){ echo ' checked';}?> >
                                  <span class="slider round"></span>
                              </label>

                              <input type="hidden" id="gallerystatus<?php echo $row->id;?>" value="<?php echo $row->status;?>" />
                          </td>
                          <?php if($i%3==0){?>
                        </tr>
                        <tr>
                      <?php } } }else{ ?>
                      <tr>
                          <td colspan="2">
                              Info. Not available
                          </td>
                      </tr>
                      <?php } ?>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</section>
<!-- /.content-wrapper -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('.change-status').on('change', function() {
            var status = 0,
                id = $(this).data('this-id');
            if ($(this).is(':checked')) {
                status = 'Active';
            } else {
                status = 'Inactive';
            }
            //alert(id);
            $.ajax({
                type: 'post',
                url: '<?php echo base_url();?>siteadmin/gallery/changestatus',
                data: {
                    status: status,
                    id: id
                },
                success: function() {
                    /* toast('Change successfully saved.', 'success', 3000);*/
                },
                error: function() {
                    /*toast('Something went wrong, Please try again.', 'danger', 3000);*/
                }

            });
        });
    });
</script>