  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<!-- Content Wrapper. Contains page content -->
 <div class="content-inner">
    <!-- Page Header-->
    <header class="page-header">
      <div class="container-fluid">
        <h2 class="no-margin-bottom">Manage Service</h2>
      </div>
    </header>

    <section class="tables">   
      <div class="container-fluid">
        <div class="row">

          <div class="col-lg-12">

            <?php 
            if($this->session->userdata('alert_type')!="")
            {
              ?>
              <div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                <?php echo $this->session->userdata('msg');?>
              </div>
              <?php
              $this->session->unset_userdata('alert_type');
              $this->session->unset_userdata('msg');
            }
            ?>
            <div class="card">
             
              <div class="card-header d-flex align-items-center">
                <h3 class="h4"> Service List</h3>
                <span style="margin-left:75%;">
                <a name="" type="button" href="<?php echo base_url();?>siteadmin/service/add" class="btn btn-primary" >Add Service </a>
                  </span>
              </div>
              <div class="card-body">
                <div class="table-responsive">  
                <!--   <table class="table table-striped"> -->

                  <table id="example" class="table table-striped table-bordered text-center table_id" style="width:100%">
                    <thead>
                      <tr>
                        <th>S.no</th>
                        <th>Service Name</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>

                      <?php 
                      $i=1;
                      if(count(array_filter($result)) > 0){
                        foreach($result as $row){
                        ?>

                      <tr>
                        <th scope="row"><?php echo $i;?></th>
                         <td>
                         <?php echo $row->service_name;?></td>

                        <td><?php echo $row->description;?></td>
                        <td >
                          <img src="<?php echo base_url();?>assets/media/service/<?php echo $row->image; ?>" style="height: 100px;">
                          
                          </td>

                        <td>

                          <a href="<?php echo base_url();?>siteadmin/service/edit/<?php echo $row->id;?>" title="Edit">
                            <i class="fa fa-edit"></i>
                          </a> &nbsp;&nbsp;&nbsp;&nbsp;

                         <a href="<?php echo base_url();?>siteadmin/service/delete/<?php echo $row->id;?>" title="Delete">
                            <i class="fa fa-trash" style="color:#f55145!important;"></i>
                          </a>


                        </td>
                                      
                      </tr>
                      <?php 
                        $i++ ;}
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  <!-- /.content-wrapper -->

