<style type="text/css">
  .form-group {
    margin-bottom: 20px;
}
</style>

<div class="content-inner">
  <!-- Page Header-->
  <header class="page-header">
    <div class="container-fluid">
      <h2 class="no-margin-bottom">Edit Service</h2>
    </div>
  </header>

  <!-- Forms Section-->
  <section class="forms"> 
    <div class="container-fluid">
      <div class="row">

        <!-- Manage social media-->
        <div class="col-lg-11 ml-auto mr-auto">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4">Edit New Service</h3>
            </div>
            <div class="card-body">
              <form class="form-horizontal" method="post" action="<?php echo base_url();?>siteadmin/service/updateservice" enctype="multipart/form-data">
                
                <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Service Name</label>
                  <div class="col-sm-9">
                    <input id="" type="text" placeholder="" name="servicename" class="form-control form-control-warning" value="<?php echo $result->service_name;?>" required="">
                  </div>
                </div>


               <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Description</label>
                  <div class="col-sm-9">
                    <textarea rows="4" cols="50" type="text" name="description" class="form-control" required=""><?php echo $result->description;?></textarea>
                  </div>
                </div>

                <div class="form-group row">
                  <label class="col-sm-3 form-control-label">Image</label>
                  <div class="col-sm-9">
                    <input type="file" name="uploadfile" accept="image/*" class="form-control" required="" value="<?php echo $result->image;?>">
                  </div>
                </div>


                <div class="form-group row">       
                  <div class="col-sm-9 offset-sm-3">
                    <input type="submit" value="Submit" class="btn btn-primary">
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>
