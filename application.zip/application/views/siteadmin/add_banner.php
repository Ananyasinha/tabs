<style type="text/css">
  .form-group.row {
    margin-bottom: 25px;
}

</style>


<div class="content-inner">
  <!-- Page Header-->
  <header class="page-header">
    <div class="container-fluid">
      <h2 class="no-margin-bottom">Manage Banner</h2>
    </div>
  </header>


  <!-- Forms Section-->
  <section class="forms"> 
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-10 ml-auto mr-auto">
        <?php 
          if($this->session->userdata('alert_type')!="")
          {
            ?>
            <div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
              <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
              <?php echo $this->session->userdata('msg');?>
            </div>
            <?php
            $this->session->unset_userdata('alert_type');
            $this->session->unset_userdata('msg');
          }
          ?>
        </div>


        <!-- manage logo-->
        <div class="col-lg-8 ml-auto mr-auto">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4"> </h3>
            </div>
            <div class="card-body">


            <form method="post" action="<?php echo base_url();?>siteadmin/banner/upload" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-12">
                      <div class="input-group">
                        <select name="banner-type" class="form-control" required="">
                          <option value="" disabled="" selected="">Select Banner Type *</option>
                            <option value="1">Home Slider Image</option>
                        </select>
                      </div>
                  </div>
                </div>

                 <div class="row" style="margin-top:30px;">
                  <div class="col-md-12">
                    <div class="input-group">
                        <input id="" type="text" placeholder="Title" name="title" class="form-control form-control-warning" required="">
                    </div>
                    </div>
                </div>

                <div class="row" style="margin-top:30px;">
                   <label class="col-md-10 form-control-label">Banner Background Image</label>
                  <div class="col-md-10">
                    <div class="input-group">
                      <input type="file" name="uploadfile" accept="image/*" class="form-control" required="" id="imgInp">
                    </div>
                    </div>
                </div>


                <div class="row" style="margin-top:30px;">
                  <label class="col-md-10 form-control-label">Banner Side Image</label>
                  <div class="col-md-10">
                    <div class="input-group">
                      <input type="file" name="uploadfile1" accept="image/*" class="form-control" id="imgInp1">
                    </div>
                  </div>
                </div>

                <br>
                <div class="form-group">       
                 <button type="submit"  class="btn btn-primary">Save</button>
                  <div class="clearfix"></div>
                </div>
              </form>
            </div>
          </div>
        </div>

      </div>

        <!-- add more button start -->
      <div class="btn-float-bottom-right">
        <a data-toggle="tooltip" title="Go Back" href="<?php echo base_url();?>siteadmin/banner" class="btn btn-primary rounded" ><i class="fa fa-reply" ></i></a>
      </div>
      <!-- add more button start -->
    </div>
  </section>
