<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Hot Spot</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <base href="<?php echo base_url();?>" />
  <link rel="stylesheet" href="assets/siteadmin/plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="assets/siteadmin/dist/css/adminlte.min.css">
 <link rel="shortcut icon" href="<?php echo base_url();?>assets/media/favicon.png">
<style type="text/css">
.nav-pills .nav-link:not(.active):hover {
    color: #ff3f3f !important;
}

.sidebar-light-primary .nav-sidebar>.nav-item>.nav-link.active {
    color: #fff;
    background-color: #ff3f3f!important;
}
.sidebar-light-primary {
    background-color: #fafafa!important;
}

.alert.alert-success {
    text-align: center;
}

.alert.alert-danger {
    text-align: center;
}
</style>

  <?php 
  if($module == "page" || $module == "Movie" || $module == 'banner' || $module == 'Gallery' || $module == 'latest' || $module == 'gossips')
  {
  ?>
  <link rel="stylesheet" href="assets/siteadmin/plugins/datatables/dataTables.bootstrap4.css">
  <?php 
  }
  ?>
  
  <?php 
  if($module == 'banner' || $module == 'Gallery' || $module == 'quality' || $module == 'award' || $module == 'Movie')
  {
  ?>
  <link href="<?php echo base_url()?>assets/dropzone/dropzone.min.css" rel="stylesheet">
  <script src="<?php echo base_url()?>assets/dropzone/dropzone.min.js"></script>
  <?php 
  }
  ?>
  <?php if($module == "page" || $module == 'Gallery' || $module == 'award' || $module == 'latest' || $module == 'movie'){?>
  <script src="assets/ckeditor/ckeditor.js"></script>
  <?php }?>
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
  <!-- <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom" id="headernav"> -->
  <nav class="main-header navbar navbar-expand navbar-light border-bottom" id="headernav">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" title="Change Theme"><i class="fa fa-bars"></i></a>
      </li>
    </ul>

    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
       <a href="<?php echo base_url();?>siteadmin/dashboard/logout" class="nav-link logout">
               
        <span class="d-none d-sm-inline">   Logout  </span><i class="fa fa-sign-out"></i></a>
      </li>
    </ul>
	
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-light-primary elevation-4" id="themebox">
    <!-- Brand Logo -->
    <a href="<?php echo base_url();?>siteadmin/dashboard" class="brand-link">
		<span class="brand-text font-weight-light"><center><img src="<?php echo base_url();?>assets/img/logo.png"  /></center></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
			<li class="nav-item <?php if($module == 'dashboard'){?>menu-open<?php }?>">
			<a href="<?php echo base_url();?>siteadmin/dashboard" class="nav-link <?php if($module == 'dashboard'){?>active<?php }?>">
			  <i class="nav-icon fa fa-home"></i>
			  <p>
				Dashboard
			  </p>
			</a>
			</li>


			<li class="nav-item has-treeview  <?php if($module == 'General Details'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'General Details'){?>active<?php }?>">
			  <i class="nav-icon fa fa-gear"></i>
			  <p>
				 Manage Site Details  
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/generaldetails" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>General Details</p>
				</a>
			  </li>
			</ul>
			</li>


			<li class="nav-item has-treeview  <?php if($module == 'banner'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'banner'){?>active<?php }?>">
			  <i class="nav-icon fa fa-plus-square-o"></i>
			  <p>
				Manage Banners
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/banner" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Banners</p>
				</a>
			  </li>
			</ul>
			</li>


			<li class="nav-item has-treeview  <?php if($module == 'Gallery'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'Gallery'){?>active<?php }?>">
			  <i class="nav-icon fa fa-photo"></i>
			  <p>
				Manage Gallery
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/gallery" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Gallery</p>
				</a>
			  </li>
			</ul>
			</li>
			
			<li class="nav-item has-treeview  <?php if($module == 'Movie'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'Movie'){?>active<?php }?>">
			  <i class="nav-icon fa fa-film"></i>
			  <p>
				Manage Movie
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/movie" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Movie Gallery</p>
				</a>
			  </li>

			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/movie/add" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>Add Movie </p>
				</a>
			  </li>
			</ul>
			</li>


			<li class="nav-item has-treeview  <?php if($module == 'latest'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'latest'){?>active<?php }?>">
			  <i class="nav-icon fa fa-bullhorn"></i>
			  <p>
				Manage Latest
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/latest" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Latest </p>
				</a>
			  </li>

			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/latest/add" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>Add Latest </p>
				</a>
			  </li>
			</ul>
			</li>


			<li class="nav-item has-treeview  <?php if($module == 'Gossips'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'Gossips'){?>active<?php }?>">
			  <i class="nav-icon fa fa-users"></i>
			  <p>
				Manage Gossips
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/gossips" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Gossips </p>
				</a>
			  </li>

			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/gossips/add" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>Add Gossips </p>
				</a>
			  </li>
			</ul>
			</li>

			
			<li class="nav-item has-treeview  <?php if($module == 'page'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'page'){?>active<?php }?>">
			  <i class="nav-icon fa fa-plus-square-o"></i>
			  <p>
				Manage Pages
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/page" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Pages</p>
				</a>
			  </li>
			</ul>
			</li>


			<li class="nav-item">
			<a href="<?php echo base_url();?>siteadmin/dashboard/logout" class="nav-link">
			  <i class="nav-icon fa fa-circle-o text-info"></i>
			  <p>Logout</p>
			</a>
			</li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>