<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Welcome To AABT</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <base href="<?php echo base_url();?>" />
  <link rel="stylesheet" href="assets/siteadmin/plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="assets/siteadmin/dist/css/adminlte.min.css">
  <?php 
  if($module == "page" || $module == "category" || $module == "product" || $module == "certificate")
  {
  ?>
  <link rel="stylesheet" href="assets/siteadmin/plugins/datatables/dataTables.bootstrap4.css">
  <?php 
  }
  ?>
  
  <?php 
  if($module == 'gallery')
  {
  ?>
  <link href="<?php echo base_url()?>assets/dropzone/dropzone.min.css" rel="stylesheet">
  <script src="<?php echo base_url()?>assets/dropzone/dropzone.min.js"></script>
  <?php 
  }
  ?>
  <?php if($module == "page" || $module == "category" || $module == "product" || $module == "certificate"){?>
  <script src="assets/ckeditor/ckeditor.js"></script>
  <?php }?>
  
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  
  <?php if($module == 'job'){?>
	<link rel="stylesheet" href="assets/select2/styles/common.min.css" />
	<link rel="stylesheet" href="https://kendo.cdn.telerik.com/2018.2.620/styles/kendo.common-material.min.css" />
	<link rel="stylesheet" href="assets/select2/styles/default.min.css" />
	<link rel="stylesheet" href="assets/select2/styles/mobile.min.css" />
  <?php }?>
  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
  <!-- <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom" id="headernav"> -->
  <nav class="main-header navbar navbar-expand navbar-light border-bottom" id="headernav">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" title="Change Theme"><i class="fa fa-bars"></i></a>
      </li>
    </ul>

    <!-- Right navbar links 
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
            class="fa fa-th-large"></i></a>
      </li>
    </ul>
	-->
	
	<ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link" onclick="var colorcode = '#'+Math.floor(100000 + Math.random() * 900000); $('#colorcode').val(colorcode); $('#themebox').css('background-color',$('#colorcode').val()); $('#headernav').css('background-color',$('#colorcode').val()+'! important');"><i class="fa fa-th-large"></i></a>
		<input type="hidden" value="343a40" id="colorcode" />
      </li>
    </ul>
	
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4" id="themebox" style="background-color: #343a40;">
    <!-- Brand Logo -->
    <a href="<?php echo base_url();?>siteadmin/dashboard" class="brand-link">
		<!-- <img src="<?php echo base_url();?>assets/logo.png" alt="Senior Jobs" class="brand-image  elevation-3" style=""> -->
		<span class="brand-text font-weight-light"><img src="<?php echo base_url();?>assets/images/logo.jpg" style="width:80px;" /></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
			<li class="nav-item <?php if($module == 'dashboard'){?>menu-open<?php }?>">
			<a href="<?php echo base_url();?>siteadmin/dashboard" class="nav-link <?php if($module == 'dashboard'){?>active<?php }?>">
			  <i class="nav-icon fa fa-dashboard"></i>
			  <p>
				Dashboard
			  </p>
			</a>
			</li>
			
			
			<li class="nav-item has-treeview  <?php if($module == 'category'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'category'){?>active<?php }?>">
			  <i class="nav-icon fa fa-plus-square-o"></i>
			  <p>
				Manage Category
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/category/add" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>Add Category</p>
				</a>
			  </li>
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/category" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Category</p>
				</a>
			  </li>
			</ul>
			</li>
			<li class="nav-item has-treeview  <?php if($module == 'product'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'product'){?>active<?php }?>">
			  <i class="nav-icon fa fa-plus-square-o"></i>
			  <p>
				Manage Product
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/product/add" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>Add Product</p>
				</a>
			  </li>
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/product" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Product</p>
				</a>
			  </li>
			</ul>
			</li>
			
			<li class="nav-item has-treeview  <?php if($module == 'certificate'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'certificate'){?>active<?php }?>">
			  <i class="nav-icon fa fa-plus-square-o"></i>
			  <p>
				Manage Certificate
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/certificate/add" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>Add Certificate</p>
				</a>
			  </li>
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/certificate" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Certificate</p>
				</a>
			  </li>
			</ul>
			</li>
			
			<li class="nav-item has-treeview  <?php if($module == 'gallery'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'gallery'){?>active<?php }?>">
			  <i class="nav-icon fa fa-plus-square-o"></i>
			  <p>
				Manage Gallery
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/gallery" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Gallery</p>
				</a>
			  </li>
			</ul>
			</li>
			<li class="nav-item has-treeview  <?php if($module == 'page'){?>menu-open<?php }?>">
			<a href="#" class="nav-link <?php if($module == 'page'){?>active<?php }?>">
			  <i class="nav-icon fa fa-plus-square-o"></i>
			  <p>
				Manage Pages
				<i class="right fa fa-angle-left"></i>
			  </p>
			</a>
			<ul class="nav nav-treeview">
			  <li class="nav-item">
				<a href="<?php echo base_url();?>siteadmin/page" class="nav-link">
				  <i class="fa fa-circle-o nav-icon"></i>
				  <p>View Pages</p>
				</a>
			  </li>
			</ul>
			</li>



			<li class="nav-item">
			<a href="<?php echo base_url();?>siteadmin/dashboard/logout" class="nav-link">
			  <i class="nav-icon fa fa-circle-o text-info"></i>
			  <p>Logout</p>
			</a>
			</li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>