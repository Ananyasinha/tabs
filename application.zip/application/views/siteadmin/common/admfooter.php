<footer class="main-footer">
    <strong>Copyright Movies &copy; <?php echo date('Y');?> <a ></a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b><p>Design by 360WebsiteDesign</p></b>
    </div>
</footer> 


  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="assets/siteadmin/plugins/jquery/jquery.min.js"></script>
<script src="assets/function/common_function.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="assets/siteadmin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<?php if($module == "page" || $module == "product" || $module == 'banner' || $module == 'latest' || $module == 'award' || $module == 'Movie' || $module == 'gossips'){?>
  
<script src="assets/siteadmin/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/siteadmin/plugins/datatables/dataTables.bootstrap4.js"></script>
<?php }?>

<script src="assets/siteadmin/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="assets/siteadmin/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="assets/siteadmin/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="assets/siteadmin/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="assets/siteadmin/dist/js/demo.js"></script>

<?php if($module == "page" || $module == "product" || $module == 'banner' || $module == 'latest' || $module == 'award' || $module == 'Movie' || $module == 'gossips'){?>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable({
		"ordering": false
	});
  });
</script>
<script>
setTimeout(function(){ $('.alert').css('display','none'); $('.alert').html(''); }, 3000);
</script>
<?php }?>


<?php 
if($module == 'banner' || $module == 'facility' || $module == 'quality' || $module == 'award' || $module == 'customer' || $module == 'otherdata')
{
?>
<script type="text/javascript">
Dropzone.options.imageUpload = {
	maxFilesize:2000,
	acceptedFiles: ".jpeg,.jpg,.png,.gif",
	init: function() {
		this.on('success', function(data){
			if (this.getQueuedFiles().length == 0 && this.getUploadingFiles().length == 0) {
     			setTimeout(function(){ location.reload(); }, 3000);
			}
	    });
	}
};
Dropzone.prototype.defaultOptions.dictDefaultMessage = "Choose or Drop files here to upload";
</script>
<?php 
}
?>
</body>
</html>