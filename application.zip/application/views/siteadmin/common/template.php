<?php
$this->load->view('siteadmin/common/admheader');
$this->load->view('siteadmin/'.$main_content);
$this->load->view('siteadmin/common/admfooter');
?>