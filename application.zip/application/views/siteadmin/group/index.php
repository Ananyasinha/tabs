  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css"></style> 
<!-- Content Wrapper. Contains page content -->
 <div class="content-inner">
    <!-- Page Header-->
    <header class="page-header">
      <div class="container-fluid">
        <h2 class="no-margin-bottom">Manage Group Companies</h2>
      </div>
    </header>

    <section class="tables">   
      <div class="container-fluid">
        <div class="row">

          <div class="col-lg-12">

            <?php 
            if($this->session->userdata('alert_type')!="")
            {
              ?>
              <div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
                <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                <?php echo $this->session->userdata('msg');?>
              </div>
              <?php
              $this->session->unset_userdata('alert_type');
              $this->session->unset_userdata('msg');
            }
            ?>
            <div class="card">
             
              <div class="card-header d-flex align-items-center">
                <h3 class="h4"> Group Companies list</h3>
              </div>
              <div class="card-body">
                <div class="table-responsive">  
                
                  <table id="table_id" class="table table-striped table-bordered text-center table_id" style="width:100%">
                    <thead>
                      <tr>
                        <th>S.no</th>
                        <th>Page Title</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>

                      <?php 
                      $i=1;
                      if(count(array_filter($result)) > 0){
                        foreach($result as $row){
                        ?>

                      <tr>
                        <th scope="row"><?php echo $i.'.';?></th>
                        <td><?php echo $row->name;?></td>

                        <td>
                          <a href="<?php echo base_url();?>siteadmin/group/edit/<?php echo $row->id;?>" title="Edit">
                            <i class="fa fa-edit fa-2x" style="color:#f55145!important;"></i>
                          </a>
                       
                        </td>
                                      
                      </tr>
                      <?php 
                        $i++ ;}
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  <!-- /.content-wrapper -->

