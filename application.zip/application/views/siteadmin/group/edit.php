
  <style type="text/css">
  .form-group {
    margin-bottom: 20px;
}
</style>

<div class="content-inner">
  <!-- Page Header-->
  <header class="page-header">
    <div class="container-fluid">
      <h2 class="no-margin-bottom">Edit Group Company </h2>
    </div>
  </header>

  <!-- Forms Section-->
  <section class="forms"> 
    <div class="container-fluid">
      <div class="row">

        <!-- Manage Contact Details-->
        <div class="col-lg-11 ml-auto mr-auto">
          <div class="card">
            <div class="card-header d-flex align-items-center">
              <h3 class="h4"></h3>
            </div>
            <div class="card-body">
             
	          <form method="post" action="<?php echo base_url();?>siteadmin/group/updategroup" enctype="multipart/form-data">
			        <input type="hidden" name="pageid" id="pageid" value="<?php echo $result->id;?>" />

                <div class="form-group">
                  <label class="form-control-label"> Company Name</label>
                  <input type="text" class="form-control" name="companyname" value="<?php echo $result->name;?>" required="">
                </div>

                <div class="form-group">
                  <label class="form-control-label"> Company Title</label>
                  <input type="text" class="form-control" name="companytitle" value="<?php echo $result->title;?>" required="">
                </div>

                <div class="form-group">
                  <label class="form-control-label">Page Description</label>
                 <textarea class="form-control ckeditor"  name="description"  id="page-content" size="15"><?php echo $result->grp_content;?></textarea>
                </div>

                <hr>
                <div class="form-group">       
                  <input type="submit" value="Submit" class="btn btn-primary">
                </div>
              </form>

            </div>
          </div>
        </div>

      </div>
    </div>
  </section>


