<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Latest</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Latest</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
          <form method="post" action="<?php echo base_url();?>siteadmin/latest/update" enctype="multipart/form-data">
		  <input type="hidden" name="id" id="id" value="<?php echo $result->id;?>" />
		  <div class="row">
          
		  
		  
		  
			<div class="col-md-8 ml-auto mr-auto">
			<!-- Horizontal Form -->
				<div class="card card-info">
					<div class="card-body">
						<div class="form-group">
							<label for="company_name"> Title</label>
							<input type="text" class="form-control" name="title" id="title" value="<?php echo $result->fld_title;?>" required />
						</div>

						<div class="form-group">
							<label for="company_name">Release Date</label>
							<input type="date" class="form-control" name="release_date" value="<?php echo $result->release_date;?>" required />
						</div>
						
						<div class="form-group">
							<label for="comp_logo">Image</label>
							<input type="file" class="form-control" name="movie_image" id="movie_image" value="" />
							<input type="hidden" class="form-control" name="oldnews_image" id="oldnews_image" value="<?php echo $result->fld_image;?>" />
							<span style="color:#f00">[Dimension: 350 x 282 Pixel]</span>
						</div>
					</div>
					<div class="card-footer">
						<button type="submit" class="btn btn-primary">Submit</button>
					</div>
				</div>
			</div>
			
		  </div>
		  
		  </form>
        
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->