<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Manage Movie Gallery</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url();?>siteadmin/dashboard">Home</a></li>
              <li class="breadcrumb-item active">Movie Gallery</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
    <!-- Main content -->
    <section class="content">
	<?php 
	if($this->session->userdata('alert_type')!="")
	{
		?>
		<div class="alert alert-<?php echo $this->session->userdata('alert_type');?>">
			<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
			<?php echo $this->session->userdata('msg');?>
		</div>
		<?php
		$this->session->unset_userdata('alert_type');
		$this->session->unset_userdata('msg');
	}
	?>
      <div class="row">
        <div class="col-12">
			<div class="container">
			<div class="row">
				<div class="col-md-12">
					
					<form action="<?php echo base_url()?>siteadmin/movie/insertaward" enctype="multipart/form-data" class="dropzone" id="image-upload"></form>
				</div>
			</div><span style="color:#f00;float:right">[Recommended Dimension: 522 x 351 Pixel]</span>
			</div>
			
		</div>
		<div class="clearfix">&nbsp;</div>
        <div class="col-12">
         
		 <div class="card">
            
            <!-- /.card-header -->
            <div class="card-body table-responsive">
              <table id="example1" class="table table-bordered table-striped">
                <tbody>
				<?php if(count(array_filter($result)) > 0){?>
					<tr>
					  <?php 
					  $i=0;
					  foreach($result as $row){
					  $i++;
					  ?>
						<td style="text-align: center;vertical-align: middle;">
						<?php if($row->fld_image!=""){?>
						<img src="<?php echo base_url();?>assets/awardimg/<?php echo $row->fld_image;?>" style='width:280px;' />
						<?php }?>
						<br><br>
						<a href="<?php echo base_url();?>siteadmin/movie/deleteaward/<?php echo $row->id;?>" title="Delete" onclick="return confirm('Are you sure, want to delete this record?');" class="btn btn-danger"><i class="fa fa-trash"></i></a>
						
						<?php if($row->status == "Active"){?>
						<span class="btn label-success" style="cursor:pointer;padding: 6px 10px;border-radius: 12%;" onclick="return changestatus('<?php echo base_url();?>','awardstatus<?php echo $row->id;?>',this,'<?php echo $row->id;?>','award');"><i class="fa fa-check"></i></span>
						<?php }else{?>
						<span class="btn label-danger" style="cursor:pointer;padding: 6px 10px;border-radius: 12%;" onclick="return changestatus('<?php echo base_url();?>','awardstatus<?php echo $row->id;?>',this,'<?php echo $row->id;?>','award');"><i class="fa fa-times" style="width: 16px;"></i></span>
						<?php }?>
						<input type="hidden" id="awardstatus<?php echo $row->id;?>" value="<?php echo $row->status;?>" />
						</br>
						</td>
						<?php if($i%2==0){?>
						</tr>
						<?php
						}
					}
				}else{
					?>
					<tr>
					  <td colspan="2">
							Info. Not available
					  </td>
					</tr>
					<?php
				}
				?>
                </tfoot>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->